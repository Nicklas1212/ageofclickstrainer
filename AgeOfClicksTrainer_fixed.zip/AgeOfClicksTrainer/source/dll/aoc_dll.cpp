// Age of Clicks Trainer - injected loader DLL.
// Runs inside the game's own process, attaches to the game's JVM, defines the embedded
// Java bridge classes in the game's class loader and starts the localhost bridge server.
#include <windows.h>
#include <cstdio>
#include <cstdarg>
#include <string>
#include "jni_win/jni.h"
#include "bridge_classes.h"
#include "Overlay/Overlay.h"

static int kPort = 47653;
static HMODULE g_self = nullptr;
static char g_logPath[MAX_PATH] = {0};

static void Log(const char* fmt, ...) {
    FILE* f = fopen(g_logPath, "ab");
    if (!f) { char t[MAX_PATH]; DWORD n = GetTempPathA(MAX_PATH, t); if (n && n < MAX_PATH) { strcat(t, "aoc_trainer_dll.log"); f = fopen(t, "ab"); } }
    if (!f) return;
    SYSTEMTIME t; GetLocalTime(&t); fprintf(f, "[%02d:%02d:%02d] ", t.wHour, t.wMinute, t.wSecond);
    va_list a; va_start(a, fmt); vfprintf(f, fmt, a); va_end(a); fputc('\n', f); fclose(f);
}

typedef jint (JNICALL *GetCreatedJavaVMs_t)(JavaVM**, jsize, jsize*);

static bool Describe(JNIEnv* env, const char* where) {
    if (!env->ExceptionCheck()) return false;
    jthrowable ex = env->ExceptionOccurred(); env->ExceptionClear();
    jclass tc = env->FindClass("java/lang/Throwable"); jmethodID ts = env->GetMethodID(tc, "toString", "()Ljava/lang/String;");
    jstring s = (jstring)env->CallObjectMethod(ex, ts);
    if (env->ExceptionCheck()) env->ExceptionClear();
    const char* c = s ? env->GetStringUTFChars(s, nullptr) : "?"; Log("EXCEPTION in %s: %s", where, c); if (s) env->ReleaseStringUTFChars(s, c);
    return true;
}

static DWORD WINAPI Worker(LPVOID) {
    kPort = 41000 + (int)(GetCurrentProcessId() % 20000);
    Log("worker started (pid %lu, bridge port %d)", GetCurrentProcessId(), kPort);
    // The Java bridge is started FIRST; the OpenGL overlay hook is started afterwards so that a hook problem on a new game
    // version can never prevent the bridge (and therefore all features) from working.
    HMODULE jvm = nullptr;
    for (int i = 0; i < 600 && !jvm; i++) { jvm = GetModuleHandleA("jvm.dll"); if (!jvm) Sleep(100); }
    if (!jvm) { Log("jvm.dll not found - this is not a Java process"); return 1; }
    auto getVMs = (GetCreatedJavaVMs_t)GetProcAddress(jvm, "JNI_GetCreatedJavaVMs");
    if (!getVMs) { Log("JNI_GetCreatedJavaVMs missing"); return 1; }
    JavaVM* vm = nullptr; jsize n = 0;
    for (int i = 0; i < 600; i++) { if (getVMs(&vm, 1, &n) == JNI_OK && n > 0) break; n = 0; Sleep(100); }
    if (n == 0) { Log("no JVM created"); return 1; }
    JNIEnv* env = nullptr;
    if (vm->AttachCurrentThread((void**)&env, nullptr) != JNI_OK) { Log("AttachCurrentThread failed"); return 1; }
    Log("attached to JVM");

    jclass clC = env->FindClass("java/lang/ClassLoader");
    jmethodID sys = env->GetStaticMethodID(clC, "getSystemClassLoader", "()Ljava/lang/ClassLoader;");
    jobject loader = env->CallStaticObjectMethod(clC, sys);
    if (Describe(env, "getSystemClassLoader") || !loader) { vm->DetachCurrentThread(); return 1; }
    jmethodID loadClass = env->GetMethodID(clC, "loadClass", "(Ljava/lang/String;)Ljava/lang/Class;");

    // Already injected? (loadClass succeeds)
    jstring nm = env->NewStringUTF("AocBridge");
    jobject existing = env->CallObjectMethod(loader, loadClass, nm);
    if (env->ExceptionCheck()) { env->ExceptionClear(); existing = nullptr; }
    if (existing) { Log("bridge already present - nothing to do"); vm->DetachCurrentThread(); return 0; }

    for (int i = 0; i < kClassCount; i++) {
        jclass c = env->DefineClass(kClasses[i].name, loader, (const jbyte*)kClasses[i].data, (jsize)kClasses[i].size);
        if (Describe(env, kClasses[i].name) || !c) { Log("DefineClass failed for %s", kClasses[i].name); vm->DetachCurrentThread(); return 1; }
        env->DeleteLocalRef(c);
    }
    Log("defined %d bridge classes", kClassCount);
    jobject bc = env->CallObjectMethod(loader, loadClass, nm);
    if (Describe(env, "loadClass(AocBridge)") || !bc) { vm->DetachCurrentThread(); return 1; }
    jmethodID start = env->GetStaticMethodID((jclass)bc, "start", "(I)V");
    if (!start) { Describe(env, "GetStaticMethodID"); Log("start() not found"); vm->DetachCurrentThread(); return 1; }
    env->CallStaticVoidMethod((jclass)bc, start, (jint)kPort);
    if (Describe(env, "AocBridge.start")) { vm->DetachCurrentThread(); return 1; }
    Log("bridge started on 127.0.0.1:%d", kPort);
    vm->DetachCurrentThread();
    Log("starting overlay hook");
    Overlay::Start(g_self);
    return 0;
}

BOOL WINAPI DllMain(HINSTANCE h, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) {
        g_self = h; DisableThreadLibraryCalls(h);
        GetModuleFileNameA(h, g_logPath, MAX_PATH);
        char* dot = strrchr(g_logPath, '\\'); if (dot) *(dot + 1) = 0; strcat(g_logPath, "aoc_trainer_dll.log");
        Log("DLL loaded into pid %lu", GetCurrentProcessId());
        HANDLE t = CreateThread(nullptr, 0, Worker, nullptr, 0, nullptr); if (t) CloseHandle(t);
    }
    return TRUE;
}
