@echo off
REM Build on Windows with MSYS2 MinGW-w64 (verified) or Visual Studio (not verified). Needs CMake.
REM A JDK is only needed if you change the Java bridge (then run: python bridge\gen_header.py).
if not exist build mkdir build
cmake -S . -B build -G "MinGW Makefiles" -DCMAKE_BUILD_TYPE=Release || cmake -S . -B build -A x64
cmake --build build --config Release
echo Output is in build (MinGW) or build\Release (MSVC). Keep the 3 files together:
echo   AgeOfClicksTrainer.exe, AgeOfClicksTrainerCore.dll, AocInject.exe
