// Stand-alone command-line injector: AocInject.exe  (loads AgeOfClicksTrainerCore.dll into the running game).
#include "inject.h"
#include <cstdio>
int main() {
    GameProc g = FindGame();
    if (!g.pid) { puts("Age of Clicks is not running. Start the game, load a single-player game, then run this again."); return 1; }
    if (!g.hasJvm) { puts("The game is still starting. Wait for the main menu and try again."); return 1; }
    if (g.hasCore) { puts("Already injected. Start AgeOfClicksTrainer.exe."); return 0; }
    std::string e = InjectDll(g.pid, ExeDir() + L"AgeOfClicksTrainerCore.dll");
    if (!e.empty()) { printf("FAILED: %s\n", e.c_str()); return 2; }
    puts("Injected. Start AgeOfClicksTrainer.exe (or it will connect automatically if already open)."); return 0;
}
