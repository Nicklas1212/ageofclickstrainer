#pragma once
// Winsock client for the in-game bridge (127.0.0.1 only) + small helpers.
#include <cstdarg>
#include <cstdio>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <windows.h>
#include <string>
#include <vector>
#include <deque>
#include <map>
#include <mutex>
#include <thread>
#include <atomic>
#include <chrono>

static const int kBridgePort = 47653;

inline std::vector<std::string> Split(const std::string& s, char sep) {
    std::vector<std::string> out; size_t st = 0;
    while (true) { size_t p = s.find(sep, st); if (p == std::string::npos) { out.push_back(s.substr(st)); break; } out.push_back(s.substr(st, p - st)); st = p + 1; }
    return out;
}
inline std::string Fmt(const char* f, ...) { char b[1024]; va_list a; va_start(a, f); vsnprintf(b, sizeof b, f, a); va_end(a); return b; }

struct LogEntry { std::string time, text; bool err; };

class Net {
public:
    std::mutex mu;
    std::map<std::string, std::string> kv;            // parsed status
    std::map<std::string, std::string> last;          // last payload by tag
    std::deque<LogEntry> log;
    std::atomic<bool> connected{false}, gameReady{false}, multiplayer{false};
    std::string stateMsg = "Not connected";

    void Start() { WSADATA w; WSAStartup(MAKEWORD(2, 2), &w); run = true; th = std::thread(&Net::Loop, this); }
    void Stop() { run = false; if (th.joinable()) th.join(); WSACleanup(); }
    void Submit(const std::string& cmd, const std::string& tag = "cmd") {
        std::lock_guard<std::mutex> l(mu);
        if (tag != "cmd") for (auto& r : q) if (r.tag == tag) return;   // coalesce periodic requests
        q.push_back({cmd, tag});
    }
    std::string Get(const std::string& k, const std::string& def = "") { std::lock_guard<std::mutex> l(mu); auto it = kv.find(k); return it == kv.end() ? def : it->second; }
    double Num(const std::string& k, double def = 0) { std::string s = Get(k); if (s.empty()) return def; return atof(s.c_str()); }
    bool Has(const std::string& k) { std::lock_guard<std::mutex> l(mu); return kv.count(k) > 0; }
    std::string Payload(const std::string& tag) { std::lock_guard<std::mutex> l(mu); auto it = last.find(tag); return it == last.end() ? "" : it->second; }
    uint64_t statusSerial = 0;
    void AddLog(const std::string& t, bool err) {
        SYSTEMTIME st; GetLocalTime(&st); char b[16]; snprintf(b, sizeof b, "%02d:%02d:%02d", st.wHour, st.wMinute, st.wSecond);
        std::lock_guard<std::mutex> l(mu); log.push_back({b, t, err}); while (log.size() > 500) log.pop_front();
    }
    std::string LastToast; double ToastUntil = 0; bool ToastErr = false;   // UI thread reads
    uint64_t toastSerial = 0;

private:
    struct Req { std::string cmd, tag; };
    std::deque<Req> q; std::thread th; std::atomic<bool> run{false}; SOCKET s = INVALID_SOCKET; std::string rbuf;

    bool Connect() {
        s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP); if (s == INVALID_SOCKET) return false;
        sockaddr_in a{}; a.sin_family = AF_INET; a.sin_port = htons(kBridgePort); inet_pton(AF_INET, "127.0.0.1", &a.sin_addr);
        DWORD to = 6000; setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, (const char*)&to, sizeof to);
        if (connect(s, (sockaddr*)&a, sizeof a) != 0) { closesocket(s); s = INVALID_SOCKET; return false; }
        int one = 1; setsockopt(s, IPPROTO_TCP, TCP_NODELAY, (const char*)&one, sizeof one); rbuf.clear(); return true;
    }
    bool Roundtrip(const std::string& cmd, std::string& resp) {
        std::string out = cmd + "\n"; if (send(s, out.c_str(), (int)out.size(), 0) <= 0) return false;
        while (true) {
            size_t p = rbuf.find('\n'); if (p != std::string::npos) { resp = rbuf.substr(0, p); rbuf.erase(0, p + 1); return true; }
            char b[8192]; int n = recv(s, b, sizeof b, 0); if (n <= 0) return false; rbuf.append(b, n);
        }
    }
    static std::string Unesc(std::string s) { size_t p = 0; while ((p = s.find("\\n", p)) != std::string::npos) { s.replace(p, 2, "\n"); p++; } return s; }
    void Handle(const Req& r, const std::string& resp) {
        bool ok = resp.rfind("OK|", 0) == 0; std::string body = resp.size() > 3 ? resp.substr(3) : "";
        if (!ok) {   // ERR|CODE|message  or ERR|message
            std::string m = resp.size() > 4 ? resp.substr(4) : resp; auto parts = Split(m, '|'); std::string code = parts.size() > 1 ? parts[0] : "", msg = parts.size() > 1 ? parts[1] : parts[0];
            if (code == "NOGAME") { gameReady = false; multiplayer = false; stateMsg = "Connected - waiting for you to load a single-player game"; if (r.tag == "status") return; }
            if (r.tag != "cmd" && code == "NOGAME") return;
            AddLog(r.cmd + "  ->  " + Unesc(msg), true); if (r.tag == "cmd") { LastToast = Unesc(msg); ToastErr = true; toastSerial++; }
            if (code == "MULTIPLAYER") { multiplayer = true; }
            return;
        }
        if (r.tag == "status") {
            std::map<std::string, std::string> m;
            for (auto& f : Split(body, '\t')) { size_t e = f.find('='); if (e != std::string::npos) m[f.substr(0, e)] = f.substr(e + 1); }
            std::lock_guard<std::mutex> l(mu); kv.swap(m); statusSerial++;
            multiplayer = kv["mp"] == "1"; gameReady = true; stateMsg = multiplayer ? "MULTIPLAYER detected - trainer disabled" : "Attached - single-player game active"; return;
        }
        if (r.tag == "cmd") { AddLog(r.cmd + "  ->  " + Unesc(body), false); LastToast = Unesc(body); ToastErr = false; toastSerial++; }
        else { std::lock_guard<std::mutex> l(mu); last[r.tag] = body; }
    }
    void Loop() {
        while (run) {
            if (s == INVALID_SOCKET) {
                connected = false;
                if (!Connect()) { stateMsg = "Not connected - click 'Inject / Connect' (game must be running)"; gameReady = false; for (int i = 0; i < 10 && run; i++) Sleep(100); continue; }
                connected = true; stateMsg = "Connected";
            }
            Req r; bool have = false;
            { std::lock_guard<std::mutex> l(mu); if (!q.empty()) { r = q.front(); q.pop_front(); have = true; } }
            if (!have) { Sleep(8); continue; }
            std::string resp;
            if (!Roundtrip(r.cmd, resp)) { closesocket(s); s = INVALID_SOCKET; connected = false; gameReady = false; stateMsg = "Connection lost"; continue; }
            Handle(r, resp);
        }
        if (s != INVALID_SOCKET) closesocket(s);
    }
};
