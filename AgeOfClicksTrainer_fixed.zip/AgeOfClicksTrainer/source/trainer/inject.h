#pragma once
// Process discovery + DLL injection (classic CreateRemoteThread/LoadLibraryW). Targets only the game's own process.
#include <windows.h>
#include <tlhelp32.h>
#include <psapi.h>
#include <string>
#include <vector>
#include <cwctype>

struct GameProc { DWORD pid = 0; std::wstring exePath; bool hasJvm = false; bool hasCore = false; bool modulesUnknown = false; std::string diag; };

inline std::wstring Lower(std::wstring s) { for (auto& c : s) c = (wchar_t)towlower(c); return s; }

inline std::string NarrowAscii(const std::wstring& w) { std::string r; for (wchar_t c : w) r += (c < 128 ? (char)c : '?'); return r; }

// Inspect one process: path, jvm.dll present?, our DLL present? modulesUnknown = module list could not be read (access denied etc).
inline void Inspect(DWORD pid, GameProc& g) {
    g.pid = pid; g.hasJvm = false; g.hasCore = false; g.modulesUnknown = false; g.exePath.clear();
    HANDLE p = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pid);
    if (p) { wchar_t b[MAX_PATH * 2]; DWORD n = MAX_PATH * 2; if (QueryFullProcessImageNameW(p, 0, b, &n)) g.exePath = b; CloseHandle(p); }
    HANDLE ms = INVALID_HANDLE_VALUE;
    for (int tries = 0; tries < 5; tries++) { ms = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32, pid); if (ms != INVALID_HANDLE_VALUE) break; if (GetLastError() == ERROR_BAD_LENGTH) continue; break; }
    if (ms == INVALID_HANDLE_VALUE) { g.modulesUnknown = true; return; }
    MODULEENTRY32W me{sizeof me};
    for (BOOL ok = Module32FirstW(ms, &me); ok; ok = Module32NextW(ms, &me)) {
        std::wstring m = Lower(me.szModule);
        if (m == L"jvm.dll") g.hasJvm = true;
        if (m == L"ageofclickstrainercore.dll") g.hasCore = true;
    }
    CloseHandle(ms);
}

// Finds the game. 1) a process called "Age of Clicks.exe"; 2) any process running from an "Age of Clicks" folder with jvm.dll;
// 3) any javaw/java process whose path contains "age of clicks". If the module list cannot be read, the process is still returned
// (modulesUnknown) and the injected DLL itself waits for the JVM.
inline BOOL CALLBACK EnumGlfwWnd(HWND h, LPARAM lp) {
    wchar_t cn[64]; if (!GetClassNameW(h, cn, 64)) return TRUE; if (wcscmp(cn, L"GLFW30") != 0 || !IsWindowVisible(h)) return TRUE;
    DWORD pid = 0; GetWindowThreadProcessId(h, &pid); ((std::vector<DWORD>*)lp)->push_back(pid); return TRUE;
}
inline GameProc FindGame() {
    GameProc best; best.diag = "";
    std::vector<DWORD> glfwPids; EnumWindows(EnumGlfwWnd, (LPARAM)&glfwPids);
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0); if (snap == INVALID_HANDLE_VALUE) return best;
    struct Cand { DWORD pid; std::wstring name; };
    std::vector<Cand> all; PROCESSENTRY32W pe{sizeof pe};
    for (BOOL ok = Process32FirstW(snap, &pe); ok; ok = Process32NextW(snap, &pe)) all.push_back({pe.th32ProcessID, Lower(pe.szExeFile)});
    CloseHandle(snap);
    int bestScore = -1;
    for (auto& c : all) {
        bool byName = (c.name == L"age of clicks.exe" || c.name == L"ageofclicks.exe");
        bool javaLike = (c.name == L"java.exe" || c.name == L"javaw.exe");
        bool hasWin = false; for (DWORD w : glfwPids) if (w == c.pid) hasWin = true;
        GameProc g; Inspect(c.pid, g);
        std::wstring path = Lower(g.exePath);
        bool inFolder = path.find(L"age of clicks") != std::wstring::npos || path.find(L"ageofclicks") != std::wstring::npos;
        if (!hasWin && !byName && !inFolder && !(javaLike && g.hasJvm && inFolder)) continue;
        int score = (hasWin ? 1000 : 0) + (g.hasJvm ? 100 : 0) + (byName ? 10 : 0) + (inFolder ? 5 : 0) + (g.hasCore ? 1 : 0);
        char line[512]; snprintf(line, sizeof line, " [pid %lu %s jvm=%s%s window=%s]", (unsigned long)c.pid, NarrowAscii(c.name).c_str(), g.hasJvm ? "yes" : "no", g.modulesUnknown ? " (modules unreadable - try Run as administrator)" : "", hasWin ? "yes" : "no");
        best.diag += line;
        if (score > bestScore) { std::string d = best.diag; best = g; best.diag = d; bestScore = score; }
    }
    return best;
}

inline void EnableDebugPrivilege() {
    HANDLE t; if (!OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &t)) return;
    TOKEN_PRIVILEGES tp{}; tp.PrivilegeCount = 1; tp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
    if (LookupPrivilegeValueW(nullptr, L"SeDebugPrivilege", &tp.Privileges[0].Luid)) AdjustTokenPrivileges(t, FALSE, &tp, sizeof tp, nullptr, nullptr);
    CloseHandle(t);
}

inline std::string InjectDll(DWORD pid, const std::wstring& dllPath) {
    EnableDebugPrivilege();
    if (GetFileAttributesW(dllPath.c_str()) == INVALID_FILE_ATTRIBUTES) return "AgeOfClicksTrainerCore.dll not found next to the trainer.";
    HANDLE p = OpenProcess(PROCESS_CREATE_THREAD | PROCESS_QUERY_INFORMATION | PROCESS_VM_OPERATION | PROCESS_VM_WRITE | PROCESS_VM_READ, FALSE, pid);
    if (!p) return "Cannot open the game process (error " + std::to_string(GetLastError()) + "). Run the trainer as the same user as the game (try 'Run as administrator').";
    BOOL wow = FALSE; IsWow64Process(p, &wow); if (wow) { CloseHandle(p); return "The game process is 32-bit; this build only supports 64-bit."; }
    size_t bytes = (dllPath.size() + 1) * sizeof(wchar_t);
    void* mem = VirtualAllocEx(p, nullptr, bytes, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (!mem) { CloseHandle(p); return "VirtualAllocEx failed."; }
    if (!WriteProcessMemory(p, mem, dllPath.c_str(), bytes, nullptr)) { VirtualFreeEx(p, mem, 0, MEM_RELEASE); CloseHandle(p); return "WriteProcessMemory failed."; }
    auto ll = (LPTHREAD_START_ROUTINE)GetProcAddress(GetModuleHandleW(L"kernel32.dll"), "LoadLibraryW");
    HANDLE t = CreateRemoteThread(p, nullptr, 0, ll, mem, 0, nullptr);
    if (!t) { VirtualFreeEx(p, mem, 0, MEM_RELEASE); CloseHandle(p); return "CreateRemoteThread failed (error " + std::to_string(GetLastError()) + ")."; }
    WaitForSingleObject(t, 10000); DWORD code = 0; GetExitCodeThread(t, &code); CloseHandle(t);
    VirtualFreeEx(p, mem, 0, MEM_RELEASE); CloseHandle(p);
    if (code == 0) return "LoadLibrary returned NULL - the DLL could not be loaded in the game. Likely causes: antivirus/Windows Defender blocking AgeOfClicksTrainerCore.dll (add the trainer folder as an exclusion), the files are still marked 'downloaded from the internet' (right-click each file > Properties > Unblock), or the folder path is not readable by the game.";
    return "";
}

inline std::wstring ExeDir() { wchar_t b[MAX_PATH]; GetModuleFileNameW(nullptr, b, MAX_PATH); std::wstring s = b; return s.substr(0, s.find_last_of(L"\\/") + 1); }
