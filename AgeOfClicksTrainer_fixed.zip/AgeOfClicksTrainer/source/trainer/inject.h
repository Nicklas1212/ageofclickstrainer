#pragma once
// Process discovery + DLL injection (classic CreateRemoteThread/LoadLibraryW). Targets only the game's own process.
#include <windows.h>
#include <tlhelp32.h>
#include <psapi.h>
#include <string>
#include <vector>
#include <cwctype>

struct GameProc { DWORD pid = 0; std::wstring exePath; bool hasJvm = false; bool hasCore = false; };

inline std::wstring Lower(std::wstring s) { for (auto& c : s) c = (wchar_t)towlower(c); return s; }

inline GameProc FindGame() {
    GameProc g; HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0); if (snap == INVALID_HANDLE_VALUE) return g;
    PROCESSENTRY32W pe{sizeof pe};
    for (BOOL ok = Process32FirstW(snap, &pe); ok; ok = Process32NextW(snap, &pe)) {
        std::wstring n = Lower(pe.szExeFile);
        if (n == L"age of clicks.exe" || n == L"ageofclicks.exe") { g.pid = pe.th32ProcessID; break; }
    }
    CloseHandle(snap);
    if (!g.pid) {   // fallback for renamed launchers: any 64-bit process that has jvm.dll and "age" / "clicks" in its path or name
        HANDLE sn2 = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
        if (sn2 != INVALID_HANDLE_VALUE) { PROCESSENTRY32W q{sizeof q};
            for (BOOL ok = Process32FirstW(sn2, &q); ok && !g.pid; ok = Process32NextW(sn2, &q)) {
                HANDLE pp = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, q.th32ProcessID); if (!pp) continue;
                wchar_t b[MAX_PATH * 2]; DWORD n = MAX_PATH * 2; std::wstring path; if (QueryFullProcessImageNameW(pp, 0, b, &n)) path = Lower(b); CloseHandle(pp);
                if (path.find(L"age of clicks") == std::wstring::npos && path.find(L"ageofclicks") == std::wstring::npos) continue;
                HANDLE m2 = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32, q.th32ProcessID); if (m2 == INVALID_HANDLE_VALUE) continue;
                MODULEENTRY32W e{sizeof e}; for (BOOL k = Module32FirstW(m2, &e); k; k = Module32NextW(m2, &e)) if (Lower(e.szModule) == L"jvm.dll") { g.pid = q.th32ProcessID; break; }
                CloseHandle(m2); }
            CloseHandle(sn2); }
    }
    if (!g.pid) return g;
    HANDLE ms = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32, g.pid);
    if (ms != INVALID_HANDLE_VALUE) { MODULEENTRY32W me{sizeof me};
        for (BOOL ok = Module32FirstW(ms, &me); ok; ok = Module32NextW(ms, &me)) { std::wstring m = Lower(me.szModule); if (m == L"jvm.dll") g.hasJvm = true; if (m == L"ageofclickstrainercore.dll") g.hasCore = true; }
        CloseHandle(ms); }
    HANDLE p = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, g.pid);
    if (p) { wchar_t b[MAX_PATH * 2]; DWORD n = MAX_PATH * 2; if (QueryFullProcessImageNameW(p, 0, b, &n)) g.exePath = b; CloseHandle(p); }
    return g;
}

// returns empty string on success, otherwise an explanation
inline void EnableDebugPrivilege() {
    HANDLE t; if (!OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &t)) return;
    TOKEN_PRIVILEGES tp{}; tp.PrivilegeCount = 1; tp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
    if (LookupPrivilegeValueW(nullptr, L"SeDebugPrivilege", &tp.Privileges[0].Luid)) AdjustTokenPrivileges(t, FALSE, &tp, sizeof tp, nullptr, nullptr);
    CloseHandle(t);
}

inline std::string InjectDll(DWORD pid, const std::wstring& dllPath) {
    EnableDebugPrivilege();
    if (GetFileAttributesW(dllPath.c_str()) == INVALID_FILE_ATTRIBUTES) return "AgeOfClicksTrainerCore.dll not found next to the trainer.";
    HANDLE p = OpenProcess(PROCESS_CREATE_THREAD | PROCESS_QUERY_INFORMATION | PROCESS_VM_OPERATION | PROCESS_VM_WRITE | PROCESS_VM_READ, FALSE, pid);
    if (!p) return "Cannot open the game process (error " + std::to_string(GetLastError()) + "). Run the trainer as the same user as the game (try 'Run as administrator').";
    BOOL wow = FALSE; IsWow64Process(p, &wow); if (wow) { CloseHandle(p); return "The game process is 32-bit; this build only supports 64-bit."; }
    size_t bytes = (dllPath.size() + 1) * sizeof(wchar_t);
    void* mem = VirtualAllocEx(p, nullptr, bytes, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (!mem) { CloseHandle(p); return "VirtualAllocEx failed."; }
    if (!WriteProcessMemory(p, mem, dllPath.c_str(), bytes, nullptr)) { VirtualFreeEx(p, mem, 0, MEM_RELEASE); CloseHandle(p); return "WriteProcessMemory failed."; }
    auto ll = (LPTHREAD_START_ROUTINE)GetProcAddress(GetModuleHandleW(L"kernel32.dll"), "LoadLibraryW");
    HANDLE t = CreateRemoteThread(p, nullptr, 0, ll, mem, 0, nullptr);
    if (!t) { VirtualFreeEx(p, mem, 0, MEM_RELEASE); CloseHandle(p); return "CreateRemoteThread failed (error " + std::to_string(GetLastError()) + ")."; }
    WaitForSingleObject(t, 10000); DWORD code = 0; GetExitCodeThread(t, &code); CloseHandle(t);
    VirtualFreeEx(p, mem, 0, MEM_RELEASE); CloseHandle(p);
    if (code == 0) return "LoadLibrary returned NULL - the DLL could not be loaded in the game. Likely causes: antivirus/Windows Defender blocking AgeOfClicksTrainerCore.dll (add the trainer folder as an exclusion), the files are still marked 'downloaded from the internet' (right-click each file > Properties > Unblock), or the folder path is not readable by the game.";
    return "";
}

inline std::wstring ExeDir() { wchar_t b[MAX_PATH]; GetModuleFileNameW(nullptr, b, MAX_PATH); std::wstring s = b; return s.substr(0, s.find_last_of(L"\\/") + 1); }
