// Age of Clicks Trainer - ImGui (DX11 + Win32) front-end. SINGLE-PLAYER ONLY.
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include "net.h"
#include "inject.h"
#include "json_lenient.h"
#include "imgui.h"
#include "imgui_impl_win32.h"
#include "imgui_impl_dx11.h"
#include <d3d11.h>
#include <shellapi.h>
#include <shlobj.h>
#include <filesystem>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <functional>
#include <set>
#include <cmath>
#include <zlib.h>
namespace fs = std::filesystem;

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

// ------------------------------------------------------------------ DX11 boilerplate
static ID3D11Device* g_dev = nullptr; static ID3D11DeviceContext* g_ctx = nullptr; static IDXGISwapChain* g_swap = nullptr; static ID3D11RenderTargetView* g_rtv = nullptr;
static void CreateRTV() { ID3D11Texture2D* bb = nullptr; g_swap->GetBuffer(0, IID_PPV_ARGS(&bb)); g_dev->CreateRenderTargetView(bb, nullptr, &g_rtv); bb->Release(); }
static void CleanRTV() { if (g_rtv) { g_rtv->Release(); g_rtv = nullptr; } }
static bool CreateDevice(HWND hwnd) {
    DXGI_SWAP_CHAIN_DESC sd{}; sd.BufferCount = 2; sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM; sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT; sd.OutputWindow = hwnd;
    sd.SampleDesc.Count = 1; sd.Windowed = TRUE; sd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD; sd.Flags = DXGI_SWAP_CHAIN_FLAG_ALLOW_MODE_SWITCH;
    D3D_FEATURE_LEVEL fl; const D3D_FEATURE_LEVEL lv[] = {D3D_FEATURE_LEVEL_11_0, D3D_FEATURE_LEVEL_10_0};
    HRESULT r = D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, 0, lv, 2, D3D11_SDK_VERSION, &sd, &g_swap, &g_dev, &fl, &g_ctx);
    if (r == DXGI_ERROR_UNSUPPORTED) r = D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_WARP, nullptr, 0, lv, 2, D3D11_SDK_VERSION, &sd, &g_swap, &g_dev, &fl, &g_ctx);
    if (r != S_OK) return false; CreateRTV(); return true;
}
static LRESULT WINAPI WndProc(HWND h, UINT m, WPARAM w, LPARAM l) {
    if (ImGui_ImplWin32_WndProcHandler(h, m, w, l)) return true;
    switch (m) {
        case WM_SIZE: if (g_dev && w != SIZE_MINIMIZED) { CleanRTV(); g_swap->ResizeBuffers(0, LOWORD(l), HIWORD(l), DXGI_FORMAT_UNKNOWN, 0); CreateRTV(); } return 0;
        case WM_SYSCOMMAND: if ((w & 0xfff0) == SC_KEYMENU) return 0; break;
        case WM_DESTROY: PostQuitMessage(0); return 0;
    }
    return DefWindowProcW(h, m, w, l);
}

// ------------------------------------------------------------------ config
enum Act { A_AUTOCLICK, A_PAUSE, A_MONEY, A_SPEEDUP, A_SPEEDDOWN, A_UNDO, A_QSAVE, A_QLOAD, A_OVERLAY, A_INFMONEY, A_COUNT };
static const char* kActName[A_COUNT] = {"Toggle auto-clicker", "Pause / resume game", "Add money (amount set below)", "Game speed +1", "Game speed -1", "Undo last modification", "Quick-save state (slot 1)", "Quick-load state (slot 1)", "Toggle compact overlay", "Toggle infinite money"};
static const char* kTabs[] = {"Dashboard", "Economy", "Resources", "Population", "Industry", "Military", "Research", "Territory & Map", "Diplomacy", "Politics", "War & World", "Time & Clicker", "Automation", "Presets", "Save States", "Save Editor", "Console", "Settings"};
enum Tab { T_DASH, T_ECO, T_RES, T_POP, T_IND, T_MIL, T_RSCH, T_TERR, T_DIPL, T_POL, T_WAR, T_TIME, T_AUTO, T_PRE, T_STATE, T_SAVE, T_CON, T_SET, T_COUNT };
static const char* kProfiles[] = {"Full", "Economy", "Research", "AFK", "Custom"};
static const char* kResKeys[] = {"gold","iron","coal","oil","timber","rubber","aluminum","uranium","copper","manpower","steel","fuel","ammo","mechParts","electronics","trucks","consumerGoods","infantry","artillery","tanks","aircraft","ships","nuclearWeapons"};
static const char* kResNames[] = {"Money (gold)","Iron","Coal","Oil","Timber","Rubber","Aluminum","Uranium","Copper","Manpower","Steel","Fuel","Ammunition","Mechanical parts","Electronics","Trucks","Consumer goods (food/supplies)","Infantry","Artillery","Tanks","Aircraft","Ships","Nuclear weapons"};
static const int kResCount = 23;

struct Alert { int res = 0; bool above = false; double thr = 1000; bool on = false; bool fired = false; };
struct Config {
    int vk[A_COUNT] = {VK_F6, VK_F7, VK_F8, 0, 0, VK_F11, VK_F9, VK_F10, 0, 0};
    int profile = 0; bool tabOn[T_COUNT]; bool autoInject = true; float opacity = 0.97f; bool overlay = false; bool overlayTop = true;
    double cps = 15, jitter = 20, clickMul = 1; std::string hotkeyMoney = "1m"; std::string saveDir, extra;
    std::vector<Alert> alerts; bool beep = true;
    Config() { for (auto& b : tabOn) b = true; }
};
static Config cfg; static std::wstring g_exeDir;
static fs::path CfgPath() { return fs::path(g_exeDir) / "AgeOfClicksTrainer.ini"; }
static void SaveCfg() {
    std::ofstream f(CfgPath()); if (!f) return;
    for (int i = 0; i < A_COUNT; i++) f << "vk" << i << "=" << cfg.vk[i] << "\n";
    f << "profile=" << cfg.profile << "\nautoInject=" << cfg.autoInject << "\nopacity=" << cfg.opacity << "\ncps=" << cfg.cps << "\njitter=" << cfg.jitter << "\nclickMul=" << cfg.clickMul << "\nhotkeyMoney=" << cfg.hotkeyMoney << "\nsaveDir=" << cfg.saveDir << "\nbeep=" << cfg.beep << "\noverlayTop=" << cfg.overlayTop << "\n";
    for (int i = 0; i < T_COUNT; i++) f << "tab" << i << "=" << cfg.tabOn[i] << "\n";
    for (auto& a : cfg.alerts) f << "alert=" << a.res << "," << a.above << "," << a.thr << "," << a.on << "\n";
}
static void LoadCfg() {
    std::ifstream f(CfgPath()); std::string l;
    while (std::getline(f, l)) { size_t e = l.find('='); if (e == std::string::npos) continue; std::string k = l.substr(0, e), v = l.substr(e + 1);
        try {
            if (k.rfind("vk", 0) == 0) { int i = atoi(k.c_str() + 2); if (i >= 0 && i < A_COUNT) cfg.vk[i] = atoi(v.c_str()); }
            else if (k.rfind("tab", 0) == 0) { int i = atoi(k.c_str() + 3); if (i >= 0 && i < T_COUNT) cfg.tabOn[i] = v == "1"; }
            else if (k == "profile") cfg.profile = atoi(v.c_str()); else if (k == "autoInject") cfg.autoInject = v == "1"; else if (k == "opacity") cfg.opacity = (float)atof(v.c_str());
            else if (k == "cps") cfg.cps = atof(v.c_str()); else if (k == "jitter") cfg.jitter = atof(v.c_str()); else if (k == "clickMul") cfg.clickMul = atof(v.c_str());
            else if (k == "hotkeyMoney") cfg.hotkeyMoney = v; else if (k == "saveDir") cfg.saveDir = v; else if (k == "beep") cfg.beep = v == "1"; else if (k == "overlayTop") cfg.overlayTop = v == "1";
            else if (k == "alert") { auto p = Split(v, ','); if (p.size() == 4) { Alert a; a.res = atoi(p[0].c_str()); a.above = p[1] == "1"; a.thr = atof(p[2].c_str()); a.on = p[3] == "1"; cfg.alerts.push_back(a); } }
        } catch (...) {}
    }
}
static void ApplyProfile(int p) {
    static const std::set<int> eco = {T_DASH, T_ECO, T_RES, T_IND, T_AUTO, T_PRE, T_STATE, T_CON, T_SET, T_TIME};
    static const std::set<int> rs = {T_DASH, T_ECO, T_RSCH, T_AUTO, T_PRE, T_STATE, T_CON, T_SET, T_TIME};
    static const std::set<int> afk = {T_DASH, T_AUTO, T_TIME, T_PRE, T_SET};
    for (int i = 0; i < T_COUNT; i++) cfg.tabOn[i] = p == 0 || p == 4 ? true : (p == 1 ? eco.count(i) : p == 2 ? rs.count(i) : afk.count(i)) > 0;
}

// ------------------------------------------------------------------ app state
static Net net; static double g_now = 0; static std::vector<std::pair<std::string, std::string>> g_notes;
static std::string g_injectMsg = "Waiting for Age of Clicks to start..."; static std::atomic<bool> g_injecting{false};
static bool g_overlayMode = false;
struct Series { std::deque<std::pair<double, double>> pts; std::vector<float> spark; double lastSpark = 0; };
static std::map<std::string, Series> g_series; static uint64_t g_lastSerial = 0;

static void Cmd(const std::string& c) { net.Submit(c, "cmd"); }
static void Poll(const std::string& cmd, const std::string& tag, double every) { static std::map<std::string, double> nxt; double& n = nxt[tag]; if (g_now >= n) { n = g_now + every; net.Submit(cmd, tag); } }
static bool Ready() { return net.connected && net.gameReady && !net.multiplayer; }
static bool InList(std::string l, const std::string& item) { for (auto& c : l) if (c == '[' || c == ']' || c == '{' || c == '}') c = ','; l = "," + l + ","; return l.find("," + item + ",") != std::string::npos || l.find("," + item + "=") != std::string::npos; }
static bool IsFlag(const std::string& f) { return InList(net.Get("flags"), f); }
static bool IsLocked(const std::string& key) { return InList(net.Get("locks"), key); }
static bool HasGM(const std::string& key) { return InList(net.Get("gm"), key); }
static void SetFlag(const std::string& f, bool on) { Cmd("flag " + f + " " + (on ? "on" : "off")); }
static std::string Human(double v) {
    double a = fabs(v); char b[64];
    if (a >= 1e15) snprintf(b, sizeof b, "%.2fQ", v / 1e15); else if (a >= 1e12) snprintf(b, sizeof b, "%.2fT", v / 1e12); else if (a >= 1e9) snprintf(b, sizeof b, "%.2fB", v / 1e9);
    else if (a >= 1e6) snprintf(b, sizeof b, "%.2fM", v / 1e6); else if (a >= 1e4) snprintf(b, sizeof b, "%.1fK", v / 1e3); else if (a == floor(a)) snprintf(b, sizeof b, "%.0f", v); else snprintf(b, sizeof b, "%.3g", v);
    return b;
}
static std::string Val(const std::string& k) { std::string s = net.Get(k); if (s.empty()) return "-"; char* e = nullptr; double d = strtod(s.c_str(), &e); if (e && *e == 0) return Human(d); return s; }

// ------------------------------------------------------------------ UI helpers
static ImVec4 kDim(0.62f, 0.66f, 0.72f, 1), kAccent(0.30f, 0.62f, 1.0f, 1), kGood(0.35f, 0.85f, 0.5f, 1), kBad(0.95f, 0.38f, 0.38f, 1), kWarn(1.0f, 0.75f, 0.30f, 1);
static void Desc(const char* t) { ImGui::PushStyleColor(ImGuiCol_Text, kDim); ImGui::TextWrapped("%s", t); ImGui::PopStyleColor(); }
static void Badge(const char* t, ImVec4 c) { ImGui::SameLine(); ImGui::PushStyleColor(ImGuiCol_Text, c); ImGui::Text("[%s]", t); ImGui::PopStyleColor(); if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s", strcmp(t, "experimental") == 0 ? "Best-effort feature: it uses game internals that could not be verified offline. Use Undo if the result is odd." : "This feature is mapped to the nearest mechanic the game actually has."); }
static bool Card(const char* id, const char* title, const char* desc, const char* badge = nullptr) {
    ImGui::PushStyleVar(ImGuiStyleVar_ChildRounding, 6); ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(12, 10));
    bool open = ImGui::BeginChild(id, ImVec2(0, 0), ImGuiChildFlags_Borders | ImGuiChildFlags_AutoResizeY, ImGuiWindowFlags_NoScrollbar);
    ImGui::PopStyleVar(2);
    ImGui::PushStyleColor(ImGuiCol_Text, kAccent); ImGui::TextUnformatted(title); ImGui::PopStyleColor();
    if (badge) Badge(badge, strcmp(badge, "experimental") == 0 ? kWarn : kDim);
    if (desc && *desc) Desc(desc); ImGui::Spacing(); return open;
}
static void EndCard() { ImGui::EndChild(); ImGui::Spacing(); }
static std::map<std::string, std::string> g_buf;
static char* Buf(const std::string& id, const char* def = "") { auto& s = g_buf[id]; if (s.empty() && *def) s = def; s.resize(63); return s.data(); }
static std::string BufStr(const std::string& id) { std::string s = g_buf[id]; size_t z = s.find('\0'); if (z != std::string::npos) s.resize(z); return s; }

struct Stat { const char* label; const char* field; const char* target; const char* desc; };
static void EditRow(const Stat& s, bool locks = true) {
    std::string key = std::string(s.target) + "." + s.field, id = "ed_" + key;
    ImGui::PushID(id.c_str());
    ImGui::AlignTextToFramePadding(); ImGui::TextUnformatted(s.label); ImGui::SameLine(210); ImGui::PushStyleColor(ImGuiCol_Text, kGood);
    std::string cur = strcmp(s.target, "country") == 0 ? Val(s.field) : "";
    if (strcmp(s.target, "country") != 0) cur = "(edit)"; ImGui::Text("%-12s", cur.c_str()); ImGui::PopStyleColor();
    ImGui::SameLine(320); ImGui::SetNextItemWidth(120); ImGui::InputText("##v", Buf(id), 64);
    std::string v = BufStr(id); ImGui::SameLine();
    bool can = !v.empty();
    ImGui::BeginDisabled(!can);
    if (ImGui::SmallButton("Set")) Cmd(Fmt("set %s %s %s", s.target, s.field, v.c_str())); ImGui::SameLine();
    if (ImGui::SmallButton("+")) Cmd(Fmt("add %s %s %s", s.target, s.field, v.c_str())); ImGui::SameLine();
    if (ImGui::SmallButton("-")) Cmd(Fmt("add %s %s -%s", s.target, s.field, v.c_str()));
    ImGui::EndDisabled();
    if (locks) {
        bool lk = IsLocked(key); ImGui::SameLine(); if (ImGui::Checkbox("Freeze", &lk)) Cmd(lk ? Fmt("lock %s exact", key.c_str()) : Fmt("lock %s off", key.c_str()));
        if (ImGui::IsItemHovered()) ImGui::SetTooltip("Freeze: keeps this value exactly as it is now, every 40 ms. Un-tick to release.");
        ImGui::SameLine(); if (ImGui::SmallButton("Min")) Cmd(Fmt("lock %s floor %s", key.c_str(), can ? v.c_str() : "0"));
        if (ImGui::IsItemHovered()) ImGui::SetTooltip("Never drop below the typed value (it can still grow). Release with Freeze on/off.");
        ImGui::SameLine(); if (ImGui::SmallButton("Inf")) Cmd(Fmt("lock %s floor 9t", key.c_str()));
        if (ImGui::IsItemHovered()) ImGui::SetTooltip("Infinite: keeps it at 9 trillion minimum so it can never run out.");
    }
    ImGui::PushStyleColor(ImGuiCol_Text, kDim); ImGui::TextWrapped("%s", s.desc); ImGui::PopStyleColor(); ImGui::Separator();
    ImGui::PopID();
}
static void Button(const char* label, const char* tip, const std::string& cmd, ImVec2 sz = ImVec2(0, 0)) {
    if (ImGui::Button(label, sz)) Cmd(cmd); if (tip && ImGui::IsItemHovered()) ImGui::SetTooltip("%s", tip);
}
static bool FlagToggle(const char* label, const char* flag, const char* desc, const char* badge = nullptr) {
    bool on = IsFlag(flag); ImGui::PushID(flag); bool ch = ImGui::Checkbox(label, &on); if (ch) SetFlag(flag, on); if (badge) Badge(badge, kWarn); if (desc) Desc(desc); ImGui::PopID(); return ch;
}
static void NotMapped(const char* what, const char* why) { ImGui::PushStyleColor(ImGuiCol_Text, kDim); ImGui::BulletText("%s - %s", what, why); ImGui::PopStyleColor(); }

// ------------------------------------------------------------------ data tracking / alerts
static double Rate(const std::string& key, double window, const std::string& per = "") {
    auto it = g_series.find(key); if (it == g_series.end() || it->second.pts.size() < 2) return 0;
    auto& p = it->second.pts; auto& b = p.back(); auto* a = &p.front(); for (auto& e : p) if (b.first - e.first <= window) { a = &e; break; }
    double dt = b.first - a->first; if (dt < 0.2) return 0;
    if (per.empty()) return (b.second - a->second) / dt;
    auto jt = g_series.find(per); if (jt == g_series.end() || jt->second.pts.empty()) return 0;
    double d1 = jt->second.pts.back().second, d0 = d1; for (auto& e : jt->second.pts) if (jt->second.pts.back().first - e.first <= window) { d0 = e.second; break; }
    return d1 - d0 > 0 ? (b.second - a->second) / (d1 - d0) : 0;
}
static void TrackStatus() {
    if (net.statusSerial == g_lastSerial) return; g_lastSerial = net.statusSerial;
    auto push = [&](const std::string& k) { std::string sv = net.Get(k); if (sv.empty()) return; double v = atof(sv.c_str()); auto& s = g_series[k]; s.pts.push_back({g_now, v}); while (s.pts.size() > 400 || (!s.pts.empty() && g_now - s.pts.front().first > 12)) s.pts.pop_front();
        if (g_now - s.lastSpark > 1.0) { s.lastSpark = g_now; s.spark.push_back((float)v); if (s.spark.size() > 90) s.spark.erase(s.spark.begin()); } };
    push("days"); for (int i = 0; i < kResCount; i++) push(kResKeys[i]); push("getTotalPopulation"); push("sciencePoints"); push("lastNetGoldIncome");
    for (auto& a : cfg.alerts) { if (!a.on) continue; double v = net.Num(kResKeys[a.res]); bool hit = a.above ? v >= a.thr : v <= a.thr;
        if (hit && !a.fired) { a.fired = true; net.LastToast = Fmt("ALERT: %s %s %s", kResNames[a.res], a.above ? "reached" : "fell to", Human(a.thr).c_str()); net.ToastErr = true; net.toastSerial++; net.AddLog(net.LastToast, true); if (cfg.beep) MessageBeep(MB_ICONEXCLAMATION); }
        if (!hit) a.fired = false; }
}

// ------------------------------------------------------------------ connection / injection
static void DoInject(bool manual) {
    if (g_injecting) return; GameProc g = FindGame();
    if (!g.pid) { g_injectMsg = "Age of Clicks is not running. Start the game first."; return; }
    if (!g.hasJvm) { g_injectMsg = "Game is still starting (JVM not loaded yet)..."; return; }
    if (g.hasCore) { g_injectMsg = "Already injected - connecting..."; return; }
    g_injecting = true; g_injectMsg = "Injecting into process " + std::to_string(g.pid) + "...";
    std::thread([g]() { std::string e = InjectDll(g.pid, g_exeDir + L"AgeOfClicksTrainerCore.dll"); g_injectMsg = e.empty() ? "Injected OK - connecting to the in-game bridge..." : "Injection failed: " + e; g_injecting = false; }).detach();
}
static void AutoInjectTick() {
    static double nextTry = 0; if (!cfg.autoInject || net.connected || g_injecting || g_now < nextTry) return; nextTry = g_now + 2.5; DoInject(false);
}

// ------------------------------------------------------------------ tabs
static void TabDashboard() {
    if (Card("conn", "Connection", "The trainer attaches to the running game by loading a small helper DLL into it (the game is a Java program; the helper talks to its objects). Everything stays on your PC (127.0.0.1).")) {
        ImGui::TextColored(net.connected ? kGood : kBad, "%s", net.connected ? "\xE2\x97\x8F" : "\xE2\x97\x8F"); ImGui::SameLine(); ImGui::TextWrapped("%s", net.stateMsg.c_str());
        Desc(g_injectMsg.c_str());
        if (ImGui::Button("Inject / Connect", ImVec2(160, 0))) DoInject(true);
        if (ImGui::IsItemHovered()) ImGui::SetTooltip("Finds 'Age of Clicks.exe', loads AgeOfClicksTrainerCore.dll into it and connects. Safe to press again.");
        ImGui::SameLine(); ImGui::Checkbox("Auto-inject when the game is detected", &cfg.autoInject);
    } EndCard();
    if (!Ready()) { if (net.multiplayer) ImGui::TextColored(kBad, "Multiplayer detected. Every cheat is blocked. This trainer only works in single-player."); else Desc("Load a single-player game (or start a new one) and the live data below will appear."); return; }
    if (Card("country", "Your country", nullptr)) {
        ImGui::Text("%s  [%s]   Date: %s   Speed level: %s   %s", net.Get("getName").c_str(), net.Get("getTag").c_str(), net.Get("date").c_str(), net.Get("speed").c_str(), net.Get("paused") == "true" ? "(PAUSED)" : "");
        ImGui::Text("Population %s   Happiness %s%%   Workers %s   Army %s   Territory %s   Strength %s", Val("getTotalPopulation").c_str(), Val("getHappinessPercent").c_str(), Val("getWorkersCount").c_str(), Val("getMilitaryCount").c_str(), Val("territorySize").c_str(), Val("calculateTotalStrength").c_str());
        ImGui::Text("Government %s   Science points %s (+%s/day)   Research queue %s   Techs known %s", net.Get("govForm").c_str(), Val("sciencePoints").c_str(), Val("getDailyScienceRate").c_str(), net.Get("queued").c_str(), net.Get("researched").c_str());
        if (net.Get("sandbox") == "true") ImGui::TextColored(kWarn, "Sandbox mode is ON");
    } EndCard();
    if (Card("mon", "Resource monitor", "Live amounts with income/expense rates. 'per sec' is real time over the last few seconds; 'per game day' follows the in-game calendar. Sparklines show the last 90 seconds.")) {
        static bool nz = false; ImGui::Checkbox("Hide zero resources", &nz);
        if (ImGui::BeginTable("rm", 5, ImGuiTableFlags_RowBg | ImGuiTableFlags_SizingStretchProp)) {
            ImGui::TableSetupColumn("Resource", 0, 2.2f); ImGui::TableSetupColumn("Amount", 0, 1.4f); ImGui::TableSetupColumn("per sec", 0, 1.2f); ImGui::TableSetupColumn("per game day", 0, 1.3f); ImGui::TableSetupColumn("trend", 0, 2.f); ImGui::TableHeadersRow();
            for (int i = 0; i < kResCount; i++) { double v = net.Num(kResKeys[i]); if (nz && v == 0) continue; ImGui::TableNextRow();
                ImGui::TableNextColumn(); ImGui::TextUnformatted(kResNames[i]); ImGui::TableNextColumn(); ImGui::TextUnformatted(Human(v).c_str());
                double r = Rate(kResKeys[i], 5), rd = Rate(kResKeys[i], 8, "days"); ImGui::TableNextColumn(); ImGui::TextColored(r > 0 ? kGood : r < 0 ? kBad : kDim, "%s%s", r > 0 ? "+" : "", Human(r).c_str());
                ImGui::TableNextColumn(); ImGui::TextColored(rd > 0 ? kGood : rd < 0 ? kBad : kDim, "%s%s", rd > 0 ? "+" : "", Human(rd).c_str());
                ImGui::TableNextColumn(); auto& sp = g_series[kResKeys[i]].spark; if (sp.size() > 2) { ImGui::PushID(i); ImGui::PlotLines("##s", sp.data(), (int)sp.size(), 0, nullptr, FLT_MAX, FLT_MAX, ImVec2(-1, 22)); ImGui::PopID(); } }
            ImGui::EndTable(); }
    } EndCard();
}

static bool LockToggle(const char* label, const char* key, const char* mode, const char* val, const char* desc) {
    bool on = IsLocked(key); ImGui::PushID(key); bool ch = ImGui::Checkbox(label, &on);
    if (ch) Cmd(on ? Fmt("lock %s %s %s", key, mode, val) : Fmt("lock %s off", key)); if (desc) Desc(desc); ImGui::PopID(); return ch;
}
static void TabEconomy() {
    if (Card("eco1", "Treasury & income", "Direct control of your money. 'Freeze' keeps a value locked, 'Min' stops it falling under the number you typed, 'Inf' keeps it at 9 trillion. Numbers accept 1.5m, 20k, 3b, 2t.")) {
        EditRow({"Money (gold)", "gold", "country", "Your treasury. Set = exact value, + / - = add or remove the typed amount."});
        EditRow({"Base income", "baseGoldIncome", "country", "Base gold income before multipliers. The game recomputes it from your buildings, so use Freeze to keep your value."});
        EditRow({"Gross income (last)", "lastGrossGold", "country", "Income before expenses in the last cycle (the game's tax/trade revenue figure)."});
        EditRow({"Net income (last)", "lastNetGoldIncome", "country", "Last computed net income. Mostly informational - the game overwrites it."});
        EditRow({"Management cost", "lastMgmtCost", "country", "Running cost of your administration (an expense). Freeze at 0 to remove it."});
        EditRow({"Army cost", "lastArmyCost", "country", "Upkeep of your army (an expense). Freeze at 0 to remove it."});
    } EndCard();
    if (Card("eco2", "Budget switches", "One-click behaviours. Each can be turned off again.")) {
        LockToggle("Infinite budget", "country.gold", "floor", "9t", "Keeps your treasury at 9 trillion or more so nothing is ever unaffordable (it also means upgrades, construction and recruitment cost nothing in effect).");
        LockToggle("Freeze money", "country.gold", "exact", "", "Keeps your gold at exactly the amount it has right now - spending is refunded instantly. (Switch off 'Infinite budget' first; they share the same lock.)");
        LockToggle("Freeze income", "country.baseGoldIncome", "exact", "", "Locks your base income at its current value so events or upkeep cannot change it.");
        LockToggle("Freeze expenses at 0", "country.lastMgmtCost", "exact", "0", "Forces management cost to 0 every 40 ms.");
        LockToggle("Freeze army upkeep at 0", "country.lastArmyCost", "exact", "0", "Forces army upkeep cost to 0 every 40 ms.");
        ImGui::Separator(); Desc("Gold gain multiplier: multiplies every increase of your treasury while active (clicks, income, trade).");
        for (double m : {2.0, 5.0, 10.0, 100.0}) { ImGui::SameLine(0, 6); std::string l = Fmt("x%g##g", m); if (ImGui::Button(l.c_str())) Cmd(Fmt("gainmult gold %g", m)); } ImGui::SameLine(); if (ImGui::Button("Off##g")) Cmd("gainmult gold 1");
        if (HasGM("country.gold")) { ImGui::SameLine(); ImGui::TextColored(kGood, "ACTIVE"); }
    } EndCard();
    if (Card("eco3", "Debt, loans & credit", "Market debt is the game's loan from the world market. Credit rating decides how much you can borrow.")) {
        EditRow({"Market debt", "marketDebt", "country", "Total outstanding market loan. Set to 0 or press 'Repay all'."}, false);
        EditRow({"Daily debt payment", "marketDailyPayment", "country", "How much of the loan is paid every day."}, false);
        EditRow({"War reparations owed", "reparationsDebtRemaining", "country", "Reparations you still owe after losing a war."}, false);
        EditRow({"Credit rating", "creditRating", "country", "Your creditworthiness (decimal; higher = better). Affects loan limits and interest."}, true);
        EditRow({"Missed payments", "marketMissedPayments", "country", "How many payments you missed. Reset to 0 to avoid default penalties."}, false);
        ImGui::Text("Current market interest rate: %s    Max market loan: %s", Val("getMarketInterestRate").c_str(), Val("getMaxMarketLoan").c_str());
        Desc("Interest is calculated by the game from your credit rating, so it cannot be typed directly - raise the credit rating to lower it.");
        Button("Instant repay all debts", "Sets market debt, daily payment, reparations and missed payments to 0 and removes your loans.", "debt repay");
        ImGui::SameLine(); Button("Instant bankruptcy", "Sets your gold to -2 billion and marks missed payments, to trigger the game's bankruptcy handling. Use Undo to revert.", "bankrupt on");
        ImGui::SameLine(); Button("Remove bankruptcy", "Resets negative gold, missed payments, default cooldown and debt.", "bankrupt off");
    } EndCard();
    if (Card("eco4", "Taxes, living standard & economy state", nullptr)) {
        EditRow({"Tax rate (target %)", "targetTaxation", "country", "Policy slider for taxation. Higher = more income but lower happiness. Tax revenue itself is derived from this and your workers."}, false);
        EditRow({"Living standard", "livingStandard", "country", "How well off your citizens are. Freeze it to keep it from decaying."});
        EditRow({"Economic cycle value", "economicCycleValue", "country", "The game's boom/bust state (the 'economic state'). Higher is a boom."});
        EditRow({"Economic development", "cycleDevelopment", "country", "Underlying development of your economy cycle."});
    } EndCard();
}

static void TabResources() {
    if (Card("r1", "Global resource tools", "Act on ALL resources at once (raw materials, industrial goods, consumer goods and manpower).")) {
        Desc("Gain multiplier: every increase of any resource is multiplied while active (production, trade, captures).");
        for (double m : {2.0, 5.0, 10.0, 100.0}) { ImGui::SameLine(0, 6); std::string l = Fmt("x%g##rm", m); if (ImGui::Button(l.c_str())) Cmd(Fmt("gainmult resources %g", m)); }
        ImGui::SameLine(); if (ImGui::Button("Off##rm")) Cmd("gainmult resources 1");
        Button("Infinite resources", "Keeps every resource at 9 trillion or more.", "preset infinite_economy"); ImGui::SameLine();
        Button("Release all locks", "Removes every freeze / infinite / gain-multiplier lock.", "unlock all");
        static char amt[64] = "1m"; ImGui::SetNextItemWidth(120); ImGui::InputText("##amt", amt, 64); ImGui::SameLine();
        if (ImGui::Button("Instant resource generation")) { for (auto k : {"iron","coal","oil","timber","rubber","aluminum","uranium","copper","steel","fuel","ammo","mechParts","electronics","trucks","consumerGoods","manpower"}) Cmd(Fmt("add country %s %s", k, amt)); }
        if (ImGui::IsItemHovered()) ImGui::SetTooltip("Adds the typed amount to every resource right now.");
        Desc("'Freeze resources' = use the Freeze box on a single row below, or 'Release all locks' to undo.");
    } EndCard();
    if (Card("r2", "Raw materials", "The raw inputs mined or harvested by your territory: 'raw materials' / 'food' in the game's terms is timber & co. - set each individually.")) {
        EditRow({"Iron", "iron", "country", "Iron ore stockpile."}); EditRow({"Coal", "coal", "country", "Coal stockpile."}); EditRow({"Oil", "oil", "country", "Crude oil stockpile."});
        EditRow({"Timber", "timber", "country", "Timber stockpile."}); EditRow({"Rubber", "rubber", "country", "Rubber stockpile."}); EditRow({"Aluminum", "aluminum", "country", "Aluminum stockpile."});
        EditRow({"Uranium", "uranium", "country", "Uranium stockpile (needed for nuclear weapons)."}); EditRow({"Copper", "copper", "country", "Copper stockpile."});
    } EndCard();
    if (Card("r3", "Industrial goods", "Processed products made in your factories.")) {
        EditRow({"Steel", "steel", "country", "Steel stockpile."}); EditRow({"Fuel", "fuel", "country", "Refined fuel stockpile."}); EditRow({"Ammunition", "ammo", "country", "Ammunition stockpile."});
        EditRow({"Mechanical parts (parts)", "mechParts", "country", "Parts used for vehicles and machines."}); EditRow({"Electronics", "electronics", "country", "Electronic components."}); EditRow({"Trucks", "trucks", "country", "Trucks (logistics)."});
        EditRow({"Consumer goods (food/supplies)", "consumerGoods", "country", "Goods for your population. The game has no separate 'food' - this is the closest."}, true);
    } EndCard();
    if (Card("r4", "Resource deposits", "How rich your territory is in each resource. These fractions scale your raw-material output.", "experimental")) {
        for (auto p : std::vector<std::pair<const char*, const char*>>{{"Iron richness", "ironFrac"}, {"Coal richness", "coalFrac"}, {"Oil richness", "oilFrac"}, {"Timber richness", "timberFrac"}, {"Rubber richness", "rubberFrac"}, {"Aluminum richness", "aluminumFrac"}, {"Uranium richness", "uraniumFrac"}, {"Copper richness", "copperFrac"}})
            EditRow({p.first, p.second, "country", "Deposit share used by the game to compute this resource's output. The game may recalculate it."});
        Button("Recalculate production now", "Asks the game to refresh its resource multipliers immediately.", "recalc");
    } EndCard();
    if (Card("r5", "Resource base production", "Raw production per day before upgrades. The game recalculates it periodically - freeze to keep your number.")) {
        for (auto p : std::vector<std::pair<const char*, const char*>>{{"Iron", "baseIronIncome"}, {"Coal", "baseCoalIncome"}, {"Oil", "baseOilIncome"}, {"Timber", "baseTimberIncome"}, {"Rubber", "baseRubberIncome"}, {"Aluminum", "baseAluminumIncome"}, {"Uranium", "baseUraniumIncome"}, {"Copper", "baseCopperIncome"}, {"Manpower", "baseManpowerIncome"}})
            EditRow({p.first, p.second, "country", "Base daily production of this resource."});
    } EndCard();
}

static void TabPopulation() {
    if (Card("p1", "Population", "Citizens are the base of your economy: workers produce, soldiers fight.")) {
        ImGui::Text("Total population: %s     Workers: %s     Military: %s     Conscripted: %s", Val("getTotalPopulation").c_str(), Val("getWorkersCount").c_str(), Val("getMilitaryCount").c_str(), Val("getConscriptedCount").c_str());
        static char pop[64] = ""; ImGui::SetNextItemWidth(160); ImGui::InputText("Target population", pop, 64); ImGui::SameLine();
        if (ImGui::Button("Set population")) Cmd(Fmt("pop %s", pop)); if (ImGui::IsItemHovered()) ImGui::SetTooltip("Adjusts the game's 'population bonus' so your total population equals the number you typed.");
        EditRow({"Population bonus", "populationBonus", "country", "Flat citizens added on top of the natural population."});
        EditRow({"Growth modifier", "growthModifier", "country", "Population growth multiplier/offset used by the game. Raise for faster growth (Freeze to hold it)."});
        EditRow({"Conscription (workforce split)", "targetConscription", "country", "Percent of people drafted. Lower it for more available workers, raise it for more soldiers - this is the game's 'workforce / available workers' control."}, false);
        EditRow({"Social security (happiness)", "targetSocialSecurity", "country", "Social spending slider. Raising it is the strongest direct way to raise happiness / stability."}, false);
    } EndCard();
    if (Card("p2", "Happiness, unrest & stability", "Happiness itself is calculated by the game from many factors (so it can't be typed directly). These switches attack the inputs.")) {
        ImGui::Text("Happiness now: %s%%", Val("getHappinessPercent").c_str());
        EditRow({"War exhaustion", "warExhaustion", "country", "Fatigue from war - drags happiness down. Set to 0 and freeze to ignore it."});
        EditRow({"Revolution risk", "revolutionRisk", "country", "Risk of a revolution/coup. Freeze at 0 = stability."});
        EditRow({"Strike risk", "strikeRisk", "country", "Chance of workers striking. Freeze at 0."});
        EditRow({"Liberty desire", "libertyDesire", "country", "Desire for independence (relevant for puppets). Freeze at 0."});
        FlagToggle("Suppress unrest (no rebellions)", "norebellion", "Every 40 ms: rebellion stage, revolution risk and strike risk are set to 0 - 'suppress unrest instantly' and 'freeze unrest'.");
        FlagToggle("No epidemics", "noepidemic", "Clears any epidemic and its severity continuously.");
        Button("Max social security", "Sets the social security slider to 100.", "set country targetSocialSecurity 100");
    } EndCard();
    if (Card("p3", "Not available in this game", nullptr)) {
        NotMapped("Set migration", "Age of Clicks has no migration mechanic; use population bonus / growth instead.");
        NotMapped("Freeze population", "just use Freeze on 'Population bonus' + 'Growth modifier'.");
        NotMapped("Set stability", "stability is expressed through happiness, revolution risk and strike risk above.");
    } EndCard();
}

static void TabIndustry() {
    Poll("upgrades", "upgrades", 0.7); std::string raw = net.Payload("upgrades");
    if (Card("i1", "Buildings & upgrades", "Every building the game has, with its level and the cost of the next level. Buy one level, set a level directly, or max everything.")) {
        Button("Max ALL building levels", "Sets every building to the game's maximum level and refreshes incomes. Use Undo to revert.", "maxbuildings"); ImGui::SameLine();
        static char lv[16] = "10"; ImGui::SetNextItemWidth(70); ImGui::InputText("##lv", lv, 16); ImGui::SameLine(); if (ImGui::Button("Set ALL to level")) Cmd(Fmt("maxbuildings %s", lv));
        FlagToggle("Instant construction", "instantconstruction", "Advances your construction queue by a huge step every 40 ms so projects finish immediately.", "experimental");
        if (ImGui::BeginTable("up", 7, ImGuiTableFlags_RowBg | ImGuiTableFlags_ScrollY | ImGuiTableFlags_SizingStretchProp, ImVec2(0, 420))) {
            ImGui::TableSetupColumn("Building", 0, 2.5f); ImGui::TableSetupColumn("Group", 0, 0.8f); ImGui::TableSetupColumn("Level", 0, 0.8f); ImGui::TableSetupColumn("Next cost", 0, 1.2f); ImGui::TableSetupColumn("", 0, 0.9f); ImGui::TableSetupColumn("Set level", 0, 1.6f); ImGui::TableSetupColumn("", 0, 0.8f); ImGui::TableHeadersRow();
            for (auto& row : Split(raw, '\x1e')) { auto c = Split(row, '\x1f'); if (c.size() < 7) continue; bool aff = c[6] == "1"; ImGui::TableNextRow(); ImGui::PushID(c[5].c_str());
                ImGui::TableNextColumn(); ImGui::TextColored(aff ? kGood : ImGui::GetStyle().Colors[ImGuiCol_Text], "%s", c[0].c_str()); ImGui::TableNextColumn(); ImGui::TextDisabled("%s", c[4].c_str());
                ImGui::TableNextColumn(); ImGui::Text("%s/%s", c[1].c_str(), c[3].c_str()); ImGui::TableNextColumn(); ImGui::TextColored(aff ? kGood : kDim, "%s", Human(atof(c[2].c_str())).c_str());
                ImGui::TableNextColumn(); if (ImGui::SmallButton("Buy +1")) Cmd("upgrade " + c[5]);
                ImGui::TableNextColumn(); static std::map<std::string, std::string> lb; auto& b = lb[c[5]]; b.resize(8); ImGui::SetNextItemWidth(60); ImGui::InputText("##l", b.data(), 8); ImGui::SameLine();
                if (ImGui::SmallButton("Set")) Cmd(Fmt("setlevel %s %s", c[5].c_str(), b.c_str()));
                ImGui::TableNextColumn(); if (ImGui::SmallButton("Max")) Cmd(Fmt("setlevel %s max", c[5].c_str())); ImGui::PopID(); }
            ImGui::EndTable(); }
        Desc("Green = you can afford the next level right now ('upgrade assistant' highlight).");
    } EndCard();
    if (Card("i2", "Production", nullptr)) {
        Button("Max production (all buildings)", "Same as 'Max ALL building levels': production scales with building level.", "maxbuildings"); ImGui::SameLine();
        Button("Unlock everything (all technologies)", "Unlocks every technology so every production line / building tier is available.", "techs all");
        FlagToggle("Auto-upgrade production buildings", "autobuy", "Production automation: buys the cheapest affordable upgrade every second. Choose groups on the Automation tab.");
    } EndCard();
    if (Card("i3", "Not available in this game", nullptr)) {
        NotMapped("Civilian vs military factories / allocation", "this game uses per-resource buildings (Steel Mill, Munitions Factory, Tank Factory...) instead - use the table above.");
        NotMapped("Set construction speed / remove construction costs", "use 'Instant construction' and 'Infinite budget' (Economy tab).");
        NotMapped("Production efficiency / freeze production", "use Max building levels and resource Freeze.");
    } EndCard();
}

static void TabMilitary() {
    if (Card("m1", "Army size & equipment", "Your armed forces and stockpiles. Units are counted per category; the game derives your strength from them.")) {
        EditRow({"Manpower (recruits)", "manpower", "country", "Available recruits. Raising it lets you recruit instantly."});
        EditRow({"Infantry", "infantry", "country", "Infantry divisions/units in your army."}); EditRow({"Artillery", "artillery", "country", "Artillery pieces."}); EditRow({"Tanks", "tanks", "country", "Armored vehicles."});
        EditRow({"Aircraft", "aircraft", "country", "Aircraft."}); EditRow({"Ships", "ships", "country", "Naval vessels."}); EditRow({"Nuclear weapons", "nuclearWeapons", "country", "Nuclear warheads available to launch."});
        EditRow({"Ammunition stockpile", "ammo", "country", "Ammunition for your army."}); EditRow({"Fuel stockpile", "fuel", "country", "Fuel for vehicles."});
        EditRow({"Military spending (%)", "targetMilitarySpending", "country", "Policy slider for military budget."}, false);
        EditRow({"War economy (%)", "targetWarEconomy", "country", "Policy slider converting the economy to war production."}, false);
    } EndCard();
    if (Card("m2", "Field units (organization & readiness)", "The actual units on the map. Heal restores strength, organization and supply of your units.")) {
        ImGui::Text("Army strength rating: %s", Val("calculateTotalStrength").c_str());
        Button("Restore all my units now", "Sets strength to max and refills organization/supply on all of your map units.", "units heal", ImVec2(220, 0));
        FlagToggle("Freeze army losses (invincible units)", "godunits", "Every 40 ms your units are restored to full strength, organization and supply - they can't die or break.", "experimental");
    } EndCard();
    if (Card("m3", "Military technology", nullptr)) {
        Button("Unlock all military technology", "Researches every technology on the military branch (and prerequisites).", "techs military"); ImGui::SameLine();
        Button("Unlock ALL technology", "Researches everything.", "techs all");
        Button("Max military buildings", "Sets all buildings to max level (includes barracks and factories).", "maxbuildings");
    } EndCard();
    if (Card("m4", "Not available in this game", nullptr)) {
        NotMapped("Instant deployment", "units are placed with the game's own map tools.");
        NotMapped("Edit individual army values", "the unit list below shows each unit's values; changes are made through 'Restore'.");
    } EndCard();
    Poll("units list", "units", 2.0);
    std::string raw = net.Payload("units");
    if (!raw.empty() && Card("m5", "Your units", nullptr)) {
        if (ImGui::BeginTable("ul", 5, ImGuiTableFlags_RowBg | ImGuiTableFlags_ScrollY, ImVec2(0, 220))) {
            ImGui::TableSetupColumn("Unit"); ImGui::TableSetupColumn("Strength"); ImGui::TableSetupColumn("Max"); ImGui::TableSetupColumn("Organization"); ImGui::TableSetupColumn("Supply"); ImGui::TableHeadersRow();
            for (auto& r : Split(raw, '\x1e')) { auto c = Split(r, '\x1f'); if (c.size() < 5) continue; ImGui::TableNextRow(); for (int i = 0; i < 5; i++) { ImGui::TableNextColumn(); ImGui::TextUnformatted(c[i].c_str()); } }
            ImGui::EndTable(); }
    } if (!raw.empty()) EndCard();
}

static void TabResearch() {
    Poll("techs list", "techs", 2.0);
    if (Card("s1", "Research controls", "Science points are spent on technologies. These tools skip or speed that up.")) {
        EditRow({"Science points", "sciencePoints", "country", "Your research points pool. Raise it to afford more technologies; Min keeps a reserve."});
        EditRow({"Science funding (%)", "targetScienceFunding", "country", "Budget slider for science - higher funding = faster research."}, false);
        ImGui::Text("Science per day: %s", Val("getDailyScienceRate").c_str());
        Desc("Research speed multiplier - multiplies every gain of science points while active.");
        for (double m : {2.0, 5.0, 10.0, 100.0}) { ImGui::SameLine(0, 6); std::string l = Fmt("x%g##sm", m); if (ImGui::Button(l.c_str())) Cmd(Fmt("gainmult sciencePoints %g", m)); } ImGui::SameLine(); if (ImGui::Button("Off##sm")) Cmd("gainmult sciencePoints 1");
        FlagToggle("Instant research", "instantresearch", "Anything you put in the research queue is completed immediately (with all prerequisites).");
        ImGui::Separator();
        Button("Unlock ALL technologies", "Researches every technology in the game.", "techs all"); ImGui::SameLine(); Button("Military", "Unlock the whole military branch.", "techs military"); ImGui::SameLine();
        Button("Economy", "Unlock the whole economy branch.", "techs economy"); ImGui::SameLine(); Button("Politics", "Unlock the whole politics branch.", "techs politics"); ImGui::SameLine();
        Button("Reset research", "Forgets ALL researched technologies and clears the queue. Undo available.", "techs reset");
        ImGui::Text("Research focus now: %s", net.Get("focus").c_str()); ImGui::SameLine();
        Button("Focus: economy", "Selects the economy research focus instantly.", "focus economy"); ImGui::SameLine(); Button("military", "Selects the military research focus.", "focus military"); ImGui::SameLine(); Button("politics", "Selects the politics research focus.", "focus politics");
        Desc("Removing research requirements: 'Unlock ALL' + 'Instant research' skip every prerequisite and cost.");
    } EndCard();
    if (Card("s2", "Technology list / queue helper", "Click 'Queue' to add a technology to the research queue (prerequisites are researched with it when you use Unlock). Cheapest researchable ones are highlighted.")) {
        static char flt[64] = ""; static int br = 0; ImGui::SetNextItemWidth(200); ImGui::InputTextWithHint("##tf", "filter by name...", flt, 64); ImGui::SameLine(); ImGui::SetNextItemWidth(140); ImGui::Combo("##br", &br, "All branches\0economy\0military\0politics\0");
        ImGui::SameLine(); ImGui::Text("Queue: %s   Known: %s", net.Get("queued").c_str(), net.Get("researched").c_str());
        std::string raw = net.Payload("techs");
        if (ImGui::BeginTable("tl", 6, ImGuiTableFlags_RowBg | ImGuiTableFlags_ScrollY | ImGuiTableFlags_SizingStretchProp, ImVec2(0, 380))) {
            ImGui::TableSetupColumn("Technology", 0, 3); ImGui::TableSetupColumn("Branch"); ImGui::TableSetupColumn("Epoch"); ImGui::TableSetupColumn("Cost"); ImGui::TableSetupColumn("Status"); ImGui::TableSetupColumn("Actions", 0, 2); ImGui::TableHeadersRow();
            static const char* bn[] = {"", "economy", "military", "politics"};
            for (auto& r : Split(raw, '\x1e')) { auto c = Split(r, '\x1f'); if (c.size() < 6) continue; if (*flt && c[0].find(flt) == std::string::npos) continue; if (br && c[1].find(bn[br]) == std::string::npos) continue;
                bool done = c[4] == "1", can = c[5] == "1"; ImGui::TableNextRow(); ImGui::PushID(c[0].c_str());
                ImGui::TableNextColumn(); ImGui::TextColored(done ? kDim : can ? kGood : ImGui::GetStyle().Colors[ImGuiCol_Text], "%s", c[0].c_str()); ImGui::TableNextColumn(); ImGui::TextUnformatted(c[1].c_str()); ImGui::TableNextColumn(); ImGui::TextUnformatted(c[2].c_str());
                ImGui::TableNextColumn(); ImGui::TextUnformatted(Human(atof(c[3].c_str())).c_str()); ImGui::TableNextColumn(); ImGui::TextUnformatted(done ? "known" : can ? "researchable" : "locked");
                ImGui::TableNextColumn(); ImGui::BeginDisabled(done); if (ImGui::SmallButton("Queue")) Cmd("enqueue " + c[0]); ImGui::SameLine(); if (ImGui::SmallButton("Unlock now")) Cmd("techunlock " + c[0]); ImGui::EndDisabled(); ImGui::PopID(); }
            ImGui::EndTable(); }
        Button("Clear queue", "Empties the research queue.", "dequeue");
    } EndCard();
}

static void TabTerritory() {
    Poll("world", "world", 2.0); std::string raw = net.Payload("world");
    if (Card("t1", "Your territory", "Territory size is counted in map cells. Changing it only changes the number the game uses for economy/population - to actually redraw borders use the game's sandbox editors (button below).")) {
        EditRow({"Territory size", "territorySize", "country", "Size of your country in map cells."}, true);
        EditRow({"Core territory size", "coreTerritorySize", "country", "Part of your land that counts as integrated homeland."}, false);
    } EndCard();
    if (Card("t2", "Sandbox & map editors", "The game ships its own map/country editors in sandbox mode. Turning sandbox on unlocks them (colour editor, borders, spawn / delete / duplicate country, rename, flag, capital). The trainer cannot paint the map itself.")) {
        Button("Enable sandbox mode", "Calls the game's own sandbox switch.", "sandbox on"); ImGui::SameLine(); Button("Disable sandbox mode", "Back to normal rules.", "sandbox off");
        ImGui::TextColored(net.Get("sandbox") == "true" ? kGood : kDim, "Sandbox is %s", net.Get("sandbox") == "true" ? "ON" : "off");
        Desc("Console commands for territory exist too: use the Console tab with 'annex <country>' / 'declareWar <country>' (type 'help' there).");
    } EndCard();
    if (Card("t3", "World countries (map information overlay)", "Ownership & strength of every country. Use the buttons to annex a country (game console command), puppet it, or set relations.")) {
        static char flt[64] = ""; ImGui::SetNextItemWidth(220); ImGui::InputTextWithHint("##wf", "search country / tag...", flt, 64);
        if (ImGui::BeginTable("wt", 8, ImGuiTableFlags_RowBg | ImGuiTableFlags_ScrollY | ImGuiTableFlags_Sortable | ImGuiTableFlags_SizingStretchProp, ImVec2(0, 420))) {
            ImGui::TableSetupColumn("Country", 0, 2.5f); ImGui::TableSetupColumn("Tag"); ImGui::TableSetupColumn("Territory"); ImGui::TableSetupColumn("Gold"); ImGui::TableSetupColumn("Population"); ImGui::TableSetupColumn("Strength"); ImGui::TableSetupColumn("Gov / Status", 0, 1.5f); ImGui::TableSetupColumn("Actions", ImGuiTableColumnFlags_NoSort, 3); ImGui::TableHeadersRow();
            std::vector<std::vector<std::string>> rows; for (auto& r : Split(raw, '\x1e')) { auto c = Split(r, '\x1f'); if (c.size() >= 11) { std::string lo = c[0] + " " + c[1]; std::string lf = flt; auto lw = [](std::string x) { for (auto& ch : x) ch = (char)tolower(ch); return x; }; if (!lf.empty() && lw(lo).find(lw(lf)) == std::string::npos) continue; rows.push_back(c); } }
            if (ImGuiTableSortSpecs* sp = ImGui::TableGetSortSpecs()) if (sp->SpecsCount > 0) { int col = sp->Specs[0].ColumnIndex; bool asc = sp->Specs[0].SortDirection == ImGuiSortDirection_Ascending; int ci[] = {0, 1, 2, 3, 4, 9, 10};
                std::stable_sort(rows.begin(), rows.end(), [&](auto& x, auto& y) { if (col <= 1 || col == 6) return asc ? x[ci[col]] < y[ci[col]] : x[ci[col]] > y[ci[col]]; double a = atof(x[ci[col]].c_str()), b = atof(y[ci[col]].c_str()); return asc ? a < b : a > b; }); }
            int n = 0; for (auto& c : rows) { if (n++ > 400) break; ImGui::TableNextRow(); ImGui::PushID(n); bool me = c[8] == "1";
                ImGui::TableNextColumn(); ImGui::TextColored(me ? kGood : ImGui::GetStyle().Colors[ImGuiCol_Text], "%s%s", c[0].c_str(), me ? " (you)" : ""); ImGui::TableNextColumn(); ImGui::TextUnformatted(c[1].c_str());
                ImGui::TableNextColumn(); ImGui::TextUnformatted(c[2].c_str()); ImGui::TableNextColumn(); ImGui::TextUnformatted(Human(atof(c[3].c_str())).c_str()); ImGui::TableNextColumn(); ImGui::TextUnformatted(Human(atof(c[4].c_str())).c_str());
                ImGui::TableNextColumn(); ImGui::TextUnformatted(Human(atof(c[9].c_str())).c_str()); ImGui::TableNextColumn(); ImGui::Text("%s%s%s", c[10].c_str(), c[6] == "true" ? " ally" : "", c[7] == "true" ? " puppet" : "");
                ImGui::TableNextColumn(); if (!me) { if (ImGui::SmallButton("Annex")) Cmd("console annex " + c[0]); ImGui::SameLine(); if (ImGui::SmallButton("Puppet")) Cmd("puppet on " + c[0]); ImGui::SameLine(); if (ImGui::SmallButton("Free")) Cmd("puppet off " + c[0]);
                    ImGui::SameLine(); if (ImGui::SmallButton("Friend")) Cmd("rel " + c[0] + " 100"); ImGui::SameLine(); if (ImGui::SmallButton("War")) Cmd("console declareWar " + c[0]); }
                ImGui::PopID(); }
            ImGui::EndTable(); }
    } EndCard();
    if (Card("t4", "Not available in this game", nullptr)) {
        NotMapped("Reveal entire map", "the map has no fog of war in this version.");
        NotMapped("Transfer / release / create countries", "use sandbox mode editors or 'annex' above. Direct border painting is done in the game's own editor.");
        NotMapped("Edit land quality", "see Resources > deposits for the data-level equivalent.");
    } EndCard();
}

static void TabDiplomacy() {
    Poll("world", "world", 3.0); std::string raw = net.Payload("world");
    if (Card("d1", "Relations & influence (all countries)", "Relations range from -100 (hostile) to +100 (friendly). These apply to every other country at once; the world table on 'Territory & Map' has per-country buttons.")) {
        static int rel = 100; ImGui::SetNextItemWidth(260); ImGui::SliderInt("Relations", &rel, -100, 100); ImGui::SameLine(); if (ImGui::Button("Apply to ALL")) Cmd(Fmt("rel all %d", rel));
        static int inf = 100; ImGui::SetNextItemWidth(260); ImGui::SliderInt("Influence", &inf, 0, 1000); ImGui::SameLine(); if (ImGui::Button("Apply to ALL##inf")) Cmd(Fmt("influence all %d", inf));
        EditRow({"Diplomatic power (points)", "diplomacyPoints", "country", "Points spent on diplomatic actions."});
        EditRow({"Liberty desire", "libertyDesire", "country", "Independence desire (puppets)."});
        EditRow({"Infamy", "infamy", "country", "How hated you are for aggression. Set 0 and Freeze to remove coalition risk."});
        FlagToggle("No cooldowns (diplomacy / clickers)", "nocooldown", "Clears the cooldown timers of the economy, diplomacy and military click boosters every 40 ms.");
    } EndCard();
    if (Card("d2", "Diplomatic actions", "Quick actions. Peace/war/alliances are performed through the game's own console commands.")) {
        static char who[64] = ""; ImGui::SetNextItemWidth(220); ImGui::InputTextWithHint("##who", "country name", who, 64);
        std::string w = who; ImGui::BeginDisabled(w.empty());
        if (ImGui::Button("Set relation +100")) Cmd("rel " + w + " 100"); ImGui::SameLine(); if (ImGui::Button("Relation -100")) Cmd("rel " + w + " -100"); ImGui::SameLine();
        if (ImGui::Button("Make puppet")) Cmd("puppet on " + w); ImGui::SameLine(); if (ImGui::Button("Free puppet")) Cmd("puppet off " + w); ImGui::SameLine();
        if (ImGui::Button("Declare war")) Cmd("console declareWar " + w); ImGui::SameLine(); if (ImGui::Button("Annex")) Cmd("console annex " + w);
        ImGui::EndDisabled();
        Desc("Alliances, pacts, blocs and 'force peace': not exposed as a reliable single call in this game version. Raise relations to 100 and use the in-game diplomacy screen; those actions then succeed. Check the Console tab ('help') for any extra commands.");
    } EndCard();
}

static void TabPolitics() {
    if (Card("g1", "Government", "Changes your government form (regime) instantly.")) {
        std::string lst = net.Payload("govlist"); if (lst.empty()) Poll("gov list", "govlist", 2.0);
        static int sel = 0; auto items = Split(lst, '\t'); items.erase(std::remove(items.begin(), items.end(), std::string()), items.end());
        if (!items.empty()) { sel = std::min(sel, (int)items.size() - 1); if (ImGui::BeginCombo("Form", items[sel].c_str())) { for (int i = 0; i < (int)items.size(); i++) if (ImGui::Selectable(items[i].c_str(), i == sel)) sel = i; ImGui::EndCombo(); }
            if (ImGui::Button("Change government NOW")) Cmd("gov set " + items[sel]); ImGui::SameLine(); if (ImGui::Button("Set national course only")) Cmd("gov course " + items[sel]); }
        ImGui::Text("Current: %s    Course: %s", net.Get("govForm").c_str(), net.Get("govCourse").c_str());
    } EndCard();
    if (Card("g2", "Political support", "Support for each ideology (0-1). The game normalizes them, so move one up and read the result.")) {
        EditRow({"Democracy", "supportDemocracy", "country", "Support for democracy."}); EditRow({"Authoritarianism", "supportAuthoritarianism", "country", "Support for authoritarian rule."});
        EditRow({"Totalitarianism", "supportTotalitarianism", "country", "Support for totalitarian rule."}); EditRow({"Communism", "supportCommunism", "country", "Support for communism."});
        FlagToggle("Remove political penalties (no rebellions)", "norebellion", "Suppresses rebellion stages, revolution risk and strikes continuously.");
        EditRow({"Rebellion stage", "rebellionStage", "country", "0 = calm. Higher = open rebellion. Set 0 to suppress instantly."}, false);
    } EndCard();
    if (Card("g3", "Not available in this game", nullptr)) {
        NotMapped("Trigger political events / uprisings", "events are generated by the game; use the Console tab if it exposes them.");
        NotMapped("Change regime of other countries", "use the sandbox editors.");
    } EndCard();
}

static void TabWar() {
    if (Card("w1", "War state", "Fatigue and devastation from war.")) {
        EditRow({"War exhaustion", "warExhaustion", "country", "Fatigue from war. 0 = fresh. Freeze at 0 to ignore it."});
        EditRow({"Nuclear devastation", "nuclearDevastation", "country", "Fallout damage. 0 = none."});
        Button("Clear exhaustion & devastation", "Sets both to 0.", "war exhaustion0");
    } EndCard();
    if (Card("w2", "Rules", nullptr)) {
        Button("Disable capitulation (you never surrender)", "Prevents countries - including you - from capitulating.", "war nocapitulation"); ImGui::SameLine(); Button("Enable capitulation", "Back to normal.", "war capitulation");
        Button("Disable AI (freeze all computer countries)", "Computer-controlled countries stop acting.", "war noai"); ImGui::SameLine(); Button("Enable AI", "Back to normal.", "war ai");
        Desc("Force peace / end war / war score / peace conference values: no stable single call exists in this version. Use relations (+100) and the game's own peace screen, or check 'help' in the Console tab.");
    } EndCard();
}

static void TabTime() {
    if (Card("c1", "Auto-clicker", "Presses the game's real 'click' for you (earns click gold exactly like clicking). CPS = clicks per second; randomization varies the rate +/- the given % every 40 ms so it isn't perfectly regular; the multiplier presses several clicks per click.")) {
        bool on = IsFlag("autoclick"); static float cps = (float)cfg.cps, jit = (float)cfg.jitter, mul = (float)cfg.clickMul;
        ImGui::SetNextItemWidth(300); bool c1 = ImGui::SliderFloat("Clicks per second", &cps, 1, 500, "%.0f", ImGuiSliderFlags_Logarithmic);
        ImGui::SetNextItemWidth(300); bool c2 = ImGui::SliderFloat("Randomization (+/- %)", &jit, 0, 90, "%.0f%%");
        ImGui::SetNextItemWidth(300); bool c3 = ImGui::SliderFloat("Click multiplier (clicks per click)", &mul, 1, 1000, "x%.0f", ImGuiSliderFlags_Logarithmic);
        cfg.cps = cps; cfg.jitter = jit; cfg.clickMul = mul;
        if (ImGui::Checkbox("Auto-clicker ON", &on) || ((c1 || c2 || c3) && on)) Cmd(Fmt("autoclick %s %g %g %g", on ? "on" : "off", cps, jit, mul));
        ImGui::SameLine(); Desc(Fmt("Effective rate ~ %.0f clicks/s", on ? cps * mul : 0.0).c_str());
        Desc("Instant clicks: use the buttons below to fire a burst at once.");
        for (int n : {10, 100, 1000, 10000}) { ImGui::SameLine(0, 6); std::string l = Fmt("Click x%d", n); if (ImGui::Button(l.c_str())) Cmd(Fmt("click %d", n)); }
        FlagToggle("No cooldowns (instant clicks of the game's boosters)", "nocooldown", "Clears the cooldown timers of the game's economy/diplomacy/military auto-clicker boosters continuously.");
    } EndCard();
    if (Card("c2", "Game speed", "The game's own speed levels (same as its speed buttons) plus a 'days per tick' multiplier that makes the calendar run faster than the top level.")) {
        ImGui::Text("Current level: %s    Effective speed: %s    Days per tick: %s", net.Get("speed").c_str(), net.Get("effspeed").c_str(), net.Get("dpt").c_str());
        for (int s : {1, 2, 3, 4, 5, 6}) { if (s > 1) ImGui::SameLine(0, 6); std::string l = Fmt("Level %d", s); if (ImGui::Button(l.c_str())) Cmd(Fmt("speed %d", s)); }
        Desc("Levels map to the game's speed buttons (roughly x1, x2, x5, x10...). Use 'Days per tick' below for x25/x50 effects.");
        static int dpt = 1; ImGui::SetNextItemWidth(260); ImGui::SliderInt("Days per tick", &dpt, 1, 50); ImGui::SameLine(); if (ImGui::Button("Apply##dpt")) Cmd(Fmt("dpt %d", dpt)); ImGui::SameLine(); if (ImGui::Button("Reset to 1")) { dpt = 1; Cmd("dpt 1"); }
        ImGui::Separator();
        bool paused = net.Get("paused") == "true"; if (ImGui::Button(paused ? "Resume game" : "Pause game")) Cmd(Fmt("pause %s", paused ? "off" : "on")); ImGui::SameLine();
        FlagToggle("Freeze time (keep paused)", "pauselock", nullptr);
        Desc("Freeze time keeps the game paused even if something tries to resume it (the game's own pause toggle).");
    } EndCard();
    if (Card("c3", "Skip time", "Advances the game clock by running the game's own 'simulate' console command for a number of seconds of simulation.", "experimental")) {
        for (auto p : std::vector<std::pair<const char*, int>>{{"Skip 1 day", 1}, {"Skip 1 month", 30}, {"Skip 1 year", 365}}) { if (ImGui::Button(p.first)) Cmd(Fmt("console simulate %d", p.second)); ImGui::SameLine(); }
        ImGui::NewLine(); Desc("If the number of seconds does not match one day in your version, check 'help' in the Console tab for the exact meaning of simulate.");
    } EndCard();
}

static void TabAutomation() {
    Poll("upgrades", "upgrades", 0.7); std::string raw = net.Payload("upgrades");
    if (Card("a1", "AFK mode", "One switch for hands-off play: auto-clicker + auto-upgrade + auto-research + no cooldowns. Everything stays inside the normal rules of the game (it just presses what you would press).")) {
        bool afk = IsFlag("autoclick") && IsFlag("autobuy") && IsFlag("autoresearch");
        if (ImGui::Checkbox("AFK mode", &afk)) { Cmd(afk ? "preset afk" : "flag autoclick off"); if (!afk) { SetFlag("autobuy", false); SetFlag("autoresearch", false); SetFlag("nocooldown", false); } }
        ImGui::SameLine(); Desc("Use the sliders on 'Time & Clicker' for the CPS.");
    } EndCard();
    if (Card("a2", "Upgrade assistant / production automation", "Every second, buys the cheapest affordable upgrade from the groups you tick. On the Industry tab affordable upgrades are highlighted green.")) {
        static bool g[6] = {true, true, true, true, true, true}; static const char* gn[] = {"eco", "raw", "prod", "mil", "sci", "dip"}; static const char* gl[] = {"Economy", "Raw materials", "Production", "Military", "Science", "Diplomacy"};
        for (int i = 0; i < 6; i++) { if (i) ImGui::SameLine(); ImGui::Checkbox(gl[i], &g[i]); }
        std::string cats; for (int i = 0; i < 6; i++) if (g[i]) cats += std::string(cats.empty() ? "" : ",") + gn[i];
        if (ImGui::Button("Apply groups")) Cmd("opt autobuy " + cats);
        FlagToggle("Auto-upgrade", "autobuy", "Buys upgrades automatically from the selected groups when you can afford them (cheapest first).");
        int aff = 0; for (auto& r : Split(raw, '\x1e')) { auto c = Split(r, '\x1f'); if (c.size() >= 7 && c[6] == "1") aff++; } ImGui::Text("Affordable right now: %d upgrades", aff);
    } EndCard();
    if (Card("a3", "Research queue helper", "Keeps your research queue filled with the cheapest researchable technology.")) {
        static int br = 0; static const char* bn[] = {"all", "economy", "military", "politics"}; ImGui::SetNextItemWidth(160); if (ImGui::Combo("Branch", &br, "All\0Economy\0Military\0Politics\0")) Cmd(Fmt("opt autoresearch %s", bn[br]));
        FlagToggle("Auto-research", "autoresearch", "When the queue has fewer than 3 items, adds the cheapest researchable tech of the chosen branch.");
    } EndCard();
    if (Card("a4", "Auto-collect", nullptr)) {
        Desc("Collecting income in this game is done by clicking (and the game's boosters). Auto-collect = the Auto-clicker ('Time & Clicker') plus 'No cooldowns'.");
        FlagToggle("No cooldowns", "nocooldown", nullptr);
    } EndCard();
    if (Card("a5", "Resource alerts", "Get a toast + sound when a resource reaches a threshold.")) {
        if (ImGui::Button("Add alert")) cfg.alerts.push_back(Alert());
        ImGui::Checkbox("Play sound", &cfg.beep);
        for (size_t i = 0; i < cfg.alerts.size(); i++) { auto& a = cfg.alerts[i]; ImGui::PushID((int)i); ImGui::Checkbox("##on", &a.on); ImGui::SameLine(); ImGui::SetNextItemWidth(180);
            if (ImGui::BeginCombo("##res", kResNames[a.res])) { for (int k = 0; k < kResCount; k++) if (ImGui::Selectable(kResNames[k], k == a.res)) a.res = k; ImGui::EndCombo(); }
            ImGui::SameLine(); ImGui::SetNextItemWidth(110); int dir = a.above ? 1 : 0; if (ImGui::Combo("##dir", &dir, "falls below\0rises above\0")) a.above = dir == 1;
            ImGui::SameLine(); ImGui::SetNextItemWidth(130); float t = (float)a.thr; if (ImGui::InputFloat("##thr", &t, 0, 0, "%.0f")) a.thr = t;
            ImGui::SameLine(); if (ImGui::SmallButton("Remove")) { cfg.alerts.erase(cfg.alerts.begin() + i); ImGui::PopID(); break; } ImGui::PopID(); }
    } EndCard();
}

static void TabPresets() {
    struct P { const char* id; const char* name; const char* desc; };
    static const P ps[] = {
        {"infinite_economy", "Infinite Economy", "Locks your gold and ALL resources at 9 trillion minimum so you can never run out."},
        {"superpower", "Superpower", "Infinite economy + all technologies + all buildings at max + relations 100 with everyone + 5 million of every unit + invincible units."},
        {"tiny_nation", "Tiny Nation", "A hard-mode start: gold 5000, resources 100, no army. (Undo available.)"},
        {"max_research", "Max Research", "All technologies unlocked, x10 science gain, instant research."},
        {"sandbox", "Sandbox", "Turns on the game's sandbox mode (unlocks its editors)."},
        {"god_mode", "God Mode", "Infinite economy, no cooldowns, invincible units, no unrest / epidemics, no capitulation, war exhaustion & devastation held at 0."},
        {"afk", "AFK", "Auto-clicker + auto-upgrade + auto-research + no cooldowns."}};
    Desc("Presets run several actions at once. Every preset first stores an Undo point (except toggles), so you can step back with the Undo button.");
    for (auto& p : ps) { if (Card(p.id, p.name, p.desc)) { std::string l = std::string("Activate ") + p.name; if (ImGui::Button(l.c_str())) Cmd(std::string("preset ") + p.id); } EndCard(); }
    if (Card("pu", "Undo", "Reverts your last modification (up to 40 steps are remembered).")) { ImGui::Text("Undo steps available: %s", net.Get("undo").c_str()); Button("Undo last modification", "Restores all numbers, research and clears locks.", "undo"); } EndCard();
}

// ------------------------------------------------------------------ save states (live) + file backups
static std::vector<fs::path> FindSaveDirs() {
    std::vector<fs::path> roots; auto add = [&](const char* env, const char* sub = "") { const char* e = getenv(env); if (e) roots.push_back(fs::path(e) / sub); };
    GameProc g = FindGame(); if (!g.exePath.empty()) { fs::path d = fs::path(g.exePath).parent_path(); roots.push_back(d); roots.push_back(d.parent_path()); }
    add("APPDATA"); add("LOCALAPPDATA"); add("USERPROFILE", ".prefs"); add("USERPROFILE", "Documents"); add("USERPROFILE", "Saved Games"); add("USERPROFILE", "AppData\\LocalLow"); add("USERPROFILE");
    std::vector<std::pair<fs::file_time_type, fs::path>> hits; std::set<std::string> seen;
    for (auto& r : roots) { std::error_code ec; if (!fs::exists(r, ec)) continue; int budget = 4000;
        for (fs::recursive_directory_iterator it(r, fs::directory_options::skip_permission_denied, ec), end; it != end && budget > 0; it.increment(ec)) { if (ec) break; budget--;
            if (it.depth() > 3) { it.disable_recursion_pending(); continue; } auto p = it->path(); std::string lp = p.string(); for (auto& c : lp) c = (char)tolower(c);
            if (it->is_directory(ec)) { if (lp.find("windows") != std::string::npos || lp.find("microsoft") != std::string::npos || lp.find("node_modules") != std::string::npos || lp.find("runtime") != std::string::npos) it.disable_recursion_pending(); continue; }
            std::string ext = p.extension().string(); for (auto& c : ext) c = (char)tolower(c);
            bool ext_ok = ext == ".sav" || ext == ".save" || ext == ".json" || ext == ".dat" || ext == ".gz" || ext == ".bin" || ext == ".cgs";
            bool name_ok = lp.find("age of clicks") != std::string::npos || lp.find("ageofclicks") != std::string::npos || lp.find("\\cgs") != std::string::npos || lp.find("/cgs") != std::string::npos || lp.find("save") != std::string::npos;
            if (ext_ok && name_ok && lp.find("backups") == std::string::npos) { std::string d = p.parent_path().string(); if (seen.insert(d).second) hits.push_back({fs::last_write_time(p, ec), p.parent_path()}); } } }
    std::sort(hits.begin(), hits.end(), [](auto& a, auto& b) { return a.first > b.first; }); std::vector<fs::path> out; for (auto& h : hits) out.push_back(h.second); return out;
}
static std::vector<fs::path> g_saveDirs; static std::string g_stateMsg;
static fs::path BackupRoot() { return fs::path(g_exeDir) / "backups"; }
static std::string Stamp() { SYSTEMTIME t; GetLocalTime(&t); return Fmt("%04d%02d%02d_%02d%02d%02d", t.wYear, t.wMonth, t.wDay, t.wHour, t.wMinute, t.wSecond); }

static void TabStates() {
    if (Card("v1", "Live save-states (in memory)", "Snapshots of your country's numbers, research and levels - instantly restorable while the game is running. They are lost when the game closes. For permanent copies use the file backups below.")) {
        for (int i = 1; i <= 5; i++) { ImGui::PushID(i); bool has = net.Has(Fmt("slot%d", i)); ImGui::Text("Slot %d: %s", i, has ? "saved" : "empty"); ImGui::SameLine(120); if (ImGui::SmallButton("Save here")) Cmd(Fmt("snapshot %d", i)); ImGui::SameLine(); ImGui::BeginDisabled(!has); if (ImGui::SmallButton("Restore")) Cmd(Fmt("restore %d", i)); ImGui::EndDisabled(); ImGui::PopID(); }
        Button("Undo last modification", "Reverts the last change made by the trainer.", "undo");
    } EndCard();
    if (Card("v2", "Save-file backups (on disk)", "Copies the game's save folder to a timestamped folder next to the trainer, and restores it later. Close the game (or reload the save) before restoring.")) {
        if (g_saveDirs.empty() && cfg.saveDir.empty()) { g_saveDirs = FindSaveDirs(); if (!g_saveDirs.empty()) cfg.saveDir = g_saveDirs[0].string(); }
        static char dir[512]; static bool init = false; if (!init) { snprintf(dir, sizeof dir, "%s", cfg.saveDir.c_str()); init = true; }
        ImGui::SetNextItemWidth(-190); ImGui::InputText("Save folder", dir, sizeof dir); cfg.saveDir = dir; ImGui::SameLine(); if (ImGui::Button("Auto-detect")) { g_saveDirs = FindSaveDirs(); if (!g_saveDirs.empty()) { snprintf(dir, sizeof dir, "%s", g_saveDirs[0].string().c_str()); cfg.saveDir = dir; g_stateMsg = "Found " + std::to_string(g_saveDirs.size()) + " candidate folder(s)."; } else g_stateMsg = "Nothing found automatically - paste the folder path (File Explorer address bar)."; }
        if (g_saveDirs.size() > 1) { ImGui::TextUnformatted("Other candidates:"); for (size_t i = 1; i < g_saveDirs.size() && i < 6; i++) if (ImGui::SmallButton(g_saveDirs[i].string().c_str())) { snprintf(dir, sizeof dir, "%s", g_saveDirs[i].string().c_str()); cfg.saveDir = dir; } }
        if (ImGui::Button("Create backup now")) { std::error_code ec; fs::path d = BackupRoot() / Stamp(); fs::create_directories(d, ec); fs::copy(cfg.saveDir, d, fs::copy_options::recursive | fs::copy_options::overwrite_existing, ec); g_stateMsg = ec ? "Backup failed: " + ec.message() : "Backup saved to " + d.string(); }
        ImGui::SameLine(); if (ImGui::Button("Open backups folder")) { std::error_code ec; fs::create_directories(BackupRoot(), ec); ShellExecuteW(nullptr, L"open", BackupRoot().wstring().c_str(), nullptr, nullptr, SW_SHOW); }
        if (!g_stateMsg.empty()) Desc(g_stateMsg.c_str());
        std::error_code ec; if (fs::exists(BackupRoot(), ec)) { std::vector<fs::path> bs; for (auto& e : fs::directory_iterator(BackupRoot(), ec)) if (e.is_directory()) bs.push_back(e.path()); std::sort(bs.rbegin(), bs.rend());
            for (auto& b : bs) { ImGui::PushID(b.string().c_str()); ImGui::TextUnformatted(b.filename().string().c_str()); ImGui::SameLine(220); if (ImGui::SmallButton("Restore")) { std::error_code e2; fs::copy(b, cfg.saveDir, fs::copy_options::recursive | fs::copy_options::overwrite_existing, e2); g_stateMsg = e2 ? "Restore failed: " + e2.message() : "Restored " + b.filename().string() + " - reload the save in the game."; }
                ImGui::SameLine(); if (ImGui::SmallButton("Delete")) { std::error_code e3; fs::remove_all(b, e3); } ImGui::PopID(); } }
    } EndCard();
}

// ------------------------------------------------------------------ save editor
struct SaveDoc { fs::path path; std::string raw; int kind = 0; /*0 none,1 json,2 gz json,3 binary*/ JV root; std::string err; bool dirty = false; };
static SaveDoc g_doc;
static bool Inflate(const std::string& in, std::string& out) {
    z_stream z{}; if (inflateInit2(&z, 15 + 32) != Z_OK) return false; z.next_in = (Bytef*)in.data(); z.avail_in = (uInt)in.size(); char buf[1 << 16]; int r;
    do { z.next_out = (Bytef*)buf; z.avail_out = sizeof buf; r = inflate(&z, Z_NO_FLUSH); if (r != Z_OK && r != Z_STREAM_END) { inflateEnd(&z); return false; } out.append(buf, sizeof buf - z.avail_out); } while (r != Z_STREAM_END);
    inflateEnd(&z); return true;
}
static bool Deflate(const std::string& in, std::string& out) {
    z_stream z{}; if (deflateInit2(&z, 6, Z_DEFLATED, 15 + 16, 8, Z_DEFAULT_STRATEGY) != Z_OK) return false; z.next_in = (Bytef*)in.data(); z.avail_in = (uInt)in.size(); char buf[1 << 16]; int r;
    do { z.next_out = (Bytef*)buf; z.avail_out = sizeof buf; r = deflate(&z, Z_FINISH); out.append(buf, sizeof buf - z.avail_out); } while (r != Z_STREAM_END && r == Z_OK); deflateEnd(&z); return r == Z_STREAM_END;
}
static void LoadDoc(const fs::path& p) {
    g_doc = SaveDoc(); g_doc.path = p; std::ifstream f(p, std::ios::binary); std::stringstream ss; ss << f.rdbuf(); g_doc.raw = ss.str();
    std::string text = g_doc.raw; bool gz = text.size() > 2 && (unsigned char)text[0] == 0x1f && (unsigned char)text[1] == 0x8b;
    if (gz) { std::string o; if (!Inflate(g_doc.raw, o)) { g_doc.kind = 3; g_doc.err = "Corrupt gzip data."; return; } text = o; }
    size_t i = 0; while (i < text.size() && isspace((unsigned char)text[i])) i++;
    if (i < text.size() && (text[i] == '{' || text[i] == '[')) { std::string e; if (JParse(text, g_doc.root, e)) { g_doc.kind = gz ? 2 : 1; return; } g_doc.err = "Looks like JSON but could not be parsed: " + e; }
    g_doc.kind = 3; if (g_doc.err.empty()) g_doc.err = "This save is not JSON text (it is a binary format). The file editor can't safely edit it - use the live editing tabs while the game is running, then save in-game.";
}
static void DrawJV(JV& v, const std::string& name, int depth, const std::string& flt) {
    ImGui::PushID(&v);
    if (v.t == JV::Obj || v.t == JV::Arr) {
        size_t n = v.t == JV::Obj ? v.o.size() : v.a.size(); std::string lab = Fmt("%s  {%zu}", name.c_str(), n);
        if (depth == 0) ImGui::SetNextItemOpen(true, ImGuiCond_Once);
        if (ImGui::TreeNode(lab.c_str())) { size_t lim = std::min<size_t>(n, 300);
            for (size_t i = 0; i < lim; i++) { if (v.t == JV::Obj) DrawJV(v.o[i].second, v.o[i].first, depth + 1, flt); else DrawJV(v.a[i], Fmt("[%zu]", i), depth + 1, flt); }
            if (n > lim) ImGui::TextDisabled("... %zu more (use the search box)", n - lim); ImGui::TreePop(); }
    } else {
        ImGui::AlignTextToFramePadding(); ImGui::Text("%s", name.c_str()); ImGui::SameLine(300); ImGui::SetNextItemWidth(260);
        if (v.t == JV::Bool) { if (ImGui::Checkbox("##b", &v.b)) g_doc.dirty = true; }
        else if (v.t == JV::Num) { static std::map<const void*, std::string> eb; auto& b = eb[&v]; if (b.empty()) { b = v.num; } b.resize(std::max<size_t>(b.size(), 40)); if (ImGui::InputText("##n", b.data(), 40)) { std::string t = b.c_str(); char* e = nullptr; double d = strtod(t.c_str(), &e); if (e && *e == 0 && !t.empty()) { v.n = d; v.num = t; g_doc.dirty = true; } } }
        else if (v.t == JV::Str) { std::string tmp = v.s; tmp.resize(std::max<size_t>(tmp.size() + 256, 512)); if (ImGui::InputText("##s", tmp.data(), tmp.size())) { v.s = tmp.c_str(); g_doc.dirty = true; } }
        else ImGui::TextDisabled("null");
    }
    ImGui::PopID();
}
static void Flatten(JV& v, const std::string& path, const std::string& flt, std::vector<std::pair<std::string, JV*>>& out) {
    if (out.size() > 2000) return;
    if (v.t == JV::Obj) for (auto& kv : v.o) Flatten(kv.second, path + "/" + kv.first, flt, out);
    else if (v.t == JV::Arr) for (size_t i = 0; i < v.a.size(); i++) Flatten(v.a[i], path + "/" + std::to_string(i), flt, out);
    else { std::string a = path, f = flt; for (auto& c : a) c = (char)tolower(c); for (auto& c : f) c = (char)tolower(c); if (a.find(f) != std::string::npos) out.push_back({path, &v}); }
}
static void TabSaveEditor() {
    if (Card("e0", "Save-file editor", "Opens a save file from disk, lets you edit every value, and writes it back (a backup of the original is made first). CLOSE THE GAME (or load a different save) before editing the file that is currently open in the game, otherwise the game may overwrite it. This editor works on JSON saves (plain or gzip-compressed).")) {
        static char dir[512]; static bool init = false; if (!init) { snprintf(dir, sizeof dir, "%s", cfg.saveDir.c_str()); init = true; }
        ImGui::SetNextItemWidth(-190); ImGui::InputText("Save folder", dir, sizeof dir); ImGui::SameLine(); if (ImGui::Button("Auto-detect##e")) { g_saveDirs = FindSaveDirs(); if (!g_saveDirs.empty()) snprintf(dir, sizeof dir, "%s", g_saveDirs[0].string().c_str()); }
        cfg.saveDir = dir; std::error_code ec; std::vector<fs::path> files; if (fs::exists(cfg.saveDir, ec)) for (auto& e : fs::directory_iterator(cfg.saveDir, ec)) if (e.is_regular_file()) files.push_back(e.path());
        std::sort(files.begin(), files.end(), [&](auto& a, auto& b) { std::error_code e1; return fs::last_write_time(a, e1) > fs::last_write_time(b, e1); });
        static int sel = -1; ImGui::SetNextItemWidth(420); if (ImGui::BeginCombo("File", sel >= 0 && sel < (int)files.size() ? files[sel].filename().string().c_str() : "choose a save...")) { for (int i = 0; i < (int)files.size() && i < 200; i++) if (ImGui::Selectable(files[i].filename().string().c_str(), i == sel)) { sel = i; LoadDoc(files[i]); } ImGui::EndCombo(); }
        ImGui::SameLine(); if (ImGui::Button("Reload") && sel >= 0 && sel < (int)files.size()) LoadDoc(files[sel]);
    } EndCard();
    if (g_doc.kind == 0) return;
    if (g_doc.kind == 3) { ImGui::TextColored(kWarn, "%s", g_doc.err.c_str()); ImGui::Text("File: %s  (%zu bytes)", g_doc.path.filename().string().c_str(), g_doc.raw.size()); return; }
    ImGui::Text("%s  -  %s%s", g_doc.path.filename().string().c_str(), g_doc.kind == 2 ? "gzip JSON" : "JSON", g_doc.dirty ? "   (modified)" : "");
    static char flt[128] = ""; ImGui::SetNextItemWidth(300); ImGui::InputTextWithHint("##sf", "search keys, e.g. gold, iron, population...", flt, 128);
    ImGui::SameLine(); ImGui::BeginDisabled(!g_doc.dirty);
    if (ImGui::Button("Save (backup first)")) { std::string o; JWrite(g_doc.root, o); if (g_doc.kind == 2) { std::string z; if (Deflate(o, z)) o = z; }
        std::error_code ec; fs::path bd = BackupRoot() / ("edit_" + Stamp()); fs::create_directories(bd, ec); fs::copy_file(g_doc.path, bd / g_doc.path.filename(), ec); std::ofstream f(g_doc.path, std::ios::binary | std::ios::trunc); f.write(o.data(), (std::streamsize)o.size()); g_doc.dirty = false; g_stateMsg = "Saved. Backup in " + bd.string(); }
    ImGui::EndDisabled(); if (!g_stateMsg.empty()) Desc(g_stateMsg.c_str());
    ImGui::BeginChild("tree", ImVec2(0, 0), ImGuiChildFlags_Borders);
    if (*flt) { std::vector<std::pair<std::string, JV*>> out; Flatten(g_doc.root, "", flt, out); for (auto& o : out) DrawJV(*o.second, o.first, 1, flt); if (out.size() > 2000) ImGui::TextDisabled("Showing first 2000 matches"); }
    else DrawJV(g_doc.root, "root", 0, flt);
    ImGui::EndChild();
}

static void TabConsole() {
    if (Card("k1", "Game console & raw commands", "Runs the GAME's own debug console (type 'help'). Prefix with '!' to send a raw trainer-bridge command instead (for troubleshooting).")) {
        static char in[256] = ""; ImGui::SetNextItemWidth(-260); bool enter = ImGui::InputText("##con", in, 256, ImGuiInputTextFlags_EnterReturnsTrue); ImGui::SameLine();
        if ((ImGui::Button("Run") || enter) && *in) { std::string c = in; Cmd(c[0] == '!' ? c.substr(1) : "console " + c); in[0] = 0; ImGui::SetKeyboardFocusHere(-1); }
        ImGui::SameLine(); if (ImGui::Button("help")) Cmd("console help"); ImGui::SameLine(); if (ImGui::Button("Bridge diag")) Cmd("diag");
    } EndCard();
    ImGui::BeginChild("log", ImVec2(0, 0), ImGuiChildFlags_Borders); std::lock_guard<std::mutex> l(net.mu);
    for (auto& e : net.log) { ImGui::PushStyleColor(ImGuiCol_Text, e.err ? kBad : ImGui::GetStyle().Colors[ImGuiCol_Text]); ImGui::TextWrapped("[%s] %s", e.time.c_str(), e.text.c_str()); ImGui::PopStyleColor(); }
    if (ImGui::GetScrollY() >= ImGui::GetScrollMaxY() - 5) ImGui::SetScrollHereY(1.0f);
    ImGui::EndChild();
}

static int g_capture = -1;
static void TabSettings() {
    if (Card("o1", "Profiles", "A profile chooses which tabs are visible. 'Custom' lets you tick them yourself.")) {
        ImGui::SetNextItemWidth(200); if (ImGui::Combo("Profile", &cfg.profile, "Full\0Economy\0Research\0AFK\0Custom\0")) { ApplyProfile(cfg.profile); if (cfg.profile == 3) Cmd("preset afk"); }
        if (cfg.profile == 4) for (int i = 1; i < T_COUNT - 1; i++) { ImGui::Checkbox(kTabs[i], &cfg.tabOn[i]); if (i % 4) ImGui::SameLine(); }
    } EndCard();
    if (Card("o2", "Hotkeys", "Global hotkeys (work while the game window is focused). Click a key box, then press the key you want; Esc clears it.")) {
        for (int i = 0; i < A_COUNT; i++) { ImGui::PushID(i); ImGui::Text("%s", kActName[i]); ImGui::SameLine(300);
            char nm[64] = "(none)"; if (cfg.vk[i]) { UINT sc = MapVirtualKeyA(cfg.vk[i], MAPVK_VK_TO_VSC); if (!GetKeyNameTextA((LONG)(sc << 16), nm, sizeof nm)) snprintf(nm, sizeof nm, "VK %d", cfg.vk[i]); }
            std::string lab = g_capture == i ? "press a key..." : nm; if (ImGui::Button(lab.c_str(), ImVec2(140, 0))) g_capture = i; ImGui::PopID(); }
        char b[64]; snprintf(b, sizeof b, "%s", cfg.hotkeyMoney.c_str()); ImGui::SetNextItemWidth(120); if (ImGui::InputText("Amount for 'Add money'", b, sizeof b)) cfg.hotkeyMoney = b;
        if (g_capture >= 0) { for (int vk = 8; vk < 255; vk++) { if (vk == VK_LBUTTON || vk == VK_RBUTTON || vk == VK_MBUTTON) continue; if (GetAsyncKeyState(vk) & 0x8000) { cfg.vk[g_capture] = vk == VK_ESCAPE ? 0 : vk; g_capture = -1; break; } } }
    } EndCard();
    if (Card("o3", "Window", nullptr)) {
        ImGui::SliderFloat("Opacity", &cfg.opacity, 0.4f, 1.0f); ImGui::Checkbox("Overlay stays on top", &cfg.overlayTop);
        if (ImGui::Button("Compact stats overlay (toggle)")) g_overlayMode = !g_overlayMode;
        if (ImGui::Button("Save settings now")) SaveCfg();
    } EndCard();
    if (Card("o4", "About & safety", nullptr)) {
        Desc("Single-player only: the in-game bridge refuses every write when the game reports a network/multiplayer session. Everything runs locally on 127.0.0.1. Debug log of the injected part: aoc_trainer_dll.log next to the DLL. Many values are recalculated by the game each day - use Freeze/Min if a number snaps back. Always keep a file backup (Save States tab).");
    } EndCard();
}

// ------------------------------------------------------------------ overlay + hotkeys
static void DrawOverlayContent() {
    ImGui::TextColored(kAccent, "%s  %s", net.Get("getName").c_str(), net.Get("date").c_str());
    if (!Ready()) { ImGui::TextWrapped("%s", net.stateMsg.c_str()); return; }
    ImGui::Text("Gold %s  (%s%s/s)", Val("gold").c_str(), Rate("gold", 5) >= 0 ? "+" : "", Human(Rate("gold", 5)).c_str());
    ImGui::Text("Pop %s   Happy %s%%   Army %s", Val("getTotalPopulation").c_str(), Val("getHappinessPercent").c_str(), Val("getMilitaryCount").c_str());
    ImGui::Text("Steel %s  Fuel %s  Ammo %s", Val("steel").c_str(), Val("fuel").c_str(), Val("ammo").c_str());
    ImGui::Text("Territory %s   Science +%s/d", Val("territorySize").c_str(), Val("getDailyScienceRate").c_str());
    if (IsFlag("autoclick")) ImGui::TextColored(kGood, "Auto-clicker ON"); if (net.Get("paused") == "true") ImGui::TextColored(kWarn, "PAUSED");
}
static void Hotkeys() {
    static bool down[A_COUNT] = {}; static HWND self = nullptr; (void)self;
    for (int i = 0; i < A_COUNT; i++) { if (!cfg.vk[i] || g_capture >= 0) continue; bool d = (GetAsyncKeyState(cfg.vk[i]) & 0x8000) != 0; if (d && !down[i]) {
        if (!Ready()) { down[i] = d; continue; }
        switch (i) {
            case A_AUTOCLICK: Cmd(Fmt("autoclick %s %g %g %g", IsFlag("autoclick") ? "off" : "on", cfg.cps, cfg.jitter, cfg.clickMul)); break;
            case A_PAUSE: Cmd(Fmt("pause %s", net.Get("paused") == "true" ? "off" : "on")); break;
            case A_MONEY: Cmd("add country gold " + cfg.hotkeyMoney); break;
            case A_SPEEDUP: Cmd(Fmt("speed %d", (int)net.Num("speed") + 1)); break;
            case A_SPEEDDOWN: Cmd(Fmt("speed %d", std::max(1, (int)net.Num("speed") - 1))); break;
            case A_UNDO: Cmd("undo"); break; case A_QSAVE: Cmd("snapshot 1"); break; case A_QLOAD: Cmd("restore 1"); break;
            case A_OVERLAY: g_overlayMode = !g_overlayMode; break;
            case A_INFMONEY: Cmd(IsLocked("country.gold") ? "lock country.gold off" : "lock country.gold floor 9t"); break; } } down[i] = d; }
}

// ------------------------------------------------------------------ main
int WINAPI WinMain(HINSTANCE hi, HINSTANCE, LPSTR, int) {
    g_exeDir = ExeDir(); LoadCfg(); if (cfg.profile != 4) ApplyProfile(cfg.profile);
    WNDCLASSEXW wc{sizeof wc, CS_CLASSDC, WndProc, 0, 0, hi, nullptr, nullptr, nullptr, nullptr, L"AocTrainer", nullptr}; RegisterClassExW(&wc);
    HWND hwnd = CreateWindowExW(WS_EX_LAYERED, wc.lpszClassName, L"Age of Clicks Trainer (single-player)", WS_OVERLAPPEDWINDOW, 100, 80, 1180, 800, nullptr, nullptr, hi, nullptr);
    if (!CreateDevice(hwnd)) { MessageBoxW(nullptr, L"Could not create a Direct3D 11 device.", L"Error", MB_ICONERROR); return 1; }
    ShowWindow(hwnd, SW_SHOWDEFAULT); UpdateWindow(hwnd);
    IMGUI_CHECKVERSION(); ImGui::CreateContext(); ImGuiIO& io = ImGui::GetIO(); io.IniFilename = nullptr;
    const char* fonts[] = {"C:\\Windows\\Fonts\\segoeui.ttf", "C:\\Windows\\Fonts\\arial.ttf"}; for (auto f : fonts) if (GetFileAttributesA(f) != INVALID_FILE_ATTRIBUTES) { io.Fonts->AddFontFromFileTTF(f, 17.0f); break; }
    ImGui::StyleColorsDark(); ImGuiStyle& st = ImGui::GetStyle(); st.WindowRounding = 0; st.FrameRounding = 4; st.GrabRounding = 4; st.TabRounding = 4; st.ItemSpacing = ImVec2(8, 6); st.FramePadding = ImVec2(8, 4);
    ImVec4* c = st.Colors; c[ImGuiCol_WindowBg] = ImVec4(0.075f, 0.082f, 0.10f, 1); c[ImGuiCol_ChildBg] = ImVec4(0.10f, 0.11f, 0.135f, 1); c[ImGuiCol_Border] = ImVec4(0.20f, 0.22f, 0.27f, 1);
    c[ImGuiCol_FrameBg] = ImVec4(0.14f, 0.15f, 0.19f, 1); c[ImGuiCol_Button] = ImVec4(0.18f, 0.34f, 0.60f, 1); c[ImGuiCol_ButtonHovered] = ImVec4(0.24f, 0.44f, 0.75f, 1); c[ImGuiCol_ButtonActive] = ImVec4(0.20f, 0.38f, 0.66f, 1);
    c[ImGuiCol_Header] = ImVec4(0.18f, 0.34f, 0.60f, 0.6f); c[ImGuiCol_CheckMark] = ImVec4(0.45f, 0.80f, 1.f, 1); c[ImGuiCol_SliderGrab] = kAccent; c[ImGuiCol_TableRowBgAlt] = ImVec4(1, 1, 1, 0.03f);
    ImGui_ImplWin32_Init(hwnd); ImGui_ImplDX11_Init(g_dev, g_ctx);
    net.Start(); LARGE_INTEGER fq, t0; QueryPerformanceFrequency(&fq); QueryPerformanceCounter(&t0);
    int curTab = 0; bool done = false; bool prevOverlay = false; uint64_t toastSeen = 0; double toastUntil = 0; double nextStatus = 0; double nextCfg = 0;
    RECT savedRect{};
    while (!done) {
        MSG msg; while (PeekMessageW(&msg, nullptr, 0, 0, PM_REMOVE)) { TranslateMessage(&msg); DispatchMessageW(&msg); if (msg.message == WM_QUIT) done = true; } if (done) break;
        LARGE_INTEGER t1; QueryPerformanceCounter(&t1); g_now = double(t1.QuadPart - t0.QuadPart) / fq.QuadPart;
        if (g_now > nextStatus && net.connected) { nextStatus = g_now + 0.25; net.Submit("status", "status"); }
        if (g_now > nextCfg) { nextCfg = g_now + 15; SaveCfg(); }
        AutoInjectTick(); TrackStatus(); Hotkeys();
        if (g_overlayMode != prevOverlay) { prevOverlay = g_overlayMode; if (g_overlayMode) { GetWindowRect(hwnd, &savedRect); SetWindowPos(hwnd, cfg.overlayTop ? HWND_TOPMOST : HWND_NOTOPMOST, savedRect.left, savedRect.top, 360, 190, SWP_NOACTIVATE); }
            else SetWindowPos(hwnd, HWND_NOTOPMOST, savedRect.left, savedRect.top, savedRect.right - savedRect.left, savedRect.bottom - savedRect.top, 0); }
        SetLayeredWindowAttributes(hwnd, 0, (BYTE)(255 * (g_overlayMode ? std::min(cfg.opacity, 0.85f) : cfg.opacity)), LWA_ALPHA);
        ImGui_ImplDX11_NewFrame(); ImGui_ImplWin32_NewFrame(); ImGui::NewFrame();
        ImGuiViewport* vp = ImGui::GetMainViewport(); ImGui::SetNextWindowPos(vp->WorkPos); ImGui::SetNextWindowSize(vp->WorkSize);
        ImGui::Begin("main", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoBringToFrontOnFocus);
        if (g_overlayMode) { DrawOverlayContent(); if (ImGui::Button("Full window")) g_overlayMode = false; }
        else {
            ImGui::TextColored(kAccent, "AGE OF CLICKS TRAINER"); ImGui::SameLine(); ImGui::TextColored(net.multiplayer ? kBad : Ready() ? kGood : kWarn, "   \xE2\x97\x8F %s", net.stateMsg.c_str());
            ImGui::SameLine(ImGui::GetWindowWidth() - 230); if (ImGui::Button("Undo")) Cmd("undo"); ImGui::SameLine(); if (ImGui::Button("Overlay")) g_overlayMode = true;
            if (net.multiplayer) { ImGui::PushStyleColor(ImGuiCol_Text, kBad); ImGui::TextWrapped("MULTIPLAYER DETECTED - all cheats are disabled. This trainer is for single-player only."); ImGui::PopStyleColor(); }
            ImGui::BeginChild("nav", ImVec2(190, 0), ImGuiChildFlags_Borders);
            for (int i = 0; i < T_COUNT; i++) { if (!cfg.tabOn[i] && i != T_DASH && i != T_SET) continue; if (ImGui::Selectable(kTabs[i], curTab == i, 0, ImVec2(0, 26))) curTab = i; }
            ImGui::EndChild(); ImGui::SameLine();
            ImGui::BeginChild("content", ImVec2(0, 0), ImGuiChildFlags_None);
            bool needGame = curTab != T_DASH && curTab != T_SET && curTab != T_STATE && curTab != T_SAVE;
            if (needGame && !Ready()) { ImGui::Spacing(); ImGui::TextWrapped("%s", net.multiplayer ? "Blocked: multiplayer detected." : "Waiting for a single-player game. Go to the Dashboard to inject/connect, then load or start a game."); }
            else {
                if (curTab == T_DASH) TabDashboard(); else if (curTab == T_ECO) TabEconomy(); else if (curTab == T_RES) TabResources(); else if (curTab == T_POP) TabPopulation(); else if (curTab == T_IND) TabIndustry();
                else if (curTab == T_MIL) TabMilitary(); else if (curTab == T_RSCH) TabResearch(); else if (curTab == T_TERR) TabTerritory(); else if (curTab == T_DIPL) TabDiplomacy(); else if (curTab == T_POL) TabPolitics();
                else if (curTab == T_WAR) TabWar(); else if (curTab == T_TIME) TabTime(); else if (curTab == T_AUTO) TabAutomation(); else if (curTab == T_PRE) TabPresets(); else if (curTab == T_STATE) TabStates();
                else if (curTab == T_SAVE) TabSaveEditor(); else if (curTab == T_CON) TabConsole(); else TabSettings(); }
            ImGui::EndChild();
        }
        ImGui::End();
        if (net.toastSerial != toastSeen) { toastSeen = net.toastSerial; toastUntil = g_now + 4.0; }
        if (g_now < toastUntil && !g_overlayMode) { ImGui::SetNextWindowPos(ImVec2(vp->WorkPos.x + vp->WorkSize.x - 16, vp->WorkPos.y + vp->WorkSize.y - 16), ImGuiCond_Always, ImVec2(1, 1)); ImGui::SetNextWindowBgAlpha(0.92f);
            ImGui::Begin("toast", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoInputs | ImGuiWindowFlags_NoSavedSettings); ImGui::PushStyleColor(ImGuiCol_Text, net.ToastErr ? kBad : kGood); ImGui::PushTextWrapPos(520); ImGui::TextWrapped("%s", net.LastToast.c_str()); ImGui::PopTextWrapPos(); ImGui::PopStyleColor(); ImGui::End(); }
        ImGui::Render(); const float clear[4] = {0.07f, 0.08f, 0.10f, 1}; g_ctx->OMSetRenderTargets(1, &g_rtv, nullptr); g_ctx->ClearRenderTargetView(g_rtv, clear);
        ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData()); g_swap->Present(1, 0);
    }
    SaveCfg(); net.Stop(); ImGui_ImplDX11_Shutdown(); ImGui_ImplWin32_Shutdown(); ImGui::DestroyContext();
    CleanRTV(); if (g_swap) g_swap->Release(); if (g_ctx) g_ctx->Release(); if (g_dev) g_dev->Release(); DestroyWindow(hwnd); UnregisterClassW(wc.lpszClassName, hi); return 0;
}
