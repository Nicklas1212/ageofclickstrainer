import java.util.*;

/** Command dispatch for the extended (v2) bridge features. Returns null when the command is not handled here. */
class AocExt {
    static String handle(String cmd, String[] a, String line) throws Exception {
        switch (cmd) {
            case "wstats": return AocWorld.wstats();
            case "cinfo": return AocWorld.cinfo(a[1]);
            case "dipl": return AocWorld.dipl(a[1], a[2]);
            case "relpair": return AocWorld.relpair(a[1], a[2], (int) AocBridge.parse(a[3]));
            case "resources": return AocWorld.resources();
            case "rset": return AocWorld.rset(a[1], a[2], AocBridge.parse(a[3]));
            case "rates": return AocWorld.rates();
            case "vx": return AocVars.list(a.length > 1 ? line.substring(2).trim() : "");
            case "vxget": return AocVars.get(line.substring(5).trim());
            case "vxset": return AocVars.set(a[1], line.substring(line.indexOf(a[1], 5) + a[1].length()).trim());
            case "vxreset": return AocVars.reset(a[1]);
            case "vxfind": return AocVars.find(line.substring(6).trim());
            case "mapprobe": return AocMap.probe();
            case "mapuse": return AocMap.use((int) AocBridge.parse(a[1]));
            case "mapdata": return AocMap.data((int) AocBridge.parse(a[1]));
            case "mapkeys": return AocMap.keys();
            case "mapdiag": return AocMap.diag();
            case "cellinfo": return AocMap.cellinfo((int) AocBridge.parse(a[1]), (int) AocBridge.parse(a[2]));
            case "mapset": return AocMap.mapset((int) AocBridge.parse(a[1]), (int) AocBridge.parse(a[2]), (int) AocBridge.parse(a[3]));
            case "classdump": return AocMap.classdump(Arrays.copyOfRange(a, 1, a.length));
            case "plan": return AocPlan.plan(Arrays.copyOfRange(a, 1, a.length));
            case "planapply": return AocPlan.apply(a[1], a.length > 2 && a[2].equals("1"));
            case "version": return "OK|2";
        }
        return null;
    }
}
