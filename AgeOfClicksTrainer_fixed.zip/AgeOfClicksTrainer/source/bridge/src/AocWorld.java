import java.lang.reflect.*;
import java.util.*;
import java.util.concurrent.Callable;

/** World-wide read models: per-country statistics, diplomacy pair info, dynamic resource list. */
class AocWorld {
    static final char RS = '\u001e', US = '\u001f';
    static final String[] STOCK = {"gold","iron","coal","oil","timber","rubber","aluminum","uranium","copper","manpower","steel","fuel","ammo","mechParts","electronics","trucks","consumerGoods","infantry","artillery","tanks","aircraft","ships","nuclearWeapons"};

    @SuppressWarnings("unchecked")
    static Map<String,Object> world() throws Exception { return (Map<String,Object>) AocBridge.call(AocBridge.gm(), "getWorldCountries"); }

    static String wstats() throws Exception {
        Object me = AocBridge.cs(); StringBuilder sb = new StringBuilder("OK|"); boolean first = true;
        for (Map.Entry<String,Object> e : world().entrySet()) {
            Object c = e.getValue(); if (!first) sb.append(RS); first = false;
            sb.append(e.getKey()).append(US).append(AocBridge.read(c, "tag")).append(US).append(AocBridge.read(c, "colorHex")).append(US).append(AocBridge.read(c, "territorySize")).append(US)
              .append(AocBridge.read(c, "gold")).append(US).append(AocBridge.read(c, "getTotalPopulation")).append(US).append(AocBridge.read(c, "calculateTotalStrength")).append(US)
              .append(AocBridge.read(c, "getHappinessPercent")).append(US).append(AocBridge.read(c, "getDynamicGoldIncomePerSec")).append(US).append(AocBridge.read(c, "playerRelation")).append(US)
              .append(AocBridge.read(c, "isAlly")).append(US).append(AocBridge.read(c, "isPuppet")).append(US).append(c == me ? 1 : 0).append(US).append(AocBridge.read(c, "currentForm")).append(US)
              .append(AocBridge.read(c, "manpower")).append(US).append(AocBridge.read(c, "revolutionRisk")).append(US).append(AocBridge.read(c, "warExhaustion")).append(US)
              .append(AocBridge.read(c, "sciencePoints")).append(US).append(AocBridge.read(c, "livingStandard"));
            for (String k : STOCK) sb.append(US).append(AocBridge.read(c, k));
        }
        return sb.toString();
    }

    static String cinfo(String name) throws Exception {
        Object c = AocBridge.countryByName(name); StringBuilder sb = new StringBuilder("OK|name=" + name.replace('_', ' '));
        for (String s : AocBridge.STATS) { Object v = AocBridge.read(c, s); if (v != null) sb.append('\t').append(s).append('=').append(v); }
        for (String s : AocBridge.DERIVED) { Object v = AocBridge.read(c, s); if (v != null) sb.append('\t').append(s).append('=').append(v); }
        Object f = AocBridge.read(c, "currentForm"); if (f != null) sb.append("\tgovForm=").append(f);
        for (String s : new String[]{"colorHex","puppetMasterName","allyOfCountryName","allianceName","populationBonus","happiness"}) { Object v = AocBridge.read(c, s); if (v != null) sb.append('\t').append(s).append('=').append(v); }
        return sb.toString();
    }

    @SuppressWarnings("unchecked")
    static String dipl(String an, String bn) throws Exception {
        Object a = AocBridge.countryByName(an), b = AocBridge.countryByName(bn); String A = String.valueOf(AocBridge.call(a, "getName")), B = String.valueOf(AocBridge.call(b, "getName"));
        StringBuilder sb = new StringBuilder("OK|");
        sb.append("relAB=").append(mapGet(AocBridge.read(a, "aiRelations"), B)).append("\trelBA=").append(mapGet(AocBridge.read(b, "aiRelations"), A));
        sb.append("\tinfluenceAB=").append(mapGet(AocBridge.read(a, "influenceMap"), B)).append("\tinfluenceBA=").append(mapGet(AocBridge.read(b, "influenceMap"), A));
        sb.append("\tpactAB=").append(mapGet(AocBridge.read(a, "nonAggressionPacts"), B)).append("\tpactBA=").append(mapGet(AocBridge.read(b, "nonAggressionPacts"), A));
        sb.append("\talliedA=").append(AocBridge.read(a, "isAlly")).append("\talliedB=").append(AocBridge.read(b, "isAlly"));
        sb.append("\tallyOfA=").append(AocBridge.read(a, "allyOfCountryName")).append("\tallyOfB=").append(AocBridge.read(b, "allyOfCountryName"));
        sb.append("\tallianceA=").append(AocBridge.read(a, "allianceName")).append("\tallianceB=").append(AocBridge.read(b, "allianceName"));
        sb.append("\tpuppetA=").append(AocBridge.read(a, "isPuppet")).append("\tmasterA=").append(AocBridge.read(a, "puppetMasterName"));
        sb.append("\tpuppetB=").append(AocBridge.read(b, "isPuppet")).append("\tmasterB=").append(AocBridge.read(b, "puppetMasterName"));
        sb.append("\tlibertyA=").append(AocBridge.read(a, "libertyDesire")).append("\tlibertyB=").append(AocBridge.read(b, "libertyDesire"));
        sb.append("\tA=").append(A).append("\tB=").append(B);
        return sb.toString();
    }
    static Object mapGet(Object m, String k) { return m instanceof Map ? ((Map<?, ?>) m).get(k) : null; }

    static String relpair(final String an, final String bn, final int v) throws Exception {
        final int val = Math.max(-100, Math.min(100, v));
        return AocBridge.onGame(new Callable<String>() { public String call() throws Exception {
            Object a = AocBridge.countryByName(an), b = AocBridge.countryByName(bn);
            AocBridge.call(a, "setAiRelation", String.valueOf(AocBridge.call(b, "getName")), val); AocBridge.call(b, "setAiRelation", String.valueOf(AocBridge.call(a, "getName")), val);
            AocBridge.detail("relations " + an + " <-> " + bn + " = " + val); return "OK|Relations set to " + val; } });
    }

    /** Resource list taken from the game's own DebugResourceType enum plus any custom resources. */
    @SuppressWarnings("unchecked")
    static String resources() throws Exception {
        Object c = AocBridge.cs(); StringBuilder sb = new StringBuilder("OK|"); Class<?> e = AocBridge.cls(AocBridge.P + "DebugResourceType"); boolean first = true;
        for (Object k : e.getEnumConstants()) {
            Object key = AocBridge.read(k, "key"); if (key == null) key = k.toString().toLowerCase(Locale.ROOT);
            Object amt = null; try { amt = AocBridge.call(c, "getResourceAmount", String.valueOf(key)); } catch (Throwable t) { }
            if (amt == null) amt = AocBridge.read(c, camel(k.toString()));
            if (!first) sb.append(RS); first = false; sb.append(k).append(US).append(key).append(US).append(amt).append(US).append("game");
        }
        Object custom = AocBridge.read(c, "customResourceStocks");
        if (custom instanceof Map) for (Map.Entry<?, ?> en : ((Map<?, ?>) custom).entrySet()) { if (!first) sb.append(RS); first = false; sb.append(en.getKey()).append(US).append(en.getKey()).append(US).append(en.getValue()).append(US).append("custom"); }
        return sb.toString();
    }
    static String camel(String enumName) { StringBuilder sb = new StringBuilder(); boolean up = false; for (char ch : enumName.toLowerCase(Locale.ROOT).toCharArray()) { if (ch == '_') up = true; else { sb.append(up ? Character.toUpperCase(ch) : ch); up = false; } } return sb.toString(); }

    @SuppressWarnings("unchecked")
    static String rset(final String key, final String mode, final double v) throws Exception {
        return AocBridge.onGame(new Callable<String>() { public String call() throws Exception {
            Object c = AocBridge.cs(); Object custom = AocBridge.read(c, "customResourceStocks");
            if (custom instanceof Map && ((Map<?, ?>) custom).containsKey(key)) { Map<Object, Object> m = (Map<Object, Object>) custom; double cur = ((Number) m.get(key)).doubleValue(); double nv = mode.equals("add") ? cur + v : v; m.put(key, (long) nv); AocBridge.detail(key + ": " + AocBridge.fmtNum(cur) + " -> " + AocBridge.fmtNum(nv)); return "OK|" + key + " = " + AocBridge.fmtNum(nv); }
            double cur = ((Number) AocBridge.call(c, "getResourceAmount", key)).doubleValue(); double target = mode.equals("add") ? cur + v : v; long delta = Math.round(target - cur);
            if (delta > 0) AocBridge.call(c, "addResourceAmount", key, delta); else if (delta < 0) AocBridge.call(c, "deductResourceAmount", key, -delta);
            AocBridge.detail(key + ": " + AocBridge.fmtNum(cur) + " -> " + AocBridge.fmtNum(((Number) AocBridge.call(c, "getResourceAmount", key)).doubleValue()));
            return "OK|" + key + " = " + AocBridge.fmtNum(((Number) AocBridge.call(c, "getResourceAmount", key)).doubleValue()); } });
    }

    /** Per-day flows as computed by the game's own resource ledger (private static helpers, reached by reflection). */
    static String rates() throws Exception {
        Object c = AocBridge.cs(); Class<?> L = AocBridge.cls(AocBridge.P + "ResourceLedger"); StringBuilder sb = new StringBuilder("OK|"); boolean first = true;
        Class<?> cc = c.getClass();
        for (String k : STOCK) {
            Object gross = invokeStatic(L, "gross", cc, c, k), delta = invokeStatic(L, "delta", cc, c, k);
            if (!first) sb.append(RS); first = false; sb.append(k).append(US).append(gross == null ? "" : gross).append(US).append(delta == null ? "" : delta);
        }
        return sb.toString();
    }
    static Object invokeStatic(Class<?> k, String name, Class<?> p0, Object a0, String a1) {
        try { Method m = k.getDeclaredMethod(name, p0, String.class); m.setAccessible(true); return m.invoke(null, a0, a1); } catch (Throwable t) { return null; }
    }
}
