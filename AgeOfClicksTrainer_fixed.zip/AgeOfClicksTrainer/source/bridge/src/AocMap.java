import java.lang.reflect.*;
import java.util.*;
import java.util.concurrent.Callable;

/**
 * Map access. The game's map classes are not documented, so this module DISCOVERS grids by type and shape
 * (reflection), samples them, and works out which one holds country ownership. Everything is reported to the UI
 * so the user can see what was found and override the choice.
 */
class AocMap {
    static final char RS = '\u001e', US = '\u001f';
    static class Grid { String path, kind, readerDesc; Object obj; int w, h; Method get2, get1, set3; Object arr; int unique; long min, max; boolean writable; boolean viaSeed; Map<Long,String> map; String ext = "", rejected = "", top = ""; int matched, coverage, distinct; }
    static final List<Grid> cands = new ArrayList<>();
    static Grid cur; static int curIdx = -1;
    static Map<Long,String> keyToCountry = new HashMap<>(); static String extractorDesc = "";

    static Object warManager() throws Exception { return AocBridge.call(AocBridge.gm(), "getWarManager"); }

    static int intField(Object o, String... names) { for (String n : names) { Field f = AocBridge.fld(o.getClass(), n); if (f != null && (f.getType() == int.class || f.getType() == long.class)) try { return ((Number) f.get(o)).intValue(); } catch (Throwable t) { } } return -1; }
    static int intMethod(Object o, String... names) { for (String n : names) for (Method m : o.getClass().getMethods()) if (m.getName().equals(n) && m.getParameterTypes().length == 0 && (m.getReturnType() == int.class || m.getReturnType() == long.class)) try { return ((Number) m.invoke(o)).intValue(); } catch (Throwable t) { } return -1; }

    static Grid describeGrid(String path, Object obj, Object holder) {
        Grid g = new Grid(); g.path = path; g.obj = obj; Class<?> c = obj.getClass(); g.kind = c.getSimpleName();
        g.w = Math.max(intMethod(obj, "getWidth", "width", "getW", "w", "getSizeX", "sizeX", "getCols", "cols"), intField(obj, "width", "w", "sizeX", "cols"));
        g.h = Math.max(intMethod(obj, "getHeight", "height", "getH", "h", "getSizeY", "sizeY", "getRows", "rows"), intField(obj, "height", "h", "sizeY", "rows"));
        for (Method m : c.getMethods()) {
            Class<?>[] p = m.getParameterTypes(); String n = m.getName();
            boolean ret = m.getReturnType() == int.class || m.getReturnType() == byte.class || m.getReturnType() == short.class || m.getReturnType() == long.class || m.getReturnType() == float.class;
            if (ret && p.length == 2 && p[0] == int.class && p[1] == int.class && (n.equals("get") || n.equals("getInt") || n.equals("at") || n.equals("read") || n.equals("getValue") || n.equals("getPixel")) && g.get2 == null) g.get2 = m;
            if (ret && p.length == 1 && p[0] == int.class && (n.equals("get") || n.equals("getInt") || n.equals("at") || n.equals("getValue")) && g.get1 == null) g.get1 = m;
            if (m.getReturnType() == void.class && p.length == 3 && p[0] == int.class && p[1] == int.class && (n.equals("set") || n.equals("put") || n.equals("setInt") || n.equals("write") || n.equals("drawPixel")) && g.set3 == null) g.set3 = m;
        }
        g.writable = g.set3 != null; g.readerDesc = g.get2 != null ? g.get2.getName() + "(x,y)" : g.get1 != null ? g.get1.getName() + "(index)" : "none";
        if (g.w <= 0 && g.h <= 0 && holder != null) { g.w = intField(holder, "mapWidth", "width", "w"); g.h = intField(holder, "mapHeight", "height", "h"); }
        return g;
    }
    static Grid describeArray(String path, Object arr, Object holder) {
        Grid g = new Grid(); g.path = path; g.arr = arr; g.kind = arr.getClass().getComponentType().getSimpleName() + "[" + Array.getLength(arr) + "]"; g.readerDesc = "array index";
        int w = holder == null ? -1 : intField(holder, "mapWidth", "width", "w", "sizeX"), h = holder == null ? -1 : intField(holder, "mapHeight", "height", "h", "sizeY");
        int len = Array.getLength(arr); if (w > 0 && h > 0 && (long) w * h == len) { g.w = w; g.h = h; } else if (w > 0 && len % w == 0) { g.w = w; g.h = len / w; } else return null;
        g.writable = true; return g;
    }
    static long read(Grid g, int x, int y) throws Exception {
        if (g.arr != null) return ((Number) Array.get(g.arr, y * g.w + x)).longValue();
        Object r = g.get2 != null ? g.get2.invoke(g.obj, x, y) : g.get1.invoke(g.obj, y * g.w + x);
        if (r instanceof Float) return Float.floatToIntBits((Float) r); return ((Number) r).longValue();
    }
    static void write(Grid g, int x, int y, int v) throws Exception {
        if (g.arr != null) { Class<?> t = g.arr.getClass().getComponentType(); Object boxed = t == int.class ? (Object) v : t == short.class ? (Object) (short) v : t == byte.class ? (Object) (byte) v : (Object) (long) v; Array.set(g.arr, y * g.w + x, boxed); return; }
        g.set3.invoke(g.obj, x, y, v);
    }
    static boolean usable(Grid g) { return g.w > 8 && g.h > 8 && (g.arr != null || g.get2 != null || g.get1 != null); }

    static void sample(Grid g) {
        Set<Long> u = new HashSet<>(); long mn = Long.MAX_VALUE, mx = Long.MIN_VALUE; int n = 0;
        try { for (int i = 0; i < 4000; i++) { int x = (int) ((i * 7919L) % g.w), y = (int) ((i * 104729L / 3) % g.h); long v = read(g, x, y); u.add(v); mn = Math.min(mn, v); mx = Math.max(mx, v); n++; } } catch (Throwable t) { g.readerDesc += " (read error: " + t.getClass().getSimpleName() + ")"; g.get1 = null; g.get2 = null; g.arr = null; }
        g.unique = u.size(); g.min = n == 0 ? 0 : mn; g.max = n == 0 ? 0 : mx;
    }

    // ---- extractors: ways to turn a country into the integer that the grid stores ----
    static class Ext { String name; Map<Long,String> keys = new HashMap<>(); }
    static List<Ext> extractors() throws Exception {
        List<Ext> out = new ArrayList<>(); Map<String,Object> world = AocWorld.world(); List<Map.Entry<String,Object>> cs = new ArrayList<>(world.entrySet());
        if (cs.isEmpty()) return out;
        for (int form = 0; form < 6; form++) { Ext x = new Ext(); x.name = "colorHex form " + form;
            for (Map.Entry<String,Object> e : cs) { try { long[] f = rgbForms(String.valueOf(AocBridge.read(e.getValue(), "colorHex"))); if (f.length > form) x.keys.put(norm(f[form]), e.getKey()); } catch (Throwable t) { } }
            if (!x.keys.isEmpty()) out.add(x); }
        for (int base = 0; base < 2; base++) { Ext x = new Ext(); x.name = "country order index (" + base + "-based)"; int i = base; for (Map.Entry<String,Object> e : cs) x.keys.put((long) i++, e.getKey()); out.add(x); }
        Set<String> doneF = new HashSet<>(); Class<?> cc = cs.get(0).getValue().getClass();
        for (Class<?> k = cc; k != null && k != Object.class; k = k.getSuperclass()) for (Field f : k.getDeclaredFields()) {
            if (Modifier.isStatic(f.getModifiers()) || !(f.getType() == int.class || f.getType() == long.class) || !doneF.add(f.getName())) continue;
            try { f.setAccessible(true); } catch (Throwable t) { continue; } Ext x = new Ext(); x.name = "field " + f.getName();
            for (Map.Entry<String,Object> e : cs) { try { x.keys.put(norm(((Number) f.get(e.getValue())).longValue()), e.getKey()); } catch (Throwable t) { } }
            if (x.keys.size() >= 2) out.add(x); }
        Set<String> doneM = new HashSet<>();
        for (Method m : cc.getMethods()) { if (m.getParameterTypes().length != 0 || !(m.getReturnType() == int.class || m.getReturnType() == long.class) || m.getDeclaringClass() == Object.class || !doneM.add(m.getName())) continue;
            String ln = m.getName().toLowerCase(Locale.ROOT); if (!(ln.contains("id") || ln.contains("index") || ln.contains("color") || ln.contains("code") || ln.contains("owner") || ln.contains("number"))) continue;
            Ext x = new Ext(); x.name = "getter " + m.getName() + "()";
            for (Map.Entry<String,Object> e : cs) { try { x.keys.put(norm(((Number) m.invoke(e.getValue())).longValue()), e.getKey()); } catch (Throwable t) { } }
            if (x.keys.size() >= 2) out.add(x); }
        return out;
    }
    // ---- pixel-count sources: the game keeps how many map pixels each country owns. Matching those numbers to the
    // histogram of a grid identifies which grid value is which country, whatever the encoding of the value is. ----
    static class Src { String name; Map<String,Double> target = new HashMap<>(); }
    static double num(Object o, String field) { if (o == null) return -1; Field f = AocBridge.fld(o.getClass(), field); if (f == null) return -1; try { f.setAccessible(true); Object v = f.get(o); return v instanceof Number ? ((Number) v).doubleValue() : -1; } catch (Throwable t) { return -1; } }
    static List<Src> countSources() throws Exception {
        List<Src> out = new ArrayList<>(); Map<String,Object> world = AocWorld.world();
        for (String fn : new String[]{"territorySize", "coreTerritorySize", "mapPixels"}) { Src s = new Src(); s.name = fn;
            for (Map.Entry<String,Object> e : world.entrySet()) { double v = num(e.getValue(), fn); if (v > 0) s.target.put(e.getKey(), v); }
            if (s.target.size() >= 3) out.add(s); }
        try { Object gm = AocBridge.gm(); Field f = AocBridge.fld(gm.getClass(), "lastCountryPixelCounts");
            if (f != null) { f.setAccessible(true); Object m = f.get(gm); if (m instanceof Map) { Src s = new Src(); s.name = "lastCountryPixelCounts"; Map<?,?> mm = (Map<?,?>) m;
                for (Map.Entry<String,Object> e : world.entrySet()) { Object v = mm.get(e.getKey()); if (v == null) v = mm.get(String.valueOf(AocBridge.read(e.getValue(), "tag"))); if (v instanceof Number && ((Number) v).doubleValue() > 0) s.target.put(e.getKey(), ((Number) v).doubleValue()); }
                if (s.target.size() >= 3) out.add(s); } } } catch (Throwable t) { }
        return out;
    }
    static Map<Long,String> matchByCount(Map<Long,Integer> counts, int step, Src src) {
        double scale = (double) step * step; List<Object[]> pairs = new ArrayList<>();
        for (Map.Entry<Long,Integer> c : counts.entrySet()) { if (c.getKey() == 0 || c.getValue() < 3) continue; double sc = c.getValue() * scale, tol = Math.max(0.03, 3.0 / Math.sqrt(c.getValue()));
            for (Map.Entry<String,Double> t : src.target.entrySet()) { double err = Math.abs(sc - t.getValue()) / t.getValue(); if (err <= tol) pairs.add(new Object[]{err, c.getKey(), t.getKey()}); } }
        Collections.sort(pairs, (a, b) -> Double.compare((Double) a[0], (Double) b[0])); Map<Long,String> m = new HashMap<>(); Set<String> used = new HashSet<>();
        for (Object[] p : pairs) { Long v = (Long) p[1]; String n = (String) p[2]; if (m.containsKey(v) || used.contains(n)) continue; m.put(v, n); used.add(n); }
        return m;
    }
    static long xform(long v, int t) { return t == 0 ? v : t == 1 ? (v & 0xFFFFFFL) : (v >>> 8) & 0xFFFFFFL; }
    static final String[] TNAME = {"", " (low 24 bits)", " (>>8)"};

    /** Counts values over the grid, then finds the extractor+transform that explains the most distinct values. Fills g.map. */
    static void evaluate(Grid g, List<Ext> exts, List<Src> srcs) {
        g.map = null; g.matched = 0; g.coverage = 0; g.ext = "";
        Map<Long,Integer> counts = new HashMap<>(); int n = 0; int step = Math.max(1, (int) Math.sqrt((double) g.w * g.h / (g.arr != null ? 1500000 : 400000)));
        try { for (int y = 0; y < g.h; y += step) for (int x = 0; x < g.w; x += step) { counts.merge(norm(read(g, x, y)), 1, Integer::sum); n++; } } catch (Throwable t) { g.ext = "read error"; return; }
        g.distinct = counts.size(); g.top = topValues(counts, 8);
        if (counts.size() > 20000) return;
        int bestM = 0; long bestCells = 0;
        for (Ext e : exts) for (int t = 0; t < 3; t++) { Map<Long,String> m = new HashMap<>(); long cells = 0, nonZero = 0;
            for (Map.Entry<Long,Integer> c : counts.entrySet()) { if (c.getKey() == 0) continue; nonZero += c.getValue(); String name = e.keys.get(xform(c.getKey(), t)); if (name != null) { m.put(c.getKey(), name); cells += c.getValue(); } }
            Set<String> names = new HashSet<>(m.values()); int dm = names.size();
            if (dm > bestM || (dm == bestM && cells > bestCells)) { bestM = dm; bestCells = cells; g.map = m; g.ext = e.name + TNAME[t]; g.matched = dm; g.coverage = nonZero == 0 ? 0 : (int) (100 * cells / nonZero); } }
        for (Src sr : srcs) { Map<Long,String> m = matchByCount(counts, step, sr); long cells = 0, nonZero = 0; for (Map.Entry<Long,Integer> c : counts.entrySet()) { if (c.getKey() == 0) continue; nonZero += c.getValue(); if (m.containsKey(c.getKey())) cells += c.getValue(); }
            int dm = new HashSet<>(m.values()).size(); if (dm > bestM + 1 || (dm > bestM && g.map == null)) { bestM = dm; bestCells = cells; g.map = m; g.ext = "pixel counts (" + sr.name + ")"; g.matched = dm; g.coverage = nonZero == 0 ? 0 : (int) (100 * cells / nonZero); } }
        int need = Math.max(3, exts.isEmpty() ? 3 : (int) (0.10 * exts.get(0).keys.size()));
        if (g.ext.startsWith("country order index") && exts.size() > 0) need = Math.max(5, (int) (0.5 * AocWorldSize()));
        if (bestM >= need && g.coverage < 15) { g.rejected = "only " + g.coverage + "% of the non-empty cells belong to known countries"; g.map = null; return; }
        if (bestM < need) { g.rejected = "only " + bestM + " countries matched (need " + need + ")"; g.map = null; g.matched = bestM; }
    }
    static int AocWorldSize() { try { return AocWorld.world().size(); } catch (Throwable t) { return 0; } }
    static String topValues(Map<Long,Integer> counts, int n) {
        List<Map.Entry<Long,Integer>> l = new ArrayList<>(counts.entrySet()); Collections.sort(l, (a, b) -> b.getValue() - a.getValue()); StringBuilder sb = new StringBuilder();
        for (int i = 0; i < Math.min(n, l.size()); i++) sb.append(l.get(i).getKey()).append('x').append(l.get(i).getValue()).append(' '); return sb.toString().trim();
    }


    // ---- seed discovery: find the game's seed, then find the objects that hold the same seed (the map generator / map data share it) ----
    static long seedValue; static boolean haveSeed; static final List<String> seedHolders = new ArrayList<>(); static final List<Object> seedHolderObjs = new ArrayList<>();
    static void findSeed() {
        haveSeed = false; seedValue = 0;
        try { Object r = AocBridge.call(AocBridge.gm(), "getGameSeed"); if (r instanceof Number) { seedValue = ((Number) r).longValue(); haveSeed = true; } } catch (Throwable t) { }
        if (!haveSeed || seedValue == 0) try { Field f = AocBridge.gm().getClass().getDeclaredField("pendingGameSeed"); f.setAccessible(true); long v = f.getLong(null); if (v != 0) { seedValue = v; haveSeed = true; } } catch (Throwable t) { }
    }
    static boolean bfsType(Object v) { String n = v.getClass().getName(); return n.startsWith("ru.ius.david.cgs") && !v.getClass().isEnum() || v instanceof Collection || v instanceof Map || (v.getClass().isArray() && !v.getClass().getComponentType().isPrimitive()); }
    static void findSeedHolders(Object gm, Object wm) {
        seedHolders.clear(); seedHolderObjs.clear(); if (!haveSeed || seedValue == 0) return;
        Set<Object> seen = Collections.newSetFromMap(new IdentityHashMap<Object, Boolean>()); ArrayDeque<Object[]> q = new ArrayDeque<>();
        if (gm != null) q.add(new Object[]{"gm", gm, 0}); if (wm != null) q.add(new Object[]{"wm", wm, 0});
        for (String cn : new String[]{"MapCache", "HomelandMap", "MapTopology", "TerritoryMask", "TerritoryRenderer", "PaintedMapSurface", "NativeGrids", "MapModeManager", "IntegrationMask"}) try {
            Class<?> c = AocBridge.cls("ru.ius.david.cgs." + cn);
            for (Field f : c.getDeclaredFields()) { if (!Modifier.isStatic(f.getModifiers()) || f.getType().isPrimitive()) continue; try { f.setAccessible(true); Object v = f.get(null); if (v != null && bfsType(v)) q.add(new Object[]{"static:" + cn + "." + f.getName(), v, 0}); } catch (Throwable t) { } }
        } catch (Throwable t) { }
        int visited = 0;
        while (!q.isEmpty() && visited < 30000) {
            Object[] it = q.poll(); String path = (String) it[0]; Object o = it[1]; int d = (Integer) it[2]; if (o == null || !seen.add(o)) continue; visited++;
            if (o instanceof Collection) { int i = 0; for (Object e : (Collection<?>) o) { if (i++ >= 12) break; if (e != null && bfsType(e) && d < 6) q.add(new Object[]{path + "[" + (i - 1) + "]", e, d + 1}); } continue; }
            if (o instanceof Map) { int i = 0; for (Object e : ((Map<?, ?>) o).values()) { if (i++ >= 12) break; if (e != null && bfsType(e) && d < 6) q.add(new Object[]{path + "{" + (i - 1) + "}", e, d + 1}); } continue; }
            if (o.getClass().isArray()) { int len = Math.min(Array.getLength(o), 12); for (int i = 0; i < len; i++) { Object e = Array.get(o, i); if (e != null && bfsType(e) && d < 6) q.add(new Object[]{path + "[" + i + "]", e, d + 1}); } continue; }
            boolean holds = false;
            for (Class<?> k = o.getClass(); k != null && k != Object.class; k = k.getSuperclass()) for (Field f : k.getDeclaredFields()) {
                if (Modifier.isStatic(f.getModifiers())) continue; Class<?> t = f.getType(); Object v;
                try { f.setAccessible(true); if (t == long.class) { if (f.getLong(o) == seedValue) holds = true; continue; } if (t == int.class) { if (seedValue == (long) f.getInt(o) && seedValue != 0) holds = true; continue; } if (t.isPrimitive()) continue; v = f.get(o); } catch (Throwable e) { continue; }
                if (v != null && d < 6 && bfsType(v)) q.add(new Object[]{path + "." + f.getName(), v, d + 1});
            }
            if (holds && o != gm && !o.getClass().getSimpleName().equals("SeededRandom")) { seedHolders.add(path + " (" + o.getClass().getSimpleName() + ")"); seedHolderObjs.add(o); }
        }
    }

    static String probe() throws Exception {
        return AocBridge.onGame(new Callable<String>() { public String call() throws Exception {
            cands.clear(); Object wm = warManager(); Object gm = AocBridge.gm();
            if (wm == null && gm == null) return "ERR|NOMAP|The game has no war/map manager yet.";
            Set<Object> seen = Collections.newSetFromMap(new IdentityHashMap<Object, Boolean>());
            if (wm != null) scan("wm", wm, null, 0, seen); if (gm != null) scan("gm", gm, null, 0, seen);
            findSeed(); findSeedHolders(gm, wm); int plain = cands.size();
            Set<Object> seen2 = Collections.newSetFromMap(new IdentityHashMap<Object, Boolean>());
            for (int i = 0; i < seedHolderObjs.size(); i++) scan("seed:" + seedHolders.get(i).replaceAll(" \\(.*\\)$", ""), seedHolderObjs.get(i), null, 0, seen2);
            for (int i = plain; i < cands.size(); i++) cands.get(i).viaSeed = true;
            for (Iterator<Grid> it = cands.iterator(); it.hasNext();) { Grid g = it.next(); if (!usable(g)) { it.remove(); continue; } sample(g); if (g.arr == null && g.get2 == null && g.get1 == null) it.remove(); }
            if (cands.size() > 40) { Collections.sort(cands, (a, b) -> Integer.compare(b.unique, a.unique)); while (cands.size() > 40) cands.remove(cands.size() - 1); }
            List<Ext> exts = extractors(); List<Src> srcs = countSources(); int best = -1; double bs = 0;
            for (int i = 0; i < cands.size(); i++) { Grid g = cands.get(i); evaluate(g, exts, srcs);
                double sc = g.map == null ? 0 : g.coverage * 1000.0 + g.matched * 10 + (g.viaSeed ? 300 : 0) + (g.kind.contains("Int") ? 1 : 0); if (sc > bs) { bs = sc; best = i; } }
            if (best < 0) { // fallback: most plausible by shape, so the user can still pick manually
                for (int i = 0; i < cands.size(); i++) { Grid g = cands.get(i); if (g.unique >= 3 && g.unique <= 3500 && (best < 0 || g.unique > cands.get(best).unique)) best = i; } }
            cur = best >= 0 ? cands.get(best) : null; curIdx = best; if (cur != null && cur.map != null) { keyToCountry = cur.map; extractorDesc = cur.ext; }
            StringBuilder sb = new StringBuilder("OK|" + curIdx + RS);
            for (int i = 0; i < cands.size(); i++) { Grid g = cands.get(i); String rd = g.readerDesc + (g.viaSeed ? " (found through the game seed)" : "") + " [" + (g.map != null ? "matched " + g.matched + " countries via " + g.ext : g.rejected.isEmpty() ? "no country match" : g.rejected) + "]";
                sb.append(i).append(US).append(g.path).append(US).append(g.kind).append(US).append(g.w).append(US).append(g.h).append(US).append(g.unique).append(US).append(g.min).append(US).append(g.max).append(US).append(rd).append(US).append(g.writable ? 1 : 0).append(RS); }
            return sb.toString(); } });
    }
    static boolean holderType(Class<?> t) { String n = t.getName(); return n.startsWith("ru.ius.david.cgs") && !t.isEnum() && !t.isInterface(); }
    static void scan(String path, Object o, Object holder, int depth, Set<Object> seen) {
        if (o == null || depth > 3 || seen.contains(o)) return; seen.add(o);
        String cn = o.getClass().getSimpleName();
        if ((cn.endsWith("Grid") || cn.endsWith("Mask") || cn.equals("Pixmap")) && !cn.startsWith("Unit")) { Grid g = describeGrid(path, o, holder); if (g.get2 != null || g.get1 != null) { cands.add(g); } }
        for (Class<?> k = o.getClass(); k != null && k != Object.class; k = k.getSuperclass()) for (Field f : k.getDeclaredFields()) {
            if (Modifier.isStatic(f.getModifiers())) continue; Class<?> t = f.getType(); Object v;
            try { f.setAccessible(true); v = f.get(o); } catch (Throwable e) { continue; } if (v == null) continue;
            String p = path + "." + f.getName();
            if (t.isArray() && (t.getComponentType() == int.class || t.getComponentType() == short.class || t.getComponentType() == byte.class) && Array.getLength(v) >= 20000) { Grid g = describeArray(p, v, o); if (g != null) cands.add(g); }
            else if (t.isArray() && !t.getComponentType().isPrimitive() && depth < 3 && holderType(t.getComponentType())) { int len = Math.min(Array.getLength(v), 4); for (int i = 0; i < len; i++) scan(p + "[" + i + "]", Array.get(v, i), o, depth + 1, seen); }
            else if (v instanceof Collection && depth < 3) { int i = 0; for (Object e : (Collection<?>) v) { if (i++ >= 8) break; if (e != null) scan(p + "[" + (i - 1) + "]", e, o, depth + 1, seen); } }
            else if (v instanceof Map && depth < 3) { int i = 0; for (Object e : ((Map<?, ?>) v).values()) { if (i++ >= 8) break; if (e != null) scan(p + "{" + (i - 1) + "}", e, o, depth + 1, seen); } }
            else if (v.getClass().getName().equals("com.badlogic.gdx.graphics.Pixmap")) scan(p, v, o, depth + 1, seen);
            else if (holderType(t) || (!t.isPrimitive() && !t.isArray() && v.getClass().getName().startsWith("ru.ius.david.cgs") && !v.getClass().isEnum())) scan(p, v, o, depth + 1, seen);
        }
    }

    static String use(int idx) { if (idx < 0 || idx >= cands.size()) return "ERR|BAD|No such grid. Run map detection first."; cur = cands.get(idx); curIdx = idx; return "OK|Using grid " + cur.path; }

    static String data(final int outW) throws Exception {
        if (cur == null) return "ERR|NOMAP|No map grid selected. Run detection first.";
        return AocBridge.onGame(new Callable<String>() { public String call() throws Exception {
            Grid g = cur; int ow = Math.max(16, Math.min(outW, g.w)); int oh = Math.max(8, (int) Math.round((double) ow * g.h / g.w));
            java.nio.ByteBuffer bb = java.nio.ByteBuffer.allocate(ow * oh * 4).order(java.nio.ByteOrder.LITTLE_ENDIAN);
            for (int cy = 0; cy < oh; cy++) { int sy = Math.min(g.h - 1, (int) ((cy + 0.5) * g.h / oh)); for (int cx = 0; cx < ow; cx++) { int sx = Math.min(g.w - 1, (int) ((cx + 0.5) * g.w / ow)); bb.putInt((int) read(g, sx, sy)); } }
            return "OK|" + ow + " " + oh + " " + g.w + " " + g.h + " " + Base64.getEncoder().encodeToString(bb.array()); } });
    }

    static long[] rgbForms(String hex) {
        try { String h = hex.replace("#", "").trim(); if (h.length() == 8) h = h.substring(2); int rgb = Integer.parseInt(h, 16); int r = (rgb >> 16) & 255, gg = (rgb >> 8) & 255, b = rgb & 255;
            return new long[]{rgb, 0xFF000000L | rgb, ((long) rgb << 8 | 0xFF) & 0xFFFFFFFFL, (b << 16 | gg << 8 | r), 0xFF000000L | (b << 16 | gg << 8 | r), ((long) (b << 16 | gg << 8 | r) << 8 | 0xFF) & 0xFFFFFFFFL}; } catch (Throwable t) { return new long[0]; }
    }
    static long norm(long v) { return v & 0xFFFFFFFFL; }

    static String keys() throws Exception {
        if (cur == null) return "ERR|NOMAP|No map grid selected. Run detection first.";
        return AocBridge.onGame(new Callable<String>() { public String call() throws Exception {
            Grid g = cur; if (g.map == null && g.rejected.isEmpty()) evaluate(g, extractors(), countSources());
            if (g.map == null) { keyToCountry.clear(); return "ERR|NOMATCH|This grid does not look like country ownership (" + (g.rejected.isEmpty() ? "no country values found" : g.rejected) + "; " + g.distinct + " distinct values). Pick another grid in Map > Setup, or use Write diagnostics and send aoc_map_diag.txt."; }
            keyToCountry = g.map; extractorDesc = g.ext; int total = AocWorld.world().size();
            StringBuilder sb = new StringBuilder("OK|" + g.ext + US + g.matched + US + total + US + g.coverage + RS);
            for (Map.Entry<Long,String> e : g.map.entrySet()) sb.append(e.getKey()).append(US).append(e.getValue()).append(RS);
            return sb.toString(); } });
    }

    static void listMapFiles(java.io.File d, int depth, StringBuilder sb) {
        java.io.File[] fs = d.listFiles(); if (fs == null || depth > 3) return;
        for (java.io.File f : fs) { String n = f.getName().toLowerCase(Locale.ROOT); if (f.isDirectory()) { if (!n.equals("jre") && !n.equals("runtime")) listMapFiles(f, depth + 1, sb); }
            else if ((n.contains("map") || n.contains("cache") || n.contains("seed") || n.contains("world")) && f.length() > 1000) sb.append("  ").append(f.getPath()).append(" (").append(f.length()).append(" bytes)\n"); }
    }
    static String diag() throws Exception {
        return AocBridge.onGame(new Callable<String>() { public String call() throws Exception {
            StringBuilder sb = new StringBuilder("Map diagnostics\n"); List<Ext> exts = extractors(); sb.append("countries: ").append(AocWorld.world().size()).append("\nextractors: ");
            for (Ext e : exts) sb.append(e.name).append(" (").append(e.keys.size()).append("); "); sb.append("\n");
            for (Src sr : countSources()) sb.append("count source ").append(sr.name).append(": ").append(sr.target.size()).append(" countries\n");
            Map<String,Object> w = AocWorld.world(); int i = 0; for (Map.Entry<String,Object> e : w.entrySet()) { if (i++ >= 5) break; sb.append("sample country ").append(e.getKey()).append(" colorHex=").append(AocBridge.read(e.getValue(), "colorHex")).append('\n'); }
            sb.append("game seed: ").append(haveSeed ? String.valueOf(seedValue) : "(not found)").append("\nobjects holding the same seed: ").append(seedHolders.isEmpty() ? "(none found)" : "").append('\n'); for (String h : seedHolders) sb.append("  ").append(h).append('\n');
            try { java.io.File dir = new java.io.File(System.getProperty("user.dir")); sb.append("files near the game that look like map data:\n"); listMapFiles(dir, 0, sb); } catch (Throwable t) { }
            for (int k = 0; k < cands.size(); k++) { Grid g = cands.get(k); sb.append("\n#").append(k).append(' ').append(g.path).append(' ').append(g.kind).append(' ').append(g.w).append('x').append(g.h).append(" distinct=").append(g.distinct).append(" matched=").append(g.matched).append(" via ").append(g.ext).append(' ').append(g.rejected).append("\n  top values: ").append(g.top).append('\n'); }
            String file = System.getProperty("user.dir") + java.io.File.separator + "aoc_map_diag.txt";
            try (java.io.FileWriter fw = new java.io.FileWriter(file)) { fw.write(sb.toString()); } catch (Throwable t) { file = "(could not write file: " + t + ")"; }
            return "OK|Diagnostics written to " + file; } });
    }

    static String cellinfo(final int x, final int y) throws Exception {
        if (cur == null) return "ERR|NOMAP|No map grid selected.";
        return AocBridge.onGame(new Callable<String>() { public String call() throws Exception {
            long v = norm(read(cur, Math.max(0, Math.min(cur.w - 1, x)), Math.max(0, Math.min(cur.h - 1, y)))); StringBuilder sb = new StringBuilder("OK|value=" + v + "\towner=" + (keyToCountry.containsKey(v) ? keyToCountry.get(v) : ""));
            try { Object[] r = (Object[]) AocBridge.call(AocBridge.gm(), "appraiseDominantResourceNear", (float) x, (float) y, 24f); if (r != null) sb.append("\tdominant=").append(Arrays.toString(r)); } catch (Throwable t) { }
            return sb.toString(); } });
    }

    /** EXPERIMENTAL: re-assign the connected area of equal value around (x,y) to the value of the given country key. */
    static String mapset(final int x, final int y, final int newValue) throws Exception {
        if (cur == null || !cur.writable) return "ERR|NOWRITE|The selected grid cannot be written.";
        return AocBridge.onGame(new Callable<String>() { public String call() throws Exception {
            Grid g = cur; long old = read(g, x, y); if (norm(old) == norm(newValue)) return "OK|Nothing to change."; int w = g.w, h = g.h; int cap = 20_000_000, n = 0;
            int[] stack = new int[1 << 16]; int sp = 0; stack[sp++] = y * w + x; write(g, x, y, newValue); n++;
            while (sp > 0 && n < cap) { int p = stack[--sp]; int px = p % w, py = p / w; int[][] nb = {{px + 1, py}, {px - 1, py}, {px, py + 1}, {px, py - 1}};
                for (int[] q : nb) { if (q[0] < 0 || q[1] < 0 || q[0] >= w || q[1] >= h) continue; if (read(g, q[0], q[1]) == old) { write(g, q[0], q[1], newValue); n++; if (sp == stack.length) stack = Arrays.copyOf(stack, sp * 2); stack[sp++] = q[1] * w + q[0]; } } }
            try { Method m = AocBridge.gm().getClass().getDeclaredMethod("syncTerritorySizes"); m.setAccessible(true); m.invoke(AocBridge.gm()); } catch (Throwable t) { }
            try { AocBridge.call(AocBridge.gm(), "refreshResourceMultipliersNow"); } catch (Throwable t) { }
            AocBridge.detail("territory at " + x + "," + y + ": " + n + " cells reassigned");
            return "OK|Reassigned " + n + " cells. The on-screen map may only refresh after the game redraws it."; } });
    }

    static String classdump(String[] names) throws Exception {
        StringBuilder sb = new StringBuilder(); if (names.length == 0) names = new String[]{"ru.ius.david.cgs.WarManager", "ru.ius.david.cgs.NativeIntGrid", "ru.ius.david.cgs.CountryData", "ru.ius.david.cgs.MapTopology", "ru.ius.david.cgs.TerritoryMask", "ru.ius.david.cgs.HomelandMap", "ru.ius.david.cgs.MapScreen", "ru.ius.david.cgs.NativeByteGrid", "ru.ius.david.cgs.TerritoryRenderer", "ru.ius.david.cgs.PaintedMapSurface", "ru.ius.david.cgs.MapCache", "ru.ius.david.cgs.CountryState", "ru.ius.david.cgs.IntegrationMask"};
        for (String n : names) { try { Class<?> c = AocBridge.cls(n); sb.append("== ").append(n).append('\n');
            for (Class<?> k = c; k != null && k != Object.class; k = k.getSuperclass()) { for (Field f : k.getDeclaredFields()) sb.append("  field ").append(Modifier.toString(f.getModifiers())).append(' ').append(f.getType().getSimpleName()).append(' ').append(f.getName()).append('\n');
                for (Method m : k.getDeclaredMethods()) sb.append("  method ").append(Modifier.toString(m.getModifiers())).append(' ').append(m.getReturnType().getSimpleName()).append(' ').append(m.getName()).append(Arrays.toString(m.getParameterTypes())).append('\n'); } } catch (Throwable t) { sb.append("== ").append(n).append(" (not found)\n"); } }
        String file = System.getProperty("user.dir") + java.io.File.separator + "aoc_class_dump.txt";
        try (java.io.FileWriter fw = new java.io.FileWriter(file)) { fw.write(sb.toString()); } catch (Throwable t) { file = "(could not write file: " + t + ")"; }
        return "OK|Class dump written to " + file;
    }
}
