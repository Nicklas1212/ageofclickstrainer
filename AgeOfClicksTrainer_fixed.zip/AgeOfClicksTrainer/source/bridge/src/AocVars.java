import java.lang.reflect.*;
import java.util.*;
import java.util.concurrent.Callable;

/** Generic reflection-based variable explorer over the live game state. */
class AocVars {
    static final char RS = '\u001e', US = '\u001f';
    static final Map<String,Object> originals = new HashMap<>();   // path -> original value (typed)

    static String enc(String s) { return s.replace("%", "%25").replace("/", "%2F").replace(" ", "%20"); }
    static String dec(String s) { return s.replace("%20", " ").replace("%2F", "/").replace("%25", "%"); }

    static Object root(String name) throws Exception {
        switch (name) {
            case "game": return AocBridge.gm();
            case "country": return AocBridge.cs();
            case "player": return AocBridge.ps();
            case "countries": return AocWorld.world();
            case "technologies": return AocBridge.cls(AocBridge.P + "Technology").getField("ALL_TECHNOLOGIES").get(null);
        }
        throw new Exception("Unknown root: " + name);
    }
    static final String[] ROOTS = {"game", "country", "player", "countries", "technologies"};

    static boolean leaf(Object o, Class<?> declared) {
        if (o == null) return declared == null || declared.isPrimitive() || declared == String.class || declared.isEnum() || Number.class.isAssignableFrom(declared) || declared == Boolean.class;
        Class<?> c = o.getClass(); return c.isPrimitive() || o instanceof Number || o instanceof Boolean || o instanceof String || o instanceof Character || c.isEnum() || o instanceof Class;
    }

    static class Node { String seg; Object val; Class<?> type; Field field; Object owner; boolean editable; }

    static List<Node> children(Object o) throws Exception {
        List<Node> out = new ArrayList<>();
        if (o instanceof Map) { int i = 0; for (Map.Entry<?, ?> e : ((Map<?, ?>) o).entrySet()) { if (i++ >= 500) break; Node n = new Node(); n.seg = "{" + enc(String.valueOf(e.getKey())) + "}"; n.val = e.getValue(); n.type = n.val == null ? Object.class : n.val.getClass(); n.owner = o; n.editable = leaf(n.val, null) && n.val != null; out.add(n); } return out; }
        if (o instanceof List) { List<?> l = (List<?>) o; for (int i = 0; i < Math.min(500, l.size()); i++) { Node n = new Node(); n.seg = "[" + i + "]"; n.val = l.get(i); n.type = n.val == null ? Object.class : n.val.getClass(); n.owner = o; n.editable = leaf(n.val, null) && n.val != null; out.add(n); } return out; }
        if (o instanceof Collection) { int i = 0; for (Object v : (Collection<?>) o) { if (i >= 500) break; Node n = new Node(); n.seg = "[" + i + "]"; n.val = v; n.type = v == null ? Object.class : v.getClass(); i++; out.add(n); } return out; }
        if (o.getClass().isArray()) { int len = Array.getLength(o); for (int i = 0; i < Math.min(500, len); i++) { Node n = new Node(); n.seg = "[" + i + "]"; n.val = Array.get(o, i); n.type = o.getClass().getComponentType(); n.owner = o; n.editable = leaf(n.val, n.type); out.add(n); } return out; }
        for (Class<?> k = o.getClass(); k != null && k != Object.class; k = k.getSuperclass()) {
            for (Field f : k.getDeclaredFields()) {
                int md = f.getModifiers(); if (Modifier.isStatic(md) || f.isSynthetic()) continue;
                try { f.setAccessible(true); Node n = new Node(); n.seg = f.getName(); n.val = f.get(o); n.type = f.getType(); n.field = f; n.owner = o; n.editable = !Modifier.isFinal(md) && leaf(n.val, f.getType()); out.add(n); } catch (Throwable t) { }
            }
        }
        return out;
    }

    static Object resolve(String path) throws Exception {
        if (path.isEmpty()) return null;
        String[] seg = path.split("/"); Object cur = root(seg[0]);
        for (int i = 1; i < seg.length; i++) cur = step(cur, seg[i]);
        return cur;
    }
    static Object step(Object cur, String s) throws Exception {
        if (cur == null) throw new Exception("null on the way");
        if (s.startsWith("{")) { String key = dec(s.substring(1, s.length() - 1)); for (Map.Entry<?, ?> e : ((Map<?, ?>) cur).entrySet()) if (String.valueOf(e.getKey()).equals(key)) return e.getValue(); throw new Exception("No map key " + key); }
        if (s.startsWith("[")) { int i = Integer.parseInt(s.substring(1, s.length() - 1)); if (cur instanceof List) return ((List<?>) cur).get(i); if (cur.getClass().isArray()) return Array.get(cur, i); int j = 0; for (Object v : (Collection<?>) cur) if (j++ == i) return v; throw new Exception("Bad index"); }
        Field f = AocBridge.fld(cur.getClass(), s); if (f == null) throw new Exception("No field " + s); return f.get(cur);
    }

    static String typeName(Node n) { Class<?> t = n.type == null ? Object.class : n.type; return t.isArray() ? t.getComponentType().getSimpleName() + "[]" : t.getSimpleName(); }
    static String preview(Node n) {
        Object v = n.val; if (v == null) return "null";
        if (leaf(v, n.type)) { String s = String.valueOf(v); return s.length() > 90 ? s.substring(0, 90) + "..." : s; }
        if (v instanceof Map) return "Map (" + ((Map<?, ?>) v).size() + " entries)"; if (v instanceof Collection) return v.getClass().getSimpleName() + " (" + ((Collection<?>) v).size() + " items)";
        if (v.getClass().isArray()) return v.getClass().getComponentType().getSimpleName() + "[" + Array.getLength(v) + "]";
        return v.getClass().getSimpleName();
    }
    static String row(Node n, String path) {
        boolean lf = leaf(n.val, n.type);
        return n.seg + US + typeName(n) + US + preview(n) + US + (lf ? "L" : "C") + US + (n.editable ? "1" : "0") + US + (originals.containsKey(path + "/" + n.seg) ? "1" : "0");
    }

    static String list(final String path) throws Exception {
        return AocBridge.onGame(new Callable<String>() { public String call() throws Exception {
            StringBuilder sb = new StringBuilder("OK|");
            if (path.isEmpty()) { for (String r : ROOTS) { Object o = root(r); sb.append(r).append(US).append(o == null ? "null" : o.getClass().getSimpleName()).append(US).append(o instanceof Map ? "Map (" + ((Map<?, ?>) o).size() + ")" : o instanceof Collection ? "List (" + ((Collection<?>) o).size() + ")" : "object").append(US).append("C").append(US).append("0").append(US).append("0").append(RS); } return sb.toString(); }
            Object o = resolve(path); if (o == null) return "OK|"; for (Node n : children(o)) sb.append(row(n, path)).append(RS); return sb.toString(); } });
    }
    static String get(final String path) throws Exception {
        return AocBridge.onGame(new Callable<String>() { public String call() throws Exception { return "OK|" + String.valueOf(resolve(path)); } });
    }

    static Object parseFor(Class<?> t, String v, Object current) throws Exception {
        if (t == boolean.class || t == Boolean.class) { String x = v.toLowerCase(Locale.ROOT); return x.equals("true") || x.equals("on") || x.equals("1"); }
        if (t == String.class) return v;
        if (t == char.class || t == Character.class) return v.charAt(0);
        if (t.isEnum()) { for (Object e : t.getEnumConstants()) if (e.toString().equalsIgnoreCase(v)) return e; throw new Exception("Not a valid value. Options: " + Arrays.toString(t.getEnumConstants())); }
        double d = AocBridge.parse(v);
        if (t == int.class || t == Integer.class) return (int) Math.round(d); if (t == long.class || t == Long.class) return Math.round(d); if (t == float.class || t == Float.class) return (float) d;
        if (t == double.class || t == Double.class) return d; if (t == short.class || t == Short.class) return (short) d; if (t == byte.class || t == Byte.class) return (byte) d;
        throw new Exception("Unsupported type " + t.getSimpleName());
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    static String set(final String path, final String value) throws Exception {
        return AocBridge.onGame(new Callable<String>() { public String call() throws Exception {
            int i = path.lastIndexOf('/'); if (i < 0) throw new Exception("Cannot edit a root."); Object parent = resolve(path.substring(0, i)); String s = path.substring(i + 1); Object old;
            if (s.startsWith("{")) { String key = dec(s.substring(1, s.length() - 1)); Map m = (Map) parent; Object k2 = null; for (Object k : m.keySet()) if (String.valueOf(k).equals(key)) k2 = k; old = m.get(k2); originals.putIfAbsent(path, old); m.put(k2, parseFor(old.getClass(), value, old)); }
            else if (s.startsWith("[")) { int idx = Integer.parseInt(s.substring(1, s.length() - 1)); if (parent instanceof List) { old = ((List) parent).get(idx); originals.putIfAbsent(path, old); ((List) parent).set(idx, parseFor(old.getClass(), value, old)); } else { old = Array.get(parent, idx); originals.putIfAbsent(path, old); Array.set(parent, idx, parseFor(parent.getClass().getComponentType(), value, old)); } }
            else { Field f = AocBridge.fld(parent.getClass(), s); if (f == null) throw new Exception("No field " + s); if (Modifier.isFinal(f.getModifiers())) throw new Exception("This value is read-only."); old = f.get(parent); originals.putIfAbsent(path, old); f.set(parent, parseFor(f.getType(), value, old)); }
            Object nv = resolve(path); AocBridge.detail(path + ": " + old + " -> " + nv); return "OK|" + path + " = " + nv; } });
    }
    @SuppressWarnings({"unchecked", "rawtypes"})
    static String reset(final String path) throws Exception {
        if (!originals.containsKey(path)) return "ERR|NOBASE|No original value is recorded for this variable (it has not been edited here).";
        final Object orig = originals.get(path);
        return AocBridge.onGame(new Callable<String>() { public String call() throws Exception {
            int i = path.lastIndexOf('/'); Object parent = resolve(path.substring(0, i)); String s = path.substring(i + 1);
            if (s.startsWith("{")) { String key = dec(s.substring(1, s.length() - 1)); Map m = (Map) parent; for (Object k : m.keySet()) if (String.valueOf(k).equals(key)) { m.put(k, orig); break; } }
            else if (s.startsWith("[")) { int idx = Integer.parseInt(s.substring(1, s.length() - 1)); if (parent instanceof List) ((List) parent).set(idx, orig); else Array.set(parent, idx, orig); }
            else AocBridge.fld(parent.getClass(), s).set(parent, orig);
            originals.remove(path); return "OK|Restored " + path + " to " + orig; } });
    }

    /** Breadth-first name search through the state graph (bounded). */
    static String find(final String text) throws Exception {
        return AocBridge.onGame(new Callable<String>() { public String call() throws Exception {
            String q = text.toLowerCase(Locale.ROOT); StringBuilder sb = new StringBuilder("OK|"); int found = 0, visitedN = 0;
            ArrayDeque<Object[]> queue = new ArrayDeque<>(); Map<Object, Boolean> seen = new IdentityHashMap<>();
            for (String r : ROOTS) { Object o = root(r); if (o != null) { queue.add(new Object[]{r, o, 0}); seen.put(o, true); } }
            while (!queue.isEmpty() && visitedN < 40000 && found < 200) {
                Object[] cur = queue.poll(); String path = (String) cur[0]; Object obj = cur[1]; int depth = (Integer) cur[2]; visitedN++;
                List<Node> kids; try { kids = children(obj); } catch (Throwable t) { continue; }
                for (Node n : kids) {
                    String p = path + "/" + n.seg;
                    if (n.seg.toLowerCase(Locale.ROOT).contains(q) || (leaf(n.val, n.type) && n.val != null && String.valueOf(n.val).toLowerCase(Locale.ROOT).equals(q))) { sb.append(p).append(US).append(typeName(n)).append(US).append(preview(n)).append(US).append(leaf(n.val, n.type) ? "L" : "C").append(US).append(n.editable ? "1" : "0").append(RS); if (++found >= 200) break; }
                    if (depth < 5 && n.val != null && !leaf(n.val, n.type) && !seen.containsKey(n.val)) {
                        String cn = n.val.getClass().getName(); boolean coll = n.val instanceof Map || n.val instanceof Collection || n.val.getClass().isArray();
                        if (!coll && (cn.startsWith("java.") || cn.startsWith("sun.") || cn.startsWith("jdk.") || cn.startsWith("com.badlogic.gdx.graphics") || cn.startsWith("org.lwjgl") || cn.startsWith("com.codedisaster"))) continue;
                        seen.put(n.val, true); queue.add(new Object[]{p, n.val, depth + 1});
                    }
                }
            }
            return sb.toString(); } });
    }
}
