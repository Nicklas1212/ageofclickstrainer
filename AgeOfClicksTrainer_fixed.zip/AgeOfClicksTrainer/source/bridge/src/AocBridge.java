import java.io.*;
import java.lang.reflect.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;

/**
 * Age of Clicks Trainer - in-process bridge.
 * Loaded into the game's own JVM by the native DLL. Talks to the game purely by reflection
 * (class/field names are not obfuscated). Serves a tiny line protocol on 127.0.0.1 only.
 * SINGLE PLAYER ONLY: every mutating command is refused when the game is in network/multiplayer mode.
 */
public class AocBridge {
    static final String P = "ru.ius.david.cgs.game.";
    static ClassLoader CL;
    static Object gdxApp; static Method postRun;
    static volatile boolean running = true;
    static final Map<String,double[]> locks = new LinkedHashMap<>();   // "target.field" -> {mode(0 exact,1 floor,2 ceil), value}
    static final Map<String,Double> gainMult = new LinkedHashMap<>();  // "target.field" -> multiplier
    static final Map<String,Double> prev = new HashMap<>();
    static final Set<String> flags = Collections.synchronizedSet(new LinkedHashSet<String>());
    static final Map<String,String> opts = new ConcurrentHashMap<>();
    static final Random rnd = new Random();
    static double cps = 10, jitter = 0.2; static int clickMul = 1; static double clickAcc = 0;
    static long lastTickMs = 0, lastSlowMs = 0;
    static final LinkedList<Snap> undo = new LinkedList<>();
    static final Snap[] slots = new Snap[9];
    static volatile String lastError = "";
    static volatile Thread gameThread;
    static final Map<String,Double> baselines = new HashMap<>();
    static final LinkedList<Snap> redo = new LinkedList<>();
    static final List<String[]> history = Collections.synchronizedList(new ArrayList<String[]>()); // {time, label, detail, state}
    static void baseline(String key, double v) { if (!baselines.containsKey(key)) baselines.put(key, v); }
    static final String[] UPG = {
    "Click Power|getClickUpgradeCost|ClickPower|ClickPower|eco",
    "Auto Income|getIncomeUpgradeCost|AutoIncome|AutoIncome|eco",
    "Finance|getFinanceUpgradeCost|Finance|Finance|eco",
    "Tax Office|getTaxOfficeUpgradeCost|TaxOffice|TaxOffice|eco",
    "Trade Post|getTradePostUpgradeCost|TradePost|TradePost|eco",
    "Iron Mine|getIronUpgradeCost|IronMine|IronMine|raw",
    "Coal Mine|getCoalUpgradeCost|CoalMine|CoalMine|raw",
    "Oil Well|getOilUpgradeCost|OilWell|OilWell|raw",
    "Sawmill|getSawmillUpgradeCost|Sawmill|Sawmill|raw",
    "Rubber Plantation|getRubberUpgradeCost|RubberPlantation|RubberPlantation|raw",
    "Aluminum Mine|getAluminumUpgradeCost|AluminumMine|AluminumMine|raw",
    "Uranium Mine|getUraniumUpgradeCost|UraniumMine|UraniumMine|raw",
    "Copper Mine|getCopperUpgradeCost|CopperMine|CopperMine|raw",
    "Steel Mill|getSteelMillUpgradeCost|SteelMill|SteelMill|prod",
    "Oil Refinery|getOilRefineryUpgradeCost|OilRefinery|OilRefinery|prod",
    "Munitions Factory|getMunitionsUpgradeCost|MunitionsFactory|MunitionsFactory|prod",
    "Parts Workshop|getPartsWorkshopUpgradeCost|PartsWorkshop|PartsWorkshop|prod",
    "Railroad|getRailroadUpgradeCost|Railroad|Railroad|prod",
    "Light Industry|getLightIndustryUpgradeCost|LightIndustry|LightIndustry|prod",
    "Electronics Plant|getElectronicsPlantUpgradeCost|ElectronicsPlant|ElectronicsPlant|prod",
    "Auto Plant|getAutoPlantUpgradeCost|AutoPlant|AutoPlant|prod",
    "University|getUniversityUpgradeCost|University|University|sci",
    "Mech Barracks|getMechBarracksUpgradeCost|MechBarracks|MechBarracks|mil",
    "Barracks|getBarracksUpgradeCost|Barracks|Barracks|mil",
    "Weapons Factory|getFactoryUpgradeCost|WeaponsFactory|WeaponsFactory|mil",
    "Artillery Factory|getArtilleryFactoryUpgradeCost|ArtilleryFactory|ArtilleryFactory|mil",
    "Tank Factory|getTankFactoryUpgradeCost|TankFactory|TankFactory|mil",
    "Aircraft Factory|getAircraftFactoryUpgradeCost|AircraftFactory|AircraftFactory|mil",
    "Naval Shipyard|getNavalShipyardUpgradeCost|NavalShipyard|NavalShipyard|mil",
    "Nuclear Reactor|getNuclearReactorUpgradeCost|NuclearReactor|NuclearReactor|mil",
    "Space Center|getSpaceCenterUpgradeCost|SpaceCenter|SpaceCenter|mil",
    "Fortification|getFortificationUpgradeCost|Fortification|Fortification|mil",
    "Diplomat|getDiplomatUpgradeCost|Diplomat|Diplomat|dip"
    };

    // ---------------------------------------------------------------- entry
    public static void start(int port) {
        try {
            CL = AocBridge.class.getClassLoader();
            final ServerSocket ss = new ServerSocket(port, 8, InetAddress.getByName("127.0.0.1"));
            Thread acc = new Thread(new Runnable() { public void run() {
                while (running) {
                    try { final Socket s = ss.accept(); s.setTcpNoDelay(true);
                        Thread t = new Thread(new Runnable() { public void run() { serve(s); } }, "AocBridge-conn");
                        t.setDaemon(true); t.start();
                    } catch (Throwable e) { if (!running) break; }
                }
            }}, "AocBridge-accept");
            acc.setDaemon(true); acc.start();
            Thread tk = new Thread(new Runnable() { public void run() {
                while (running) {
                    try { Thread.sleep(40); if (needTick()) post(new Runnable() { public void run() { try { tick(); } catch (Throwable e) { lastError = String.valueOf(e); } } }); }
                    catch (Throwable e) { }
                }
            }}, "AocBridge-tick");
            tk.setDaemon(true); tk.start();
        } catch (Throwable e) { lastError = String.valueOf(e); }
    }

    static boolean needTick() { return !locks.isEmpty() || !gainMult.isEmpty() || !flags.isEmpty(); }

    static void serve(Socket s) {
        try {
            BufferedReader r = new BufferedReader(new InputStreamReader(s.getInputStream(), StandardCharsets.UTF_8));
            OutputStream o = s.getOutputStream();
            String line;
            while ((line = r.readLine()) != null) {
                String resp;
                try { resp = handle(line.trim()); } catch (Throwable e) { Throwable c = e; while (c.getCause() != null) c = c.getCause(); resp = "ERR|" + c; }
                resp = resp.replace("\r", "").replace("\n", "\\n");
                o.write((resp + "\n").getBytes(StandardCharsets.UTF_8)); o.flush();
            }
        } catch (Throwable e) { } finally { try { s.close(); } catch (Throwable e) { } }
    }

    // ---------------------------------------------------------------- game thread
    static void initGdx() throws Exception {
        if (gdxApp != null) return;
        Class<?> gdx = Class.forName("com.badlogic.gdx.Gdx", true, CL);
        gdxApp = gdx.getField("app").get(null);
        postRun = Class.forName("com.badlogic.gdx.Application", true, CL).getMethod("postRunnable", Runnable.class);
    }
    static void post(Runnable r) throws Exception { initGdx(); postRun.invoke(gdxApp, r); }
    static <T> T onGame(Callable<T> c) throws Exception {
        initGdx();
        if (Thread.currentThread() == gameThread) return c.call();
        FutureTask<T> f = new FutureTask<T>(c);
        postRun.invoke(gdxApp, f);
        try { return f.get(4, TimeUnit.SECONDS); } catch (ExecutionException e) { throw (e.getCause() instanceof Exception) ? (Exception) e.getCause() : e; }
    }

    // ---------------------------------------------------------------- reflection helpers
    static Class<?> cls(String n) throws Exception { return Class.forName(n, true, CL); }
    static Object fieldVal(Object o, String name) {
        try { boolean st = o instanceof Class; for (Class<?> k = st ? (Class<?>) o : o.getClass(); k != null; k = k.getSuperclass()) {
            try { Field f = k.getDeclaredField(name); f.setAccessible(true); return f.get(st ? null : o); } catch (NoSuchFieldException e) { } } } catch (Throwable e) { }
        return null;
    }
    static Object gmFrom(ClassLoader l) {
        try { Class<?> c = Class.forName(P + "GameManager", true, l); Object g = null;
            try { g = c.getMethod("peekInstance").invoke(null); } catch (Throwable e) { }
            if (g == null) g = fieldVal(c, "instance");
            return g;
        } catch (Throwable e) { return null; }
    }
    static long lastLoaderScan = 0; static String loaderNote = "";
    // The game may run its classes in a different class loader than the one our bridge was defined in (then Class.forName
    // yields a second, never-initialised copy of GameManager whose singleton is null). Find the loader that holds the live game.
    static ClassLoader findLiveLoader() {
        long now = System.currentTimeMillis(); if (now - lastLoaderScan < 1500) return null; lastLoaderScan = now;
        LinkedHashSet<ClassLoader> cands = new LinkedHashSet<ClassLoader>();
        try { for (Thread t : Thread.getAllStackTraces().keySet()) { ClassLoader c = t.getContextClassLoader(); while (c != null) { cands.add(c); c = c.getParent(); } } } catch (Throwable e) { }
        try { cands.add(ClassLoader.getSystemClassLoader()); } catch (Throwable e) { }
        if (AocBridge.class.getClassLoader() != null) cands.add(AocBridge.class.getClassLoader());
        loaderNote = "scanned " + cands.size() + " loaders";
        for (ClassLoader c : cands) if (gmFrom(c) != null) { loaderNote += "; live GameManager found in " + c.getClass().getName(); return c; }
        for (ClassLoader c : cands) { try { Class<?> g = Class.forName("com.badlogic.gdx.Gdx", false, c); Field f = g.getField("app"); if (f.get(null) != null) { loaderNote += "; Gdx.app live in " + c.getClass().getName(); return c; } } catch (Throwable e) { } }
        return null;
    }
    static Object gm() throws Exception {
        Object g = gmFrom(CL);
        if (g == null) { ClassLoader l = findLiveLoader(); if (l != null && l != CL) { CL = l; g = gmFrom(CL); } }
        return g;
    }
    static Object cs() throws Exception {
        Object g = gm(); if (g == null) return null; Object c = null;
        try { c = g.getClass().getMethod("getPlayerCountry").invoke(g); } catch (Throwable e) { }
        if (c == null) c = fieldVal(g, "playerCountry");
        if (c == null) { Object n = fieldVal(g, "localPlayerCountryName"), w = fieldVal(g, "worldCountries");
            if (n != null && w instanceof Map) c = ((Map<?, ?>) w).get(n); }
        return c;
    }
    static Object ps() throws Exception {
        Object g = gm(); if (g == null) return null; Object p = null;
        try { p = g.getClass().getMethod("getPlayerState").invoke(g); } catch (Throwable e) { }
        if (p == null) p = fieldVal(g, "playerState");
        return p;
    }
    static String noGameWhy() {
        try { Object g = gm(); if (g == null) return "GameManager instance is null (no game started yet in this process; " + loaderNote + "; loader=" + (CL == null ? "null" : CL.getClass().getName()) + ")";
            Object w = fieldVal(g, "worldCountries"); Object n = fieldVal(g, "localPlayerCountryName");
            return "GameManager exists but no player country (countries=" + (w instanceof Map ? ((Map<?, ?>) w).size() : -1) + ", localName=" + n + ", playerCountryField=" + fieldVal(g, "playerCountry") + ")";
        } catch (Throwable e) { return "diag failed: " + e; }
    }
    static Object tgt(String t) throws Exception {
        if (t.equals("country")) return cs(); if (t.equals("player")) return ps(); if (t.equals("game")) return gm();
        if (t.startsWith("c:")) return countryByName(t.substring(2));
        throw new Exception("bad target " + t);
    }
    /** Finds a world country by name; underscores in the request stand for spaces. */
    @SuppressWarnings("unchecked")
    static Object countryByName(String name) throws Exception {
        Map<String,Object> w = (Map<String,Object>) call(gm(), "getWorldCountries"); String n = name.replace('_', ' ');
        for (Map.Entry<String,Object> e : w.entrySet()) if (e.getKey().equalsIgnoreCase(n) || e.getKey().equalsIgnoreCase(name)) return e.getValue();
        for (Map.Entry<String,Object> e : w.entrySet()) if (String.valueOf(read(e.getValue(), "tag")).equalsIgnoreCase(name)) return e.getValue();
        throw new Exception("No such country: " + name);
    }
    /** Splits "target.field" at the last dot. */
    static String[] splitKey(String key) { int i = key.lastIndexOf('.'); return new String[]{key.substring(0, i), key.substring(i + 1)}; }
    static Field fld(Class<?> c, String n) {
        for (Class<?> k = c; k != null; k = k.getSuperclass()) { try { Field f = k.getDeclaredField(n); f.setAccessible(true); return f; } catch (NoSuchFieldException e) { } }
        return null;
    }
    static Object conv(Class<?> t, Object v) {
        if (v == null) return null;
        if (v instanceof Number) { Number n = (Number) v;
            if (t == int.class || t == Integer.class) return n.intValue(); if (t == long.class || t == Long.class) return n.longValue();
            if (t == float.class || t == Float.class) return n.floatValue(); if (t == double.class || t == Double.class) return n.doubleValue();
            if (t == short.class || t == Short.class) return n.shortValue(); if (t == byte.class || t == Byte.class) return n.byteValue(); }
        return v;
    }
    static boolean compat(Class<?> t, Object v) {
        if (v == null) return !t.isPrimitive();
        if (v instanceof Number) return t.isPrimitive() ? t != boolean.class && t != char.class : Number.class.isAssignableFrom(t);
        if (v instanceof Boolean) return t == boolean.class || t == Boolean.class;
        return t.isInstance(v);
    }
    static Object call(Object target, String name, Object... a) throws Exception {
        boolean st = target instanceof Class; Class<?> c = st ? (Class<?>) target : target.getClass();
        for (Class<?> k = c; k != null; k = k.getSuperclass()) {
            for (Method m : k.getDeclaredMethods()) {
                if (!m.getName().equals(name) || m.getParameterTypes().length != a.length) continue;
                Class<?>[] pt = m.getParameterTypes(); boolean ok = true;
                for (int i = 0; i < pt.length; i++) if (!compat(pt[i], a[i])) { ok = false; break; }
                if (!ok) continue;
                Object[] args = new Object[a.length]; for (int i = 0; i < a.length; i++) args[i] = conv(pt[i], a[i]);
                m.setAccessible(true);
                try { return m.invoke(st ? null : target, args); } catch (InvocationTargetException e) { throw (e.getCause() instanceof Exception) ? (Exception) e.getCause() : e; }
            }
        }
        throw new NoSuchMethodException(c.getSimpleName() + "." + name);
    }
    static Object read(Object o, String n) {
        try { Field f = fld(o.getClass(), n); if (f != null && !Modifier.isStatic(f.getModifiers())) return f.get(o); } catch (Throwable e) { }
        try { return call(o, n); } catch (Throwable e) { return null; }
    }
    static double num(Object o, String n) { Object v = read(o, n); if (v instanceof Number) return ((Number) v).doubleValue(); if (v instanceof Boolean) return ((Boolean) v) ? 1 : 0; return Double.NaN; }
    static void write(Object o, String n, double v) throws Exception {
        Field f = fld(o.getClass(), n); if (f == null) throw new Exception("no field " + n);
        Class<?> t = f.getType();
        if (t == long.class) f.setLong(o, Math.round(v)); else if (t == int.class) f.setInt(o, (int) Math.max(Integer.MIN_VALUE, Math.min(Integer.MAX_VALUE, Math.round(v))));
        else if (t == float.class) f.setFloat(o, (float) v); else if (t == double.class) f.setDouble(o, v);
        else if (t == boolean.class) f.setBoolean(o, v != 0); else if (t == short.class) f.setShort(o, (short) v); else if (t == byte.class) f.setByte(o, (byte) v);
        else throw new Exception("field " + n + " is not numeric (" + t.getSimpleName() + ")");
    }
    static String fmtNum(double d) { return d == Math.rint(d) && Math.abs(d) < 1e15 ? String.format("%,d", (long) d) : String.format("%.3f", d); }
    static double parse(String s) {
        s = s.trim().replace(",", "").replace("_", "").toLowerCase(Locale.ROOT);
        if (s.equals("true") || s.equals("on")) return 1; if (s.equals("false") || s.equals("off")) return 0;
        double m = 1; char c = s.isEmpty() ? ' ' : s.charAt(s.length() - 1);
        if (c == 'k') m = 1e3; else if (c == 'm') m = 1e6; else if (c == 'b') m = 1e9; else if (c == 't') m = 1e12; else if (c == 'q') m = 1e15;
        if (m != 1) s = s.substring(0, s.length() - 1);
        return Double.parseDouble(s) * m;
    }

    // ---------------------------------------------------------------- snapshots (undo + slots)
    static class Snap { Map<String,Object> c = new HashMap<>(), p = new HashMap<>(); int days; ArrayList<String> researched, queue; String label; }
    static void grab(Object o, Map<String,Object> m) {
        for (Class<?> k = o.getClass(); k != null && k != Object.class; k = k.getSuperclass())
            for (Field f : k.getDeclaredFields()) {
                int md = f.getModifiers(); if (Modifier.isStatic(md) || Modifier.isFinal(md)) continue;
                Class<?> t = f.getType();
                if (t.isPrimitive() || t == String.class || t.isEnum()) { try { f.setAccessible(true); m.put(f.getName(), f.get(o)); } catch (Throwable e) { } }
            }
    }
    static void put(Object o, Map<String,Object> m) {
        for (Map.Entry<String,Object> e : m.entrySet()) { try { Field f = fld(o.getClass(), e.getKey()); if (f != null) f.set(o, e.getValue()); } catch (Throwable x) { } }
    }
    @SuppressWarnings("unchecked")
    static Snap snap(String label) throws Exception {
        Snap s = new Snap(); s.label = label; Object c = cs(), p = ps(), g = gm();
        grab(c, s.c); if (p != null) grab(p, s.p);
        s.days = (Integer) call(g, "getGameDays");
        s.researched = new ArrayList<String>((List<String>) read(c, "researchedTechs"));
        s.queue = new ArrayList<String>((List<String>) read(c, "researchQueue"));
        return s;
    }
    @SuppressWarnings("unchecked")
    static void restore(Snap s) throws Exception {
        Object c = cs(), p = ps();
        put(c, s.c); if (p != null) put(p, s.p);
        List<String> r = (List<String>) read(c, "researchedTechs"); r.clear(); r.addAll(s.researched);
        List<String> q = (List<String>) read(c, "researchQueue"); q.clear(); q.addAll(s.queue);
        try { call(c, "recomputeBaseIncomes"); } catch (Throwable e) { }
        try { call(gm(), "syncPlayerStateToCountry", c); } catch (Throwable e) { }
    }
    static void logHistory(String line) {
        String t = new java.text.SimpleDateFormat("HH:mm:ss").format(new Date());
        history.add(new String[]{t, line, "", "done"}); while (history.size() > 300) history.remove(0);
    }
    static void detail(String d) { synchronized (history) { if (!history.isEmpty()) history.get(history.size() - 1)[2] = d; } }
    static void markHistory(String from, String to) { synchronized (history) { for (int i = history.size() - 1; i >= 0; i--) if (history.get(i)[3].equals(from)) { history.get(i)[3] = to; return; } } }
    static void pushUndo(String label) { try { undo.addLast(snap(label)); while (undo.size() > 40) undo.removeFirst(); } catch (Throwable e) { } }

    // ---------------------------------------------------------------- protocol
    static final String[] MUTATING = {"set","add","lock","unlock","gainmult","flag","click","autoclick","techs","enqueue","upgrade","maxbuildings","speed","pause","dpt",
        "mul","reset","redo","histclear","vxset","vxreset","rset","planapply","mapset","setlevel","recalc","techunlock","focus","snapshot","restore","dequeue","opt","diag","console","preset","gov","rel","influence","puppet","undo","slot","sandbox","pop","debt","bankrupt","units","war","units","revealmap","tick"};
    static boolean isMutating(String c) { for (String m : MUTATING) if (m.equals(c)) return true; return false; }

    static boolean multiplayer() throws Exception {
        Object g = gm(); if (g == null) return false;
        if (Boolean.TRUE.equals(call(g, "isNetworkMode"))) return true;
        try { if (call(g, "getActiveMultiplayerManager") != null) return true; } catch (Throwable e) { }
        try { if (Boolean.TRUE.equals(call(g, "isHostInMultiplayer"))) return true; } catch (Throwable e) { }
        return false;
    }

    static String handle(String line) throws Exception {
        if (line.isEmpty()) return "OK|";
        String[] a = line.split("\\s+"); String cmd = a[0].toLowerCase(Locale.ROOT);
        if (cmd.equals("ping")) return "OK|pong";
        Object g = gm();
        if (cmd.equals("hello")) return "OK|" + (g == null ? "menu" : "game");
        if (g == null) return "ERR|NOGAME|" + noGameWhy();
        if (cs() == null) return "ERR|NOGAME|" + noGameWhy();
        boolean mp = multiplayer();
        if (mp && (isMutating(cmd))) return "ERR|MULTIPLAYER|Blocked: multiplayer/network game detected. This trainer is single-player only.";
        if (mp && cmd.equals("status")) return status(true);
        if (isMutating(cmd) && !cmd.equals("undo") && !cmd.equals("redo") && !cmd.equals("lock") && !cmd.equals("flag") && !cmd.equals("autoclick") && !cmd.equals("click") && !cmd.equals("unlock") && !cmd.equals("opt")) { pushUndo(line); redo.clear(); logHistory(line); }
        switch (cmd) {
            case "status": return status(mp);
            case "fields": return fields(a[1]);
            case "world": return world();
            case "upgrades": return "OK|" + upgrades();
            case "techs": return techs(a);
            case "enqueue": { List<String> q = qlist(); for (int i = 1; i < a.length; i++) if (!q.contains(a[i])) q.add(a[i]); return "OK|queued"; }
            case "dequeue": { qlist().clear(); return "OK|cleared"; }
            case "get": { Object o = tgt(a[1]); return "OK|" + read(o, a[2]); }
            case "set": return setf(a[1], a[2], parse(a[3]), false);
            case "add": return setf(a[1], a[2], parse(a[3]), true);
            case "lock": return lock(a);
            case "unlock": { if (a.length > 1 && !a[1].equals("all")) { locks.remove(a[1]); gainMult.remove(a[1]); } else { locks.clear(); gainMult.clear(); } return "OK|ok"; }
            case "gainmult": return gainmult(a);
            case "flag": { if (a[2].equals("on")) flags.add(a[1]); else flags.remove(a[1]); if (a.length > 3) opts.put(a[1], a[3]); return "OK|" + a[1] + "=" + a[2]; }
            case "opt": { opts.put(a[1], a[2]); return "OK|ok"; }
            case "click": { int n = (int) Math.min(100000, parse(a[1])); doClicks(n); return "OK|clicked " + n; }
            case "autoclick": { if (a[1].equals("on")) { flags.add("autoclick"); } else flags.remove("autoclick");
                if (a.length > 2) cps = Math.max(0.1, Math.min(2000, parse(a[2]))); if (a.length > 3) jitter = Math.max(0, Math.min(0.95, parse(a[3]) / 100.0)); if (a.length > 4) clickMul = (int) Math.max(1, Math.min(10000, parse(a[4]))); return "OK|ok"; }
            case "upgrade": return buy(a[1]);
            case "maxbuildings": return maxBuildings(a.length > 1 ? (int) parse(a[1]) : -1);
            case "speed": { final int v = (int) parse(a[1]); return onGame(new Callable<String>() { public String call() throws Exception { AocBridge.call(gm(), "setPlaySpeed", v); return "OK|speed " + v; } }); }
            case "dpt": { final int v = (int) parse(a[1]); return onGame(new Callable<String>() { public String call() throws Exception { AocBridge.call(gm(), "setDaysPerTick", v); return "OK|daysPerTick " + v; } }); }
            case "pause": { final boolean on = a[1].equals("on"); return onGame(new Callable<String>() { public String call() throws Exception { AocBridge.call(gm(), "setGamePaused", on); return "OK|paused=" + on; } }); }
            case "console": { final String txt = line.substring(7).trim(); return onGame(new Callable<String>() { public String call() throws Exception {
                Object ex = cls(P + "CommandExecutor").getConstructor().newInstance(); return "OK|" + AocBridge.call(ex, "execute", txt); } }); }
            case "focus": { final String b = a[1].toUpperCase(Locale.ROOT); return onGame(new Callable<String>() { public String call() throws Exception {
                Class<?> rr = cls(P + "ResearchRules"); String br = (String) rr.getField("BRANCH_" + b).get(null);
                Object r = AocBridge.call(rr, "applyFocus", cs(), br, AocBridge.call(gm(), "getGameDays")); return "OK|focus " + br + " -> " + r; } }); }
            case "setlevel": { final int idx = Integer.parseInt(a[1]); final String val = a[2]; return onGame(new Callable<String>() { public String call() throws Exception {
                String[] u = UPG[idx].split("\\|"); Object p = ps(); int lv = val.equals("max") ? ((Number) AocBridge.call(p, u[0].equals("University") ? "getMaxUniversityLevel" : "getMaxBuildingLevel")).intValue() : (int) parse(val);
                AocBridge.call(p, "set" + u[2] + "Level", lv); try { AocBridge.call(gm(), "syncPlayerStateToCountry", cs()); AocBridge.call(cs(), "recomputeBaseIncomes"); } catch (Throwable e) { }
                return "OK|" + u[0] + " level " + lv; } }); }
            case "recalc": return onGame(new Callable<String>() { public String call() throws Exception { try { AocBridge.call(gm(), "refreshResourceMultipliersNow"); } catch (Throwable e) { } AocBridge.call(cs(), "recomputeBaseIncomes"); return "OK|recalculated"; } });
            case "techunlock": { final String id = a[1]; return onGame(new Callable<String>() { public String call() throws Exception { AocBridge.call(cs(), "addTechnologyRecursively", id); try { AocBridge.call(cs(), "recomputeBaseIncomes"); } catch (Throwable e) { } return "OK|unlocked " + id; } }); }
            case "gov": return gov(a);
            case "rel": return relations(a);
            case "influence": return influence(a);
            case "puppet": return puppet(a);
            case "pop": return pop(parse(a[1]));
            case "debt": return debt(a[1], a.length > 2 ? parse(a[2]) : 0);
            case "bankrupt": return bankrupt(a[1].equals("on"));
            case "units": return units(a);
            case "sandbox": { final boolean on = a[1].equals("on"); return onGame(new Callable<String>() { public String call() throws Exception { AocBridge.call(gm(), "setSandboxMode", on); return "OK|sandbox=" + on; } }); }
            case "war": return war(a);
            case "preset": return preset(a[1]);
            case "snapshot": { int i = (int) parse(a[1]); slots[i] = snap("slot" + i); return "OK|saved slot " + i; }
            case "restore": { int i = (int) parse(a[1]); if (slots[i] == null) return "ERR|EMPTY|Slot is empty."; pushUndo("restore"); final Snap sn = slots[i]; return onGame(new Callable<String>() { public String call() throws Exception { restore(sn); return "OK|restored"; } }); }
            case "undo": { if (undo.isEmpty()) return "ERR|EMPTY|Nothing to undo."; final Snap sn = undo.removeLast(); locks.clear(); gainMult.clear(); redo.addLast(snap(sn.label)); markHistory("done", "undone");
                return onGame(new Callable<String>() { public String call() throws Exception { restore(sn); return "OK|Undid: " + sn.label; } }); }
            case "redo": { if (redo.isEmpty()) return "ERR|EMPTY|Nothing to redo."; final Snap sn = redo.removeLast(); undo.addLast(snap(sn.label)); markHistory("undone", "done");
                return onGame(new Callable<String>() { public String call() throws Exception { restore(sn); return "OK|Redid: " + sn.label; } }); }
            case "history": { StringBuilder sb = new StringBuilder("OK|"); synchronized (history) { for (int i = history.size() - 1; i >= 0; i--) { String[] h = history.get(i); sb.append(h[0]).append('\u001f').append(h[1]).append('\u001f').append(h[2]).append('\u001f').append(h[3]).append('\u001e'); } } return sb.toString(); }
            case "histclear": { undo.clear(); redo.clear(); history.clear(); return "OK|History cleared"; }
            case "mul": return mulf(a[1], a[2], parse(a[3]));
            case "reset": return resetf(a[1], a[2]);
            case "markthread": gameThread = Thread.currentThread(); return "OK|ok";
            case "diag": return "OK|" + lastError + " flags=" + flags + " locks=" + locks.keySet();
            case "shutdown": running = false; flags.clear(); locks.clear(); gainMult.clear(); return "OK|bridge stopped";
        }
        String ext = AocExt.handle(cmd, a, line);
        if (ext != null) return ext;
        return "ERR|UNKNOWN|Unknown command " + cmd;
    }
    static String mulf(String target, String field, double m) throws Exception { double cur = num(tgt(target), field); baseline(target + "." + field, cur); return setf(target, field, cur * m, false); }
    static String resetf(String target, String field) throws Exception {
        Double b = baselines.get(target + "." + field); if (b == null) return "ERR|NOBASE|No original value is recorded for " + field + " yet (it has not been changed by the trainer).";
        locks.remove(target + "." + field); gainMult.remove(target + "." + field); return setf(target, field, b, false);
    }

    @SuppressWarnings("unchecked") static List<String> qlist() throws Exception { return (List<String>) read(cs(), "researchQueue"); }

    // ---------------------------------------------------------------- read commands
    static final String[] STATS = {"gold","iron","coal","oil","timber","rubber","aluminum","uranium","copper","manpower","steel","fuel","ammo","mechParts","electronics","trucks","consumerGoods",
        "infantry","artillery","tanks","aircraft","ships","nuclearWeapons","baseGoldIncome","lastNetGoldIncome","lastGrossGold","lastMgmtCost","lastArmyCost","marketDebt","reparationsDebtRemaining","creditRating",
        "livingStandard","warExhaustion","nuclearDevastation","sciencePoints","libertyDesire","infamy","territorySize","populationBonus","growthModifier","targetTaxation","targetConscription",
        "targetMilitarySpending","targetScienceFunding","targetSocialSecurity","targetWarEconomy","diplomacyPoints","playerRelation","supportDemocracy","supportAuthoritarianism","supportTotalitarianism","supportCommunism",
        "revolutionRisk","strikeRisk","rebellionStage","hasEpidemic","isPuppet","isAlly","baseIronIncome","baseCoalIncome","baseOilIncome","baseTimberIncome","baseRubberIncome","baseAluminumIncome","baseUraniumIncome","baseCopperIncome","baseManpowerIncome",
        "marketDailyPayment","marketMissedPayments"};
    static final String[] DERIVED = {"getTotalPopulation","getHappinessPercent","getWorkersCount","getMilitaryCount","getConscriptedCount","getDailyScienceRate","getDynamicGoldIncomePerSec","getTerritorySize","calculateTotalStrength","getMarketInterestRate","getMaxMarketLoan","getName","getTag"};

    static String status(boolean mp) throws Exception {
        Object g = gm(), c = cs(); StringBuilder sb = new StringBuilder("OK|");
        sb.append("mp=").append(mp ? 1 : 0);
        sb.append('\t').append("sandbox=").append(call(g, "isSandboxMode"));
        sb.append('\t').append("paused=").append(call(g, "isGamePaused"));
        sb.append('\t').append("speed=").append(call(g, "getPlaySpeed"));
        sb.append('\t').append("days=").append(call(g, "getGameDays"));
        try { sb.append('\t').append("date=").append(call(cls(P + "GameManager"), "formatGameDate", call(g, "getGameDays"))); } catch (Throwable e) { }
        try { sb.append('\t').append("dpt=").append(call(g, "getDaysPerTick")); } catch (Throwable e) { }
        try { sb.append('\t').append("effspeed=").append(call(g, "getEffectiveSpeed")); } catch (Throwable e) { }
        for (String s : STATS) { Object v = read(c, s); if (v != null) sb.append('\t').append(s).append('=').append(v); }
        for (String s : DERIVED) { Object v = read(c, s); if (v != null) sb.append('\t').append(s).append('=').append(v); }
        Object gf = read(c, "currentForm"); if (gf != null) sb.append('\t').append("govForm=").append(gf);
        Object tc = read(c, "targetCourse"); if (tc != null) sb.append('\t').append("govCourse=").append(tc);
        sb.append('\t').append("researched=").append(qlist2("researchedTechs")).append('\t').append("queued=").append(qlist2("researchQueue"));
        sb.append('\t').append("focus=").append(read(c, "researchFocusBranch"));
        sb.append('\t').append("flags=").append(flags.toString().replace(" ", ""));
        sb.append('\t').append("locks=").append(locks.keySet().toString().replace(" ", ""));
        sb.append('\t').append("gm=").append(gainMult.toString().replace(" ", ""));
        { StringBuilder ld = new StringBuilder(); for (Map.Entry<String,double[]> e : locks.entrySet()) { if (ld.length() > 0) ld.append('|'); ld.append(e.getKey()).append(':').append((int) e.getValue()[0] == 0 ? "exact" : (int) e.getValue()[0] == 1 ? "floor" : "ceil").append(':').append(String.format("%.0f", e.getValue()[1])); } sb.append('\t').append("lockd=").append(ld); }
        sb.append('\t').append("cps=").append(cps).append('\t').append("jit=").append(jitter).append('\t').append("cmul=").append(clickMul);
        sb.append('\t').append("undo=").append(undo.size());
        for (int i = 0; i < slots.length; i++) if (slots[i] != null) sb.append('\t').append("slot").append(i).append("=1");
        sb.append('\t').append("err=").append(lastError.replace('\t', ' '));
        return sb.toString();
    }
    static int qlist2(String n) { Object v = read(cs0(), n); return v instanceof List ? ((List<?>) v).size() : -1; }
    static Object cs0() { try { return cs(); } catch (Exception e) { return null; } }

    static String fields(String which) throws Exception {
        Object o = tgt(which); StringBuilder sb = new StringBuilder("OK|"); boolean first = true;
        List<Field> all = new ArrayList<Field>();
        for (Class<?> k = o.getClass(); k != null && k != Object.class; k = k.getSuperclass()) all.addAll(Arrays.asList(k.getDeclaredFields()));
        for (Field f : all) {
            int md = f.getModifiers(); if (Modifier.isStatic(md)) continue;
            Class<?> t = f.getType(); if (!(t.isPrimitive() || t == String.class || t.isEnum())) continue;
            try { f.setAccessible(true); Object v = f.get(o); if (!first) sb.append('\t'); first = false;
                sb.append(f.getName()).append(':').append(t.getSimpleName()).append(':').append(v).append(':').append(Modifier.isFinal(md) ? 'F' : 'W'); } catch (Throwable e) { }
        }
        return sb.toString();
    }

    @SuppressWarnings("unchecked")
    static String world() throws Exception {
        Object g = gm(); Map<String,Object> m = (Map<String,Object>) call(g, "getWorldCountries"); Object me = cs();
        StringBuilder sb = new StringBuilder("OK|"); boolean first = true;
        for (Map.Entry<String,Object> e : m.entrySet()) {
            Object c = e.getValue(); if (!first) sb.append('\u001e'); first = false;
            sb.append(e.getKey()).append('\u001f').append(read(c, "tag")).append('\u001f').append(read(c, "territorySize")).append('\u001f').append(read(c, "gold")).append('\u001f')
              .append(read(c, "getTotalPopulation")).append('\u001f').append(read(c, "playerRelation")).append('\u001f').append(read(c, "isAlly")).append('\u001f')
              .append(read(c, "isPuppet")).append('\u001f').append(c == me ? 1 : 0).append('\u001f').append(read(c, "calculateTotalStrength")).append('\u001f').append(read(c, "currentForm"));
        }
        return sb.toString();
    }

    static String upgrades() throws Exception {
        Object p = ps(), c = cs(); StringBuilder sb = new StringBuilder(); int max = ((Number) call(p, "getMaxBuildingLevel")).intValue();
        long gold = ((Number) read(c, "gold")).longValue();
        for (int i = 0; i < UPG.length; i++) {
            String[] u = UPG[i].split("\\|"); if (i > 0) sb.append('\u001e');
            long cost = -1; int lvl = -1;
            try { cost = ((Number) call(p, u[1])).longValue(); } catch (Throwable e) { }
            try { lvl = ((Number) call(p, "get" + u[2] + "Level")).intValue(); } catch (Throwable e) { }
            boolean pre = true; // prerequisites check needs enum; best effort via buy attempt
            sb.append(u[0]).append('\u001f').append(lvl).append('\u001f').append(cost).append('\u001f').append(max).append('\u001f').append(u[4]).append('\u001f').append(i).append('\u001f').append(cost >= 0 && cost <= gold ? 1 : 0);
        }
        return sb.toString();
    }

    @SuppressWarnings("unchecked")
    static String techs(String[] a) throws Exception {
        final Object c = cs(); Class<?> T = cls(P + "Technology");
        List<Object> all = (List<Object>) T.getField("ALL_TECHNOLOGIES").get(null);
        String sub = a.length > 1 ? a[1] : "list";
        if (sub.equals("list")) {
            int days = (Integer) call(gm(), "getGameDays"); StringBuilder sb = new StringBuilder("OK|"); List<String> done = (List<String>) read(c, "researchedTechs"); boolean first = true;
            for (Object t : all) { if (!first) sb.append('\u001e'); first = false; boolean can = false;
                try { can = (Boolean) call(T, "isResearchable", t, c, days); } catch (Throwable e) { }
                String id = String.valueOf(read(t, "id"));
                sb.append(id).append('\u001f').append(read(t, "branch")).append('\u001f').append(read(t, "epoch")).append('\u001f').append(read(t, "baseScienceCost")).append('\u001f').append(done.contains(id) ? 1 : 0).append('\u001f').append(can ? 1 : 0); }
            return sb.toString();
        }
        if (sub.equals("reset")) { ((List<String>) read(c, "researchedTechs")).clear(); qlist().clear(); try { call(c, "recomputeBaseIncomes"); } catch (Throwable e) { } return "OK|research reset"; }
        final String branch = sub.equals("all") ? null : sub; final int[] n = {0};
        final List<Object> list = all;
        return onGame(new Callable<String>() { public String call() throws Exception {
            for (Object t : list) { String b = String.valueOf(read(t, "branch")); if (branch != null && !b.toLowerCase(Locale.ROOT).contains(branch.toLowerCase(Locale.ROOT))) continue;
                try { AocBridge.call(c, "addTechnologyRecursively", String.valueOf(read(t, "id"))); n[0]++; } catch (Throwable e) { lastError = "tech: " + e; } }
            try { AocBridge.call(c, "recomputeBaseIncomes"); } catch (Throwable e) { }
            try { qlist().clear(); } catch (Throwable e) { }
            return "OK|unlocked " + n[0] + " technologies";
        } });
    }

    // ---------------------------------------------------------------- write commands
    static String setf(final String target, final String field, final double v, final boolean add) throws Exception {
        return onGame(new Callable<String>() { public String call() throws Exception {
            Object o = tgt(target); Field f = fld(o.getClass(), field);
            if (f == null) {   // maybe a setter exists (PlayerState levels, etc.)
                String setter = "set" + Character.toUpperCase(field.charAt(0)) + field.substring(1);
                double cur = Double.isNaN(num(o, field)) ? 0 : num(o, field);
                AocBridge.call(o, setter, add ? cur + v : v); return "OK|via " + setter;
            }
            double cur = num(o, field); baseline(target + "." + field, cur); write(o, field, add ? cur + v : v); detail(field + ": " + fmtNum(cur) + " -> " + fmtNum(num(o, field)));
            if (field.endsWith("Level")) { try { AocBridge.call(gm(), "syncPlayerStateToCountry", cs()); AocBridge.call(cs(), "recomputeBaseIncomes"); } catch (Throwable e) { } }
            return "OK|" + field + "=" + read(o, field);
        } });
    }
    static String lock(String[] a) {   // lock target.field mode [value]
        String key = a[1];
        if (a[2].equals("off")) { locks.remove(key); return "OK|unlocked"; }
        int mode = a[2].equals("floor") ? 1 : a[2].equals("ceil") ? 2 : 0;
        double val;
        try { if (a.length > 3) val = parse(a[3]); else { String[] k = splitKey(key); val = num(tgt(k[0]), k[1]); baseline(key, val); } } catch (Throwable e) { return "ERR|BAD|" + e; }
        locks.put(key, new double[]{mode, val}); return "OK|locked " + key;
    }
    static String gainmult(String[] a) {
        double m = parse(a[2]);
        String[] keys = a[1].equals("resources") ? new String[]{"iron","coal","oil","timber","rubber","aluminum","uranium","copper","steel","fuel","ammo","mechParts","electronics","trucks","consumerGoods","manpower"} : new String[]{a[1]};
        for (String k : keys) { String key = k.contains(".") ? k : "country." + k; if (m == 1) gainMult.remove(key); else gainMult.put(key, m); }
        return "OK|multiplier " + m + " on " + a[1];
    }
    static void doClicks(int n) throws Exception {
        final int k = n; onGame(new Callable<String>() { public String call() throws Exception { Object g = gm(); for (int i = 0; i < k; i++) AocBridge.call(g, "performManualClick"); return "ok"; } });
    }
    static String buy(String idx) throws Exception {
        final int i = Integer.parseInt(idx);
        return onGame(new Callable<String>() { public String call() throws Exception { return "OK|" + buyIdx(i); } });
    }
    static String buyIdx(int i) throws Exception {
        String[] u = UPG[i].split("\\|"); Object p = ps(); int before = ((Number) call(p, "get" + u[2] + "Level")).intValue();
        call(p, "upgrade" + u[3]); int after = ((Number) call(p, "get" + u[2] + "Level")).intValue();
        return u[0] + " " + before + " -> " + after;
    }
    static String maxBuildings(final int lvl) throws Exception {
        return onGame(new Callable<String>() { public String call() throws Exception {
            Object p = ps(); int max = lvl > 0 ? lvl : ((Number) AocBridge.call(p, "getMaxBuildingLevel")).intValue(); int n = 0;
            for (String row : UPG) { String[] u = row.split("\\|"); int m = u[0].equals("University") ? ((Number) AocBridge.call(p, "getMaxUniversityLevel")).intValue() : max;
                try { AocBridge.call(p, "set" + u[2] + "Level", Math.max(m, 0)); n++; } catch (Throwable e) { lastError = "lvl " + u[0] + ": " + e; } }
            try { AocBridge.call(gm(), "syncPlayerStateToCountry", cs()); } catch (Throwable e) { }
            try { AocBridge.call(cs(), "recomputeBaseIncomes"); } catch (Throwable e) { }
            try { AocBridge.call(gm(), "refreshResourceMultipliersNow"); } catch (Throwable e) { }
            return "OK|set " + n + " buildings to level " + max;
        } });
    }
    @SuppressWarnings({"unchecked","rawtypes"})
    static String gov(String[] a) throws Exception {
        final Object c = cs(); Class<?> gf = cls(P + "GovernmentForm");
        if (a[1].equals("list")) { StringBuilder sb = new StringBuilder("OK|"); for (Object e : gf.getEnumConstants()) sb.append(e).append('\t'); return sb.toString(); }
        final Object val = Enum.valueOf((Class) gf, a[2]);
        final boolean course = a[1].equals("course");
        return onGame(new Callable<String>() { public String call() throws Exception {
            if (course) { write2(c, "targetCourse", val); return "OK|course set"; }
            write2(c, "currentForm", val); write2(c, "targetCourse", val); try { AocBridge.call(c, "setStartingGovernmentForm", val); } catch (Throwable e) { }
            try { AocBridge.call(c, "updateRegimeSupportsFromForms"); } catch (Throwable e) { } return "OK|government changed"; } });
    }
    static void write2(Object o, String n, Object v) throws Exception { Field f = fld(o.getClass(), n); if (f == null) throw new Exception("no field " + n); f.set(o, v); }

    @SuppressWarnings("unchecked")
    static String relations(String[] a) throws Exception {   // rel all <v>   |  rel <country name...> <v>
        final int v = (int) Math.max(-100, Math.min(100, parse(a[a.length - 1])));
        final String who = a[1].equals("all") ? null : line2(a, 1, a.length - 1);
        return onGame(new Callable<String>() { public String call() throws Exception {
            Object c = cs(); Map<String,Object> w = (Map<String,Object>) AocBridge.call(gm(), "getWorldCountries"); String me = String.valueOf(AocBridge.call(c, "getName")); int n = 0;
            for (Map.Entry<String,Object> e : w.entrySet()) { if (e.getValue() == c) continue; if (who != null && !e.getKey().equalsIgnoreCase(who)) continue;
                try { AocBridge.call(c, "setAiRelation", e.getKey(), v); AocBridge.call(e.getValue(), "setAiRelation", me, v); n++; } catch (Throwable x) { lastError = "rel: " + x; } }
            return "OK|relations set to " + v + " with " + n + " countries"; } });
    }
    static String line2(String[] a, int from, int to) { StringBuilder s = new StringBuilder(); for (int i = from; i < to; i++) { if (s.length() > 0) s.append(' '); s.append(a[i]); } return s.toString(); }
    @SuppressWarnings("unchecked")
    static String influence(String[] a) throws Exception {
        final int v = (int) parse(a[a.length - 1]); final String who = a[1].equals("all") ? null : line2(a, 1, a.length - 1);
        return onGame(new Callable<String>() { public String call() throws Exception {
            Object c = cs(); Map<String,Object> w = (Map<String,Object>) AocBridge.call(gm(), "getWorldCountries"); int n = 0;
            for (String k : w.keySet()) { if (w.get(k) == c) continue; if (who != null && !k.equalsIgnoreCase(who)) continue; try { AocBridge.call(c, "setInfluence", k, v); n++; } catch (Throwable x) { } }
            return "OK|influence set on " + n; } });
    }
    @SuppressWarnings("unchecked")
    static String puppet(String[] a) throws Exception {   // puppet on|off <country>
        final boolean on = a[1].equals("on"); final String who = line2(a, 2, a.length);
        return onGame(new Callable<String>() { public String call() throws Exception {
            Map<String,Object> w = (Map<String,Object>) AocBridge.call(gm(), "getWorldCountries"); Object t = null;
            for (Map.Entry<String,Object> e : w.entrySet()) if (e.getKey().equalsIgnoreCase(who)) t = e.getValue();
            if (t == null) return "ERR|NOTFOUND|No such country: " + who; if (t == cs()) return "ERR|BAD|That's your own country.";
            AocBridge.call(t, "setPuppet", on, on ? String.valueOf(AocBridge.call(cs(), "getName")) : ""); return "OK|puppet=" + on + " for " + who; } });
    }
    static String pop(final double target) throws Exception {
        return onGame(new Callable<String>() { public String call() throws Exception {
            Object c = cs(); long cur = ((Number) AocBridge.call(c, "getTotalPopulation")).longValue(); long bonus = ((Number) read(c, "populationBonus")).longValue();
            write(c, "populationBonus", bonus + (target - cur)); long now = ((Number) AocBridge.call(c, "getTotalPopulation")).longValue(); return "OK|population " + cur + " -> " + now; } });
    }
    static String debt(final String what, final double v) throws Exception {
        return onGame(new Callable<String>() { public String call() throws Exception {
            Object c = cs();
            if (what.equals("repay")) { write(c, "marketDebt", 0); write(c, "marketDailyPayment", 0); write(c, "reparationsDebtRemaining", 0); write(c, "marketMissedPayments", 0);
                try { List<?> l = new ArrayList<Object>((List<?>) read(c, "loansTaken")); for (Object o : l) AocBridge.call(c, "removeLoanTaken", o); } catch (Throwable e) { }
                return "OK|all debts repaid"; }
            write(c, "marketDebt", v); return "OK|marketDebt=" + v; } });
    }
    static String bankrupt(final boolean on) throws Exception {
        return onGame(new Callable<String>() { public String call() throws Exception {
            Object c = cs();
            if (on) { write(c, "gold", -2e9); write(c, "marketMissedPayments", 5); return "OK|bankrupt (gold = -2,000,000,000)"; }
            if (num(c, "gold") < 0) write(c, "gold", 1e6); write(c, "marketMissedPayments", 0); write(c, "marketDefaultCooldown", 0); write(c, "marketDebt", 0); return "OK|bankruptcy cleared"; } });
    }
    @SuppressWarnings("unchecked")
    static List<Object> myUnits() throws Exception {
        Object wm = call(gm(), "getWarManager"); Object um = null;
        for (Method m : wm.getClass().getMethods()) if (m.getParameterTypes().length == 0 && m.getReturnType().getSimpleName().equals("UnitManager")) { um = m.invoke(wm); break; }
        if (um == null) { for (Class<?> k = wm.getClass(); k != null && um == null; k = k.getSuperclass()) for (Field f : k.getDeclaredFields()) if (f.getType().getSimpleName().equals("UnitManager")) { f.setAccessible(true); um = f.get(wm); break; } }
        if (um == null) throw new Exception("UnitManager not found");
        return new ArrayList<Object>((List<Object>) call(um, "getUnits"));
    }
    static int restoreUnits(boolean onlyMine) throws Exception {
        int n = 0; Object c = cs(); int myKey = -1;
        List<Object> us = myUnits();
        for (Object u : us) {
            try { Field st = fld(u.getClass(), "strength"), mx = fld(u.getClass(), "maxStrength"); if (st == null || mx == null) continue;
                Object ow = read(u, "ownerColorKey"); 
                if (onlyMine && ow != null) { Object my = read(c, "colorKey"); if (my == null) my = read(c, "colorId"); if (my != null && !my.equals(ow)) continue; }
                st.set(u, mx.get(u)); Field org = fld(u.getClass(), "organization"), mo = fld(u.getClass(), "maxOrganization");
                if (org != null && mo != null) org.set(u, mo.get(u)); else if (org != null && org.getType() == float.class && org.getFloat(u) < 1f) org.setFloat(u, 1f);
                Field sp = fld(u.getClass(), "supply"); if (sp != null && sp.getType() == float.class) sp.setFloat(u, Math.max(sp.getFloat(u), 1f));
                n++; } catch (Throwable e) { }
        }
        return n;
    }
    static String units(String[] a) throws Exception {
        if (a[1].equals("heal")) { return onGame(new Callable<String>() { public String call() throws Exception { return "OK|restored " + restoreUnits(true) + " units"; } }); }
        if (a[1].equals("list")) { return onGame(new Callable<String>() { public String call() throws Exception { StringBuilder sb = new StringBuilder("OK|"); int i = 0;
            for (Object u : myUnits()) { if (i++ > 300) break; sb.append(read(u, "name")).append('\u001f').append(read(u, "strength")).append('\u001f').append(read(u, "maxStrength")).append('\u001f').append(read(u, "organization")).append('\u001f').append(read(u, "supply")).append('\u001e'); } return sb.toString(); } }); }
        return "ERR|BAD|units heal|list";
    }
    static String war(String[] a) throws Exception {
        final String sub = a[1];
        return onGame(new Callable<String>() { public String call() throws Exception {
            Object c = cs();
            if (sub.equals("exhaustion0")) { AocBridge.call(c, "setWarExhaustion", 0f); write(c, "nuclearDevastation", 0); return "OK|war exhaustion & devastation cleared"; }
            if (sub.equals("nocapitulation")) { AocBridge.call(gm(), "setCapitulationDisabled", true); return "OK|capitulation disabled"; }
            if (sub.equals("capitulation")) { AocBridge.call(gm(), "setCapitulationDisabled", false); return "OK|capitulation enabled"; }
            if (sub.equals("noai")) { AocBridge.call(gm(), "setAiDisabled", true); return "OK|AI disabled"; }
            if (sub.equals("ai")) { AocBridge.call(gm(), "setAiDisabled", false); return "OK|AI enabled"; }
            return "ERR|BAD|unknown war subcommand"; } });
    }

    static String preset(String name) throws Exception {
        String[] RES = {"iron","coal","oil","timber","rubber","aluminum","uranium","copper","steel","fuel","ammo","mechParts","electronics","trucks","consumerGoods","manpower"};
        StringBuilder log = new StringBuilder();
        switch (name) {
            case "infinite_economy":
                lockF("country.gold", 9e12); for (String r : RES) lockF("country." + r, 9e12); log.append("Gold + all resources locked at 9 trillion minimum. "); break;
            case "superpower":
                lockF("country.gold", 9e12); for (String r : RES) lockF("country." + r, 9e12); handle("techs all"); handle("maxbuildings"); handle("rel all 100"); flags.add("godunits");
                for (String u : new String[]{"infantry","artillery","tanks","aircraft","ships"}) setf("country", u, 5e6, false); log.append("Economy, tech, buildings, relations, army maxed. "); break;
            case "tiny_nation":
                setf("country", "gold", 5000, false); for (String r : RES) setf("country", r, 100, false); for (String u : new String[]{"infantry","artillery","tanks","aircraft","ships"}) setf("country", u, 0, false);
                log.append("Gold 5000, resources 100, army 0 (undo available). "); break;
            case "max_research":
                handle("techs all"); gainMult.put("country.sciencePoints", 10.0); flags.add("instantresearch"); lockF("country.sciencePoints", 1e9); log.append("All techs, x10 science, instant research. "); break;
            case "sandbox":
                handle("sandbox on"); log.append("Sandbox mode enabled (use the game's own editors). "); break;
            case "god_mode":
                handle("preset infinite_economy"); flags.add("nocooldown"); flags.add("godunits"); flags.add("norebellion"); flags.add("noepidemic"); handle("war nocapitulation");
                locks.put("country.warExhaustion", new double[]{0, 0}); locks.put("country.nuclearDevastation", new double[]{0, 0}); log.append("Infinite economy, no cooldowns, invincible units, no unrest/epidemics, no capitulation. "); break;
            case "afk":
                flags.add("autoclick"); flags.add("autobuy"); flags.add("autoresearch"); flags.add("nocooldown"); log.append("Autoclick + auto-upgrade + auto-research on. "); break;
            default: return "ERR|UNKNOWN|Unknown preset";
        }
        return "OK|" + log;
    }
    static void lockF(String key, double v) { locks.put(key, new double[]{1, v}); }

    // ---------------------------------------------------------------- tick (runs on the game thread)
    @SuppressWarnings("unchecked")
    static void tick() throws Exception {
        gameThread = Thread.currentThread();
        if (multiplayer()) { flags.clear(); locks.clear(); gainMult.clear(); return; }
        Object c = cs(); if (c == null) return;
        long now = System.currentTimeMillis(); double dt = lastTickMs == 0 ? 0.04 : Math.min(0.5, (now - lastTickMs) / 1000.0); lastTickMs = now;
        // gain multipliers (before locks so locks win)
        for (Map.Entry<String,Double> e : gainMult.entrySet()) {
            String[] k = splitKey(e.getKey()); Object o = tgt(k[0]); double cur = num(o, k[1]); Double p = prev.get(e.getKey());
            if (p != null && cur > p && !Double.isNaN(cur)) { double add = (cur - p) * (e.getValue() - 1); if (add > 0) { write(o, k[1], cur + add); cur += add; } }
            prev.put(e.getKey(), cur);
        }
        for (Iterator<String> it = prev.keySet().iterator(); it.hasNext();) if (!gainMult.containsKey(it.next())) it.remove();
        for (Map.Entry<String,double[]> e : locks.entrySet()) {
            String[] k = splitKey(e.getKey()); Object o; try { o = tgt(k[0]); } catch (Throwable x) { continue; } if (o == null) continue;
            double cur = num(o, k[1]), m = e.getValue()[0], v = e.getValue()[1];
            if (Double.isNaN(cur)) continue;
            if ((m == 0 && cur != v) || (m == 1 && cur < v) || (m == 2 && cur > v)) write(o, k[1], v);
        }
        if (flags.contains("autoclick")) {
            double eff = cps * (1 + (rnd.nextDouble() * 2 - 1) * jitter); clickAcc += eff * dt;
            int n = (int) clickAcc; clickAcc -= n; n = Math.min(n, 400);
            Object g = gm(); for (int i = 0; i < n; i++) for (int j = 0; j < clickMul; j++) call(g, "performManualClick");
        }
        if (flags.contains("nocooldown")) { for (String f : new String[]{"autoclickerCooldownEnd","diploClickerCooldownEnd","milClickerCooldownEnd"}) { if (fld(c.getClass(), f) != null) write(c, f, 0); } }
        if (flags.contains("godunits")) { try { restoreUnits(true); } catch (Throwable e) { lastError = "units: " + e; } }
        if (flags.contains("noepidemic")) { if (fld(c.getClass(), "hasEpidemic") != null) write(c, "hasEpidemic", 0); write(c, "epidemicSeverity", 0); }
        if (flags.contains("norebellion")) { write(c, "rebellionStage", 0); write(c, "revolutionRisk", 0); write(c, "strikeRisk", 0); }
        if (flags.contains("pauselock")) call(gm(), "setGamePaused", true);
        if (flags.contains("instantconstruction")) { try { call(c, "advanceConstruction", 1000f); } catch (Throwable e) { lastError = "construction: " + e; flags.remove("instantconstruction"); } }
        if (flags.contains("instantresearch")) {
            List<String> q = qlist(); if (!q.isEmpty()) { for (String id : new ArrayList<String>(q)) { try { call(c, "addTechnologyRecursively", id); } catch (Throwable e) { } } q.clear(); try { call(c, "recomputeBaseIncomes"); } catch (Throwable e) { } } }
        if (now - lastSlowMs > 1000) { lastSlowMs = now;
            if (flags.contains("autobuy")) autoBuy(c);
            if (flags.contains("autoresearch")) autoResearch(c);
        }
    }
    static void autoBuy(Object c) throws Exception {
        String cats = opts.containsKey("autobuy") ? opts.get("autobuy") : "eco,raw,prod,mil,sci,dip";
        Object p = ps(); int max = ((Number) call(p, "getMaxBuildingLevel")).intValue();
        long gold = ((Number) read(c, "gold")).longValue(); int best = -1; long bc = Long.MAX_VALUE;
        for (int i = 0; i < UPG.length; i++) { String[] u = UPG[i].split("\\|"); if (!cats.contains(u[4])) continue;
            try { long cost = ((Number) call(p, u[1])).longValue(); int lvl = ((Number) call(p, "get" + u[2] + "Level")).intValue();
                int mx = u[0].equals("University") ? ((Number) call(p, "getMaxUniversityLevel")).intValue() : max;
                if (lvl < mx && cost >= 0 && cost <= gold && cost < bc) { bc = cost; best = i; } } catch (Throwable e) { } }
        if (best >= 0) { try { buyIdx(best); } catch (Throwable e) { lastError = "autobuy: " + e; } }
    }
    @SuppressWarnings("unchecked")
    static void autoResearch(Object c) throws Exception {
        List<String> q = qlist(); if (q.size() >= 3) return;
        Class<?> T = cls(P + "Technology"); List<Object> all = (List<Object>) T.getField("ALL_TECHNOLOGIES").get(null); List<String> done = (List<String>) read(c, "researchedTechs");
        int days = (Integer) call(gm(), "getGameDays"); String br = opts.containsKey("autoresearch") ? opts.get("autoresearch") : "all"; Object best = null; double bc = 1e18;
        for (Object t : all) { String id = String.valueOf(read(t, "id")); if (done.contains(id) || q.contains(id)) continue;
            if (!br.equals("all") && !String.valueOf(read(t, "branch")).toLowerCase(Locale.ROOT).contains(br)) continue;
            boolean can = false; try { can = (Boolean) call(T, "isResearchable", t, c, days); } catch (Throwable e) { } if (!can) continue;
            double cost = num(t, "baseScienceCost"); if (cost < bc) { bc = cost; best = t; } }
        if (best != null) q.add(String.valueOf(read(best, "id")));
    }
}
