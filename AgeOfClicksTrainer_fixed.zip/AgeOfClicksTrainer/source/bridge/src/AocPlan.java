import java.lang.reflect.*;
import java.util.*;
import java.util.concurrent.Callable;

/**
 * Economy planner: given desired production per resource, finds the building levels that reach it, using the
 * game's own cost functions and by measuring the effect of each level on the live economy. The simulation is run
 * on the game thread and rolled back exactly; nothing changes until "planapply".
 */
class AocPlan {
    static final char RS = '\u001e', US = '\u001f';
    static final Map<String,String[]> BUILD = new LinkedHashMap<>();
    static {
        BUILD.put("gold", new String[]{"Auto Income", "Tax Office", "Trade Post", "Finance"});
        BUILD.put("iron", new String[]{"Iron Mine"}); BUILD.put("coal", new String[]{"Coal Mine"}); BUILD.put("oil", new String[]{"Oil Well"}); BUILD.put("timber", new String[]{"Sawmill"});
        BUILD.put("rubber", new String[]{"Rubber Plantation"}); BUILD.put("aluminum", new String[]{"Aluminum Mine"}); BUILD.put("uranium", new String[]{"Uranium Mine"}); BUILD.put("copper", new String[]{"Copper Mine"});
        BUILD.put("steel", new String[]{"Steel Mill"}); BUILD.put("fuel", new String[]{"Oil Refinery"}); BUILD.put("ammo", new String[]{"Munitions Factory"}); BUILD.put("mechParts", new String[]{"Parts Workshop"});
        BUILD.put("electronics", new String[]{"Electronics Plant"}); BUILD.put("trucks", new String[]{"Auto Plant"}); BUILD.put("consumerGoods", new String[]{"Light Industry"});
        BUILD.put("infantry", new String[]{"Barracks"}); BUILD.put("artillery", new String[]{"Artillery Factory"}); BUILD.put("tanks", new String[]{"Tank Factory"});
        BUILD.put("aircraft", new String[]{"Aircraft Factory"}); BUILD.put("ships", new String[]{"Naval Shipyard"}); BUILD.put("nuclearWeapons", new String[]{"Nuclear Reactor"});
    }
    static int[] lastLevels; static long lastCost; static boolean hasPlan;

    static int idxOf(String label) { for (int i = 0; i < AocBridge.UPG.length; i++) if (AocBridge.UPG[i].startsWith(label + "|")) return i; return -1; }
    static String[] row(int i) { return AocBridge.UPG[i].split("\\|"); }
    static int level(Object p, int i) throws Exception { return ((Number) AocBridge.call(p, "get" + row(i)[2] + "Level")).intValue(); }
    static long cost(Object p, int i) throws Exception { return ((Number) AocBridge.call(p, row(i)[1])).longValue(); }
    static void setLevel(Object p, int i, int lv) throws Exception { AocBridge.call(p, "set" + row(i)[2] + "Level", lv); }
    static void refresh(Object c) { try { AocBridge.call(AocBridge.gm(), "syncPlayerStateToCountry", c); } catch (Throwable t) { } try { AocBridge.call(c, "recomputeBaseIncomes"); } catch (Throwable t) { } }

    /** measure variants, tried in order until one reacts to a level change */
    static double measure(Object c, String key, int mode) throws Exception {
        if (mode == 0) { Object v = key.equals("gold") ? AocBridge.read(c, "getDynamicGoldIncomePerSec") : null; if (v instanceof Number) return ((Number) v).doubleValue(); return Double.NaN; }
        if (mode == 1) { Object v = AocWorld.invokeStatic(AocBridge.cls(AocBridge.P + "ResourceLedger"), "gross", c.getClass(), c, key); return v instanceof Number ? ((Number) v).doubleValue() : Double.NaN; }
        String f = "base" + Character.toUpperCase(key.charAt(0)) + key.substring(1) + "Income"; double v = AocBridge.num(c, f); return v;
    }

    static String plan(final String[] args) throws Exception {
        final Map<String,Double> want = new LinkedHashMap<>();
        for (String s : args) { int e = s.indexOf('='); if (e > 0) want.put(s.substring(0, e), AocBridge.parse(s.substring(e + 1))); }
        if (want.isEmpty()) return "ERR|BAD|No targets given.";
        return AocBridge.onGame(new Callable<String>() { public String call() throws Exception {
            Object c = AocBridge.cs(), p = AocBridge.ps(); int n = AocBridge.UPG.length; int max = ((Number) AocBridge.call(p, "getMaxBuildingLevel")).intValue();
            int[] start = new int[n]; for (int i = 0; i < n; i++) { try { start[i] = level(p, i); } catch (Throwable t) { start[i] = -1; } }
            int[] work = start.clone(); long total = 0; StringBuilder res = new StringBuilder(); int iterations = 0;
            try {
                for (Map.Entry<String,Double> w : want.entrySet()) {
                    String key = w.getKey(); double target = w.getValue(); String[] labels = BUILD.get(key);
                    if (labels == null) { res.append(key).append(US).append(target).append(US).append("").append(US).append("").append(US).append("0").append(US).append("No production building is known for this resource.").append(RS); continue; }
                    List<Integer> cand = new ArrayList<>(); for (String l : labels) { int i = idxOf(l); if (i >= 0 && start[i] >= 0) cand.add(i); }
                    // choose a measuring method that reacts to a level change
                    int mode = -1; double base0 = Double.NaN;
                    for (int m = 0; m < 3 && mode < 0 && !cand.isEmpty(); m++) { double a = measure(c, key, m); if (Double.isNaN(a)) continue; int i = cand.get(0); if (work[i] >= max) continue;
                        setLevel(p, i, work[i] + 1); refresh(c); double b = measure(c, key, m); setLevel(p, i, work[i]); refresh(c); if (b != a) { mode = m; base0 = a; } }
                    if (mode < 0) { res.append(key).append(US).append(target).append(US).append("").append(US).append("").append(US).append("0").append(US).append("Production of this resource did not react to building levels, so it cannot be planned reliably.").append(RS); continue; }
                    double curv = measure(c, key, mode), first = curv; long spent = 0; String note = "";
                    while (curv < target && iterations++ < 1500) {
                        int bestI = -1; double bestScore = -1; long bestCost = 0;
                        for (int i : cand) { if (work[i] >= max) continue; long cst = cost(p, i); setLevel(p, i, work[i] + 1); refresh(c); double gain = measure(c, key, mode) - curv; setLevel(p, i, work[i]); refresh(c);
                            double sc = gain / Math.max(1, cst); if (sc > bestScore) { bestScore = sc; bestI = i; bestCost = cst; } }
                        if (bestI < 0) { note = "All relevant buildings are at maximum level."; break; }
                        setLevel(p, bestI, work[bestI] + 1); work[bestI]++; refresh(c); spent += bestCost; curv = measure(c, key, mode);
                    }
                    total += spent; if (curv < target && note.isEmpty()) note = iterations >= 1500 ? "Search limit reached." : "Target not reachable.";
                    res.append(key).append(US).append(target).append(US).append(first).append(US).append(curv).append(US).append(curv >= target ? "1" : "0").append(US).append(note.isEmpty() ? "Reached. Cost " + spent : note).append(RS);
                }
            } finally { for (int i = 0; i < n; i++) if (start[i] >= 0) { try { setLevel(p, i, start[i]); } catch (Throwable t) { } } refresh(c); }
            lastLevels = work; lastCost = total; hasPlan = true;
            StringBuilder sb = new StringBuilder("OK|" + total + US + ((Number) AocBridge.read(c, "gold")).longValue() + RS + res + "#BUILDINGS" + RS);
            for (int i = 0; i < n; i++) if (start[i] >= 0 && work[i] != start[i]) sb.append(row(i)[0]).append(US).append(start[i]).append(US).append(work[i]).append(RS);
            return sb.toString(); } });
    }

    static String apply(final String mode, final boolean fund) throws Exception {
        if (!hasPlan) return "ERR|NOPLAN|Create a plan first.";
        return AocBridge.onGame(new Callable<String>() { public String call() throws Exception {
            Object c = AocBridge.cs(), p = AocBridge.ps(); long gold = ((Number) AocBridge.read(c, "gold")).longValue();
            if (mode.equals("buy")) { if (gold < lastCost) { if (!fund) return "ERR|FUNDS|Not enough money: need " + AocBridge.fmtNum(lastCost) + ", have " + AocBridge.fmtNum(gold) + ". Tick 'add missing money' or use 'set levels'."; AocBridge.write(c, "gold", lastCost); gold = lastCost; } AocBridge.write(c, "gold", gold - lastCost); }
            int n = 0; for (int i = 0; i < lastLevels.length; i++) if (lastLevels[i] >= 0) { try { if (level(p, i) != lastLevels[i]) { setLevel(p, i, lastLevels[i]); n++; } } catch (Throwable t) { } }
            refresh(c); try { AocBridge.call(AocBridge.gm(), "refreshResourceMultipliersNow"); } catch (Throwable t) { }
            AocBridge.detail("economy plan applied (" + mode + "), " + n + " buildings changed"); hasPlan = false; return "OK|Applied plan: " + n + " buildings changed" + (mode.equals("buy") ? ", " + AocBridge.fmtNum(lastCost) + " spent." : " (free)."); } });
    }
}
