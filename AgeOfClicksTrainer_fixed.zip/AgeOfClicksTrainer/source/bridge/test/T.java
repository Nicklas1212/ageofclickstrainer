import java.io.*; import java.net.*;
public class T { public static void main(String[] a) throws Exception {
  Class.forName("AocBridge").getMethod("start", int.class).invoke(null, 47653);
  Socket s=new Socket("127.0.0.1",47653); BufferedReader r=new BufferedReader(new InputStreamReader(s.getInputStream())); PrintWriter w=new PrintWriter(s.getOutputStream(),true);
  String[] cmds={"ping","status","set country gold 1.5m","add country iron 10k","lock country.gold floor 5m","lock country.warExhaustion exact 0","gainmult resources 5","autoclick on 200 20 2","techs all","upgrades","units heal","gov DEMOCRACY","gov set MONARCHY","debt repay","pop 5000","rel all 100","console help","preset god_mode","maxbuildings","undo","snapshot 1","restore 1","fields country","world","techs list","set player clickPowerLevel 7","setlevel 0 max","recalc","techunlock tech1","focus economy","bogus"};
  for(String c:cmds){ w.println(c); String x=r.readLine(); System.out.println("> "+c+"\n   "+(x==null?null:x.substring(0,Math.min(x.length(),230)).replace('\t','|'))); if(c.startsWith("autoclick")) Thread.sleep(600);}
  Thread.sleep(300); w.println("get country gold"); System.out.println(r.readLine()); w.println("get country iron"); System.out.println(r.readLine()); w.println("diag"); System.out.println(r.readLine()); System.exit(0);} }
