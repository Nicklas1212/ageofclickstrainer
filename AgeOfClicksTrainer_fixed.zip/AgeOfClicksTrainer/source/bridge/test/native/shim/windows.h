// Minimal stand-in so the portable client logic can be compiled and tested on Linux.
#pragma once
#include <ctime>
#include <cstdint>
#define VK_INSERT 0x2D
#define VK_F1 0x70
#define VK_F2 0x71
#define VK_F3 0x72
#define VK_F4 0x73
#define VK_F5 0x74
#define VK_F6 0x75
#define VK_F7 0x76
#define VK_F8 0x77
#define VK_F9 0x78
#define VK_F10 0x79
#define VK_F11 0x7A
#define MB_ICONEXCLAMATION 0x30
inline void MessageBeep(int) {}
inline int localtime_s(tm* r, const time_t* t) { localtime_r(t, r); return 0; }
#define VK_LBUTTON 0x01
#define VK_RBUTTON 0x02
#define VK_MBUTTON 0x04
#define VK_SHIFT 0x10
#define VK_CONTROL 0x11
#define VK_MENU 0x12
#define VK_ESCAPE 0x1B
