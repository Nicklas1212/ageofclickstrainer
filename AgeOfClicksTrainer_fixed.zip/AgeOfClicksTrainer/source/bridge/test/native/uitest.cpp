// Headless UI smoke test: draws every page against the mock bridge with ImGui's assertions enabled.
#include <arpa/inet.h>
#include <sys/socket.h>
#include <unistd.h>
#include <chrono>
#include <thread>
#include <cstdio>
#include <cassert>
#include "imgui.h"
#include "Core/Config.h"
#include "Core/Host.h"
#include "Core/Link.h"
#include "GameState/GameState.h"
#include "Map/MapData.h"
#include "Map/MapView.h"
#include "Notifications/Notifications.h"
#include "UI/App.h"
#include "UI/Common.h"
#include "Palette/Palette.h"
#include "Input/Keys.h"

bool KeyDown(int) { return false; }
std::string KeyName(int vk) { return vk ? "Key" : "(none)"; }
void DrawStates() { ImGui::Text("states (not tested natively)"); }
void DrawSaveEditor() { ImGui::Text("save editor (not tested natively)"); }

struct PosixLink : Link {
    int s = -1; std::string rbuf; int port;
    PosixLink(int p) : port(p) {}
    bool Open() override { s = socket(AF_INET, SOCK_STREAM, 0); sockaddr_in a{}; a.sin_family = AF_INET; a.sin_port = htons(port); inet_pton(AF_INET, "127.0.0.1", &a.sin_addr); if (connect(s, (sockaddr*)&a, sizeof a) != 0) { close(s); s = -1; return false; } rbuf.clear(); return true; }
    bool Exchange(const std::string& cmd, std::string& resp) override { std::string o = cmd + "\n"; if (send(s, o.c_str(), o.size(), 0) <= 0) return false; while (true) { size_t p = rbuf.find('\n'); if (p != std::string::npos) { resp = rbuf.substr(0, p); rbuf.erase(0, p + 1); return true; } static char b[1 << 16]; int n = recv(s, b, sizeof b, 0); if (n <= 0) return false; rbuf.append(b, n); } }
    void Close() override { if (s >= 0) close(s); s = -1; }
};
struct FakeTex : ITextureBackend { int n = 1; ImTextureID Create(int, int, const uint32_t*) override { return (ImTextureID)n++; } void Update(ImTextureID, int, int, const uint32_t*) override {} void Destroy(ImTextureID) override {} };
static double Now() { using namespace std::chrono; return duration<double>(steady_clock::now().time_since_epoch()).count(); }

static int g_frames = 0;
static void Frame(double now, bool overlayStyle, ImVec2 mouse = ImVec2(-1, -1), bool click = false, bool rclick = false) {
    ImGuiIO& io = ImGui::GetIO(); io.DisplaySize = ImVec2(1400, 900); io.DeltaTime = 1.0f / 60;
    if (mouse.x >= 0) { io.AddMousePosEvent(mouse.x, mouse.y); io.AddMouseButtonEvent(0, click); io.AddMouseButtonEvent(1, rclick); }
    App::Tick(now); ImGui::NewFrame();
    if (overlayStyle) App::DrawWindows();
    else { ImGuiViewport* vp = ImGui::GetMainViewport(); ImGui::SetNextWindowPos(vp->WorkPos); ImGui::SetNextWindowSize(vp->WorkSize); ImGui::Begin("main", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove); App::DrawMain(); ImGui::End(); }
    Notify::Draw(now); ImGui::Render(); g_frames++;
}

int main(int argc, char** argv) {
    int port = argc > 1 ? atoi(argv[1]) : 47660; PosixLink L(port); SetLink(&L); host().baseDir = "/tmp/aoc_native/"; static FakeTex tex; host().tex = &tex;
    ImGui::CreateContext(); ImGuiIO& io = ImGui::GetIO(); io.IniFilename = nullptr; unsigned char* px; int w, h; io.Fonts->GetTexDataAsRGBA32(&px, &w, &h); io.Fonts->SetTexID((ImTextureID)1000);
    App::Init(); L.Start(); for (int i = 0; i < 100 && !L.connected; i++) std::this_thread::sleep_for(std::chrono::milliseconds(50));
    for (int overlay = 0; overlay < 2; overlay++) {
        host().overlay = overlay; host().hasFocus = true; App::g_mainOpen = true;
        for (int t = 0; t < T_COUNT; t++) {
            App::GoTo((Tab)t); double e = Now() + 0.6; int n = 0; while (Now() < e || n < 8) { Frame(Now(), overlay); n++; std::this_thread::sleep_for(std::chrono::milliseconds(15)); }
            printf("[%s] page %-18s ok (%d frames)\n", overlay ? "overlay" : "window ", kTabNames[t], n);
        }
    }
    // map interaction: hover, left click, right click, double click, wheel
    host().overlay = false; App::GoTo(T_MAP); for (int i = 0; i < 30; i++) { Frame(Now(), false); std::this_thread::sleep_for(std::chrono::milliseconds(30)); }
    printf("map stage=%d\n", (int)MapData::GetStage());
    for (int step = 0; step < 6; step++) { ImVec2 m(500 + step * 20, 400); Frame(Now(), false, m, false, false); Frame(Now(), false, m, step % 2 == 0, step % 2 == 1); Frame(Now(), false, m, false, false); }
    io.AddMouseWheelEvent(0, 3); Frame(Now(), false, ImVec2(600, 400)); Frame(Now(), false, ImVec2(600, 400));
    for (int i = 0; i < 10; i++) { Frame(Now(), false, ImVec2(600, 400)); }
    printf("focus valid=%d owner=%s cells=%zu\n", (int)MapView::GetFocus().valid, MapView::GetFocus().ownerName.c_str(), MapView::GetFocus().cells);
    for (int mode = 0; mode < MapView::M_COUNT; mode++) { MapView::SetMode(mode); Frame(Now(), false); Frame(Now(), false); }
    // command palette: open, type, run
    { Palette::Open(); for (int i = 0; i < 6; i++) { Frame(Now(), false); std::this_thread::sleep_for(std::chrono::milliseconds(20)); } printf("palette drew ok\n"); assert(Palette::Run("page:Rankings") && App::Current() == T_RANK); assert(Palette::Label("act:undo") == "Undo last change"); int sc = 0; assert(UI::Fuzzy("Open Economy Planner", "ecpl", &sc) && !UI::Fuzzy("Open Map", "zzz")); }
    g_testForcePopups = true; for (int t : {T_DASH, T_ECO, T_RES, T_COUNTRIES}) { App::GoTo((Tab)t); for (int i = 0; i < 12; i++) { Frame(Now(), false); std::this_thread::sleep_for(std::chrono::milliseconds(20)); } printf("popups ok on %s\n", kTabNames[t]); } g_testForcePopups = false;
    printf("all map modes drew without assertion failures\nTOTAL FRAMES %d\n", g_frames);
    L.Stop(); App::Shutdown(); return 0;
}
