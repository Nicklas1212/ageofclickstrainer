#!/bin/bash
# Headless UI smoke test against the mock bridge (start it first: java -cp out2:mockout Serve 47660)
cd "$(dirname "$0")"; SRC=/home/claude/aoc/src; IM=/home/claude/aoc/imgui
FILES=$(cd $SRC && find . -name '*.cpp' ! -path './Main/*' ! -path './Overlay/*' ! -path './Input/*' ! -name 'SocketLink.cpp' ! -name 'Files.cpp' | sed "s|^\./|$SRC/|" | tr '\n' ' ')
g++ -O0 -g -std=c++17 -w -include windows.h -Ishim -I$SRC -I$IM -I$SRC/UI/Diplomacy -I$SRC/UI/Territory uitest.cpp $FILES o/*.o -lpthread -o uitest 2>&1 | grep -E "error|undefined" | head -20
gdb -batch -ex run -ex bt ./uitest 2>&1 | grep -E "^#[0-9]+ .*(uitest|Draw|Tab|Map|App)|page|map |focus|FRAMES|Assertion|all map" | head -60
