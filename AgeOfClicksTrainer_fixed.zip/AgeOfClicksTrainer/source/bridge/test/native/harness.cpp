#include <arpa/inet.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <sys/socket.h>
#include <unistd.h>
#include <chrono>
#include <thread>
#include <cstdio>
#include <map>
#include "Core/Config.h"
#include "Core/Host.h"
#include "Core/Link.h"
#include "GameState/GameState.h"
#include "Game/GameApi.h"
#include "Map/MapData.h"
#include "Presets/Presets.h"

struct PosixLink : Link {
    int s = -1; std::string rbuf; int port;
    PosixLink(int p) : port(p) {}
    bool Open() override { s = socket(AF_INET, SOCK_STREAM, 0); sockaddr_in a{}; a.sin_family = AF_INET; a.sin_port = htons(port); inet_pton(AF_INET, "127.0.0.1", &a.sin_addr); if (connect(s, (sockaddr*)&a, sizeof a) != 0) { close(s); s = -1; return false; } rbuf.clear(); return true; }
    bool Exchange(const std::string& cmd, std::string& resp) override { std::string o = cmd + "\n"; if (send(s, o.c_str(), o.size(), 0) <= 0) return false; while (true) { size_t p = rbuf.find('\n'); if (p != std::string::npos) { resp = rbuf.substr(0, p); rbuf.erase(0, p + 1); return true; } static char b[1 << 16]; int n = recv(s, b, sizeof b, 0); if (n <= 0) return false; rbuf.append(b, n); } }
    void Close() override { if (s >= 0) close(s); s = -1; }
};
static double Now() { using namespace std::chrono; return duration<double>(steady_clock::now().time_since_epoch()).count(); }
static void Pump(double secs) { double e = Now() + secs; while (Now() < e) { state().Update(Now()); std::this_thread::sleep_for(std::chrono::milliseconds(20)); } }
static void Show(const char* label, const std::string& s) { std::string x = s; for (auto& c : x) { if (c == '\x1e') c = '#'; if (c == '\x1f') c = ';'; if (c == '\t') c = '|'; } if (x.size() > 400) x = x.substr(0, 400) + "..."; printf("%s: %s\n", label, x.c_str()); }

int main(int argc, char** argv) {
    int port = argc > 1 ? atoi(argv[1]) : 47660; PosixLink L(port); SetLink(&L); host().baseDir = "/tmp/aoc_native/"; L.notify = [](NoteType t, const std::string& m) { printf("  [notify %d] %s\n", (int)t, m.c_str()); };
    L.Start(); for (int i = 0; i < 100 && !L.connected; i++) std::this_thread::sleep_for(std::chrono::milliseconds(50)); printf("connected=%d\n", (int)L.connected);
    L.Submit("status", "status"); Pump(0.5); printf("ready=%d gold=%s name=%s\n", (int)state().Ready(), L.Get("gold").c_str(), L.Get("getName").c_str());
    state().PollWorld(0); Pump(0.6); printf("countries=%zu\n", state().Countries().size()); for (auto& c : state().Countries()) printf("  %s tag=%s color=%06x pop=%.0f gold=%.0f me=%d stab=%.0f iron=%.0f\n", c.name.c_str(), c.tag.c_str(), c.color, c.pop, c.gold, (int)c.me, c.Stability(), c.stock[1]);
    cfg().mapRes = 100; double start = Now(); while (Now() - start < 6 && MapData::GetStage() != MapData::Stage::Ready && MapData::GetStage() != MapData::Stage::Failed) { double n = Now(); state().Update(n); MapData::Tick(n, true); std::this_thread::sleep_for(std::chrono::milliseconds(30)); }
    printf("map stage=%d msg=%s\n  extractor=%s coverage=%d size=%dx%d src=%dx%d writable=%d grids=%zu\n", (int)MapData::GetStage(), MapData::Message().c_str(), MapData::Extractor().c_str(), MapData::Coverage(), MapData::Width(), MapData::Height(), MapData::SourceWidth(), MapData::SourceHeight(), (int)MapData::Writable(), MapData::Grids().size());
    for (auto& g : MapData::Grids()) printf("  grid %d %s %s %dx%d unique=%d\n", g.idx, g.path.c_str(), g.kind.c_str(), g.w, g.h, g.unique);
    if (MapData::GetStage() == MapData::Stage::Ready) { int w = MapData::Width(), h = MapData::Height(); std::map<int, int> cnt; for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) cnt[MapData::OwnerAt(x, y)]++; for (auto& kv : cnt) printf("  owner %d (%s): %d cells\n", kv.first, kv.first >= 0 ? state().Countries()[kv.first].name.c_str() : "none", kv.second);
        uint32_t k; for (auto& n : MapData::CountryNames()) { MapData::KeyForCountry(n, k); printf("  key %s = %u\n", n.c_str(), k); } }
    Game::Set("country", "gold", "5k"); Pump(0.4); L.Submit("status", "status"); Pump(0.3); printf("gold after set 5k = %s\n", L.Get("gold").c_str());
    Game::Multiply("country", "gold", "3"); Pump(0.4); L.Submit("status", "status"); Pump(0.3); printf("gold after x3 = %s\n", L.Get("gold").c_str());
    Game::Reset("country", "gold"); Pump(0.4); L.Submit("status", "status"); Pump(0.3); printf("gold after reset = %s\n", L.Get("gold").c_str());
    Game::Freeze("country", "gold", true); Pump(0.4); L.Submit("status", "status"); Pump(0.3); printf("locked=%d\n", (int)IsLocked("country.gold"));
    Presets::Load(); auto p = Presets::CaptureCurrent("test"); printf("captured preset commands:\n"); for (auto& c : p.commands) printf("  %s\n", c.c_str());
    L.Submit("history", "history"); Pump(0.4); Show("history", L.Payload("history"));
    L.Submit("resources", "resources"); L.Submit("rates", "rates"); Pump(0.5); Show("resources", L.Payload("resources")); Show("rates", L.Payload("rates"));
    L.Submit("plan iron=100 steel=50", "plan"); Pump(0.8); printf("plan err=[%s]\n", L.TagError("plan").c_str()); Show("plan", L.Payload("plan"));
    L.Submit("cinfo Third_Land", "cinfo_c"); Pump(0.4); Show("cinfo", L.Payload("cinfo_c"));
    L.Submit("dipl Testland Other", "dipl"); Pump(0.4); Show("dipl", L.Payload("dipl"));
    L.Submit("vx", "vx:"); Pump(0.4); Show("vx root", L.Payload("vx:"));
    L.Stop(); return 0;
}
