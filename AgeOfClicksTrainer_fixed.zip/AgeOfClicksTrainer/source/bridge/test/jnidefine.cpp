// Verifies the embedded bridge classes (dll/bridge_classes.h) can be defined in the system class loader through JNI and started.
#include <jni.h>
#include <cstdio>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <string>
#include <cstring>
#include "../../dll/bridge_classes.h"
int main() {
    JavaVM* vm; JNIEnv* env; JavaVMInitArgs a{}; JavaVMOption o[1]; o[0].optionString = (char*)"-Djava.class.path=/home/claude/aoc/bridge/mockout"; a.version = JNI_VERSION_1_8; a.nOptions = 1; a.options = o;
    if (JNI_CreateJavaVM(&vm, (void**)&env, &a) != JNI_OK) { puts("no jvm"); return 1; }
    jclass clC = env->FindClass("java/lang/ClassLoader"); jmethodID sys = env->GetStaticMethodID(clC, "getSystemClassLoader", "()Ljava/lang/ClassLoader;"); jobject loader = env->CallStaticObjectMethod(clC, sys);
    jmethodID loadClass = env->GetMethodID(clC, "loadClass", "(Ljava/lang/String;)Ljava/lang/Class;");
    for (int i = 0; i < kClassCount; i++) { jclass c = env->DefineClass(kClasses[i].name, loader, (const jbyte*)kClasses[i].data, (jsize)kClasses[i].size); if (env->ExceptionCheck() || !c) { env->ExceptionDescribe(); printf("DefineClass failed: %s\n", kClasses[i].name); return 1; } }
    printf("defined %d classes\n", kClassCount);
    jobject bc = env->CallObjectMethod(loader, loadClass, env->NewStringUTF("AocBridge")); if (env->ExceptionCheck()) { env->ExceptionDescribe(); return 1; }
    jmethodID start = env->GetStaticMethodID((jclass)bc, "start", "(I)V"); env->CallStaticVoidMethod((jclass)bc, start, 47661); if (env->ExceptionCheck()) { env->ExceptionDescribe(); return 1; }
    sleep(1); int s = socket(AF_INET, SOCK_STREAM, 0); sockaddr_in ad{}; ad.sin_family = AF_INET; ad.sin_port = htons(47661); inet_pton(AF_INET, "127.0.0.1", &ad.sin_addr); if (connect(s, (sockaddr*)&ad, sizeof ad)) { puts("connect failed"); return 1; }
    for (const char* cmd : {"version\n", "wstats\n", "mapprobe\n"}) { send(s, cmd, strlen(cmd), 0); char b[600]; int n = recv(s, b, sizeof b - 1, 0); b[n > 0 ? n : 0] = 0; for (char* p = b; *p; p++) if (*p == 30) *p = '#'; else if (*p == 31) *p = ';'; printf("%s -> %.200s\n", cmd, b); }
    return 0;
}
