package ru.ius.david.cgs.game; public enum GovernmentForm { DEMOCRACY, MONARCHY, COMMUNISM }
