package ru.ius.david.cgs.game; public class CommandExecutor { public String execute(String s){ return "echo:"+s; } }
