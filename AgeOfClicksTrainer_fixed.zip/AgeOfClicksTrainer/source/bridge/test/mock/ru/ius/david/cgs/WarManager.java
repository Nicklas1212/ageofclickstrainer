package ru.ius.david.cgs; public class WarManager { public java.util.List<Object> units = new java.util.ArrayList<>(); public NativeIntGrid owner = new NativeIntGrid(400,200); public NativeByteGrid terrain = null; public MapGen gen = new MapGen();
 public WarManager(){ for(int y=0;y<200;y++) for(int x=0;x<400;x++) owner.set(x,y, x<150?0xFF0000: x<300 ? (y<100?0x00FF00:0x0000FF) : 0); } }
class NativeByteGrid {}
class MapGen { public long seed = 12345L; public NativeIntGrid world = new NativeIntGrid(400,200); MapGen(){ for(int y=0;y<200;y++) for(int x=0;x<400;x++) world.set(x,y, x<150?0xFF0000: x<300 ? (y<100?0x00FF00:0x0000FF) : 0); } }
