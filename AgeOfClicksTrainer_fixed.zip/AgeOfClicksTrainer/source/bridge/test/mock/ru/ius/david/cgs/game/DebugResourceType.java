package ru.ius.david.cgs.game; public enum DebugResourceType { GOLD("gold"), IRON("iron"), MECH_PARTS("mechParts"); public final String key; DebugResourceType(String k){key=k;} }
