package ru.ius.david.cgs.game; import java.util.*;
public class Technology { public String id, branch; public int epoch; public float baseScienceCost; public static final List<Technology> ALL_TECHNOLOGIES=new ArrayList<>();
 static { for(int i=0;i<4;i++){ Technology t=new Technology(); t.id="tech"+i; t.branch=i%2==0?"economy":"military"; t.baseScienceCost=10*(i+1); ALL_TECHNOLOGIES.add(t);} }
 public static boolean isResearchable(Technology t, CountryState c, int d){ return !c.researchedTechs.contains(t.id);} }
