package com.badlogic.gdx; public class Gdx { public static Application app = new Application(){ public void postRunnable(Runnable r){ r.run(); } }; }
