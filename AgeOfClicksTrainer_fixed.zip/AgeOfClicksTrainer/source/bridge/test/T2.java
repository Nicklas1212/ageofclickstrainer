import java.io.*; import java.net.*;
public class T2 { public static void main(String[] a) throws Exception {
  Class.forName("AocBridge").getMethod("start", int.class).invoke(null, 47655);
  Socket s=new Socket("127.0.0.1",47655); BufferedReader r=new BufferedReader(new InputStreamReader(s.getInputStream())); PrintWriter w=new PrintWriter(s.getOutputStream(),true);
  String[] cmds={"version","wstats","cinfo Third_Land","set c:Third_Land gold 777","get c:Third_Land gold","mul country gold 3","reset country gold","resources","rset iron add 50","rates","dipl Testland Other","relpair Testland Other 55","dipl Testland Other",
    "vx","vx country","vx countries","vx countries/{Third%20Land}","vxset countries/{Third%20Land}/gold 123","vxreset countries/{Third%20Land}/gold","vxfind gold",
    "mapprobe","mapkeys","mapdiag","mapdata 100","cellinfo 10 10","mapset 50 50 255","cellinfo 50 50","plan iron=100 gold=9","planapply buy 1","get player ironMineLevel","history","undo","redo","classdump ru.ius.david.cgs.WarManager"};
  for(String c:cmds){ w.println(c); String x=r.readLine(); System.out.println("> "+c+"\n   "+(x==null?null:x.substring(0,Math.min(x.length(),260)).replace('\t','|').replace((char)30,'#').replace((char)31,';'))); }
  System.exit(0);} }
