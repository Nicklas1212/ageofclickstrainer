public class Serve { public static void main(String[] a) throws Exception { Class.forName("AocBridge").getMethod("start", int.class).invoke(null, Integer.parseInt(a[0])); Thread.sleep(600000); } }
