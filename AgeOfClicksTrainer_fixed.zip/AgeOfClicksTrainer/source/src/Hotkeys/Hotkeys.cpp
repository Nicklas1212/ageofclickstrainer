#include "Hotkeys/Hotkeys.h"
#include <windows.h>
#include "Core/Config.h"
#include "Core/Host.h"
#include "Game/GameApi.h"
#include "GameState/GameState.h"
#include "Input/Keys.h"
#include "UI/App.h"

static int g_capture = -1;
void Hotkeys::BeginCapture(int a) { g_capture = a; }
int Hotkeys::Capturing() { return g_capture; }
void Hotkeys::UpdateCapture() {
    if (g_capture < 0) return;
    for (int vk = 8; vk < 255; vk++) { if (vk == VK_LBUTTON || vk == VK_RBUTTON || vk == VK_MBUTTON || vk == VK_SHIFT || vk == VK_CONTROL || vk == VK_MENU) continue; if (KeyDown(vk)) { cfg().vk[g_capture] = vk == VK_ESCAPE ? 0 : vk; g_capture = -1; SaveConfig(); return; } }
}
void Hotkeys::Poll() {
    static bool down[A_COUNT] = {}; if (g_capture >= 0 || !host().hotkeysActive) return;
    for (int i = 0; i < A_COUNT; i++) {
        int vk = cfg().vk[i]; if (!vk || i == A_OVERLAY) { continue; }
        bool d = KeyDown(vk); bool edge = d && !down[i]; down[i] = d; if (!edge) continue;
        bool tabKey = i >= A_TAB_DASH && i <= A_TAB_MILITARY;
        if (tabKey) { if (host().hasFocus) { static const Tab m[] = {T_DASH, T_MAP, T_COUNTRIES, T_ECO, T_MIL}; App::GoTo(m[i - A_TAB_DASH]); } continue; }
        if (!state().Ready()) continue;
        switch (i) {
            case A_AUTOCLICK: Cmd(Fmt("autoclick %s %g %g %g", IsFlag("autoclick") ? "off" : "on", cfg().cps, cfg().jitter, cfg().clickMul)); break;
            case A_PAUSE: Cmd(Fmt("pause %s", link().Get("paused") == "true" ? "off" : "on")); break;
            case A_MONEY: Cmd("add country gold " + cfg().hotkeyMoney); break;
            case A_QSAVE: Cmd("snapshot 1"); break; case A_QLOAD: Cmd("restore 1"); break;
            case A_UNDO: Cmd("undo"); break; case A_REDO: Cmd("redo"); break;
            case A_SPEEDUP: Cmd(Fmt("speed %d", (int)link().Num("speed") + 1)); break;
            case A_SPEEDDOWN: Cmd(Fmt("speed %d", std::max(1, (int)link().Num("speed") - 1))); break;
            case A_INFMONEY: Cmd(IsLocked("country.gold") ? "lock country.gold off" : "lock country.gold floor 9t"); break;
            case A_COMPACT: if (host().toggleCompact) host().toggleCompact(); break;
        }
    }
}
