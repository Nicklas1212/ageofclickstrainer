// Configurable global hotkeys. Poll() runs every frame (also while the overlay is hidden).
#pragma once
namespace Hotkeys {
void Poll();                      // fire actions on key-down edges
void BeginCapture(int action);    // next key press is assigned to the action (Esc clears)
int Capturing();                  // action being captured or -1
void UpdateCapture();
}
