#include <algorithm>
#include <map>
#include "UI/Common.h"
#include "UI/Tabs.h"
#include "UI/App.h"

#include "DiplLegacy.inc"

namespace {
bool Picker(const char* id, const char* label, std::string& value) {
    bool changed = false; auto& cs = state().Countries(); ImGui::SetNextItemWidth(ImGui::GetFontSize() * 14);
    if (ImGui::BeginCombo(id, value.empty() ? label : value.c_str())) {
        static std::string flt; if (ImGui::IsWindowAppearing()) { ImGui::SetKeyboardFocusHere(); flt.clear(); } UI::Search("##pf", flt, "search...", -1);
        for (auto& c : cs) { if (!flt.empty() && !ContainsNoCase(c.name, flt) && !ContainsNoCase(c.tag, flt)) continue; if (ImGui::Selectable(c.name.c_str(), c.name == value)) { value = c.name; changed = true; } }
        ImGui::EndCombo(); }
    return changed;
}
std::map<std::string, std::string> Parse(const std::string& raw) { std::map<std::string, std::string> m; for (auto& kv : Split(raw, '\t')) { size_t e = kv.find('='); if (e != std::string::npos) m[kv.substr(0, e)] = kv.substr(e + 1); } return m; }
std::string Nz(const std::string& s) { return (s.empty() || s == "null") ? "-" : s; }
}

void DrawDiplomacy() {
    state().PollWorld(2.0); static std::string A, B, lastPair;
    const CountryRow* me = nullptr; for (auto& c : state().Countries()) if (c.me) me = &c;
    if (A.empty() && me) A = me->name; if (B.empty()) B = state().selectedB.empty() ? state().selected : state().selectedB; if (!state().selectedB.empty() && state().selectedB != B) B = state().selectedB;
    state().selectedB = B;
    if (Card("dp0", "Relations between two countries", "Pick Country A and Country B. Relations run from -100 (hostile) to +100 (friendly).")) {
        ImGui::TextDisabled("Country A"); ImGui::SameLine(); Picker("##A", "choose...", A); ImGui::SameLine(0, 24); ImGui::TextDisabled("Country B"); ImGui::SameLine(); Picker("##B", "choose...", B);
        ImGui::SameLine(); if (ImGui::Button("Swap")) std::swap(A, B); ImGui::SameLine(); if (me && ImGui::Button("A = me")) A = me->name;
        if (A.empty() || B.empty() || A == B) Desc(A == B && !A.empty() ? "Choose two different countries." : "Choose both countries.");
        else {
            std::string pair = A + "|" + B; if (pair != lastPair) { lastPair = pair; link().ClearTag("dipl"); }
            Poll("dipl " + EncodeName(A) + " " + EncodeName(B), "dipl", 1.0); auto m = Parse(link().Payload("dipl")); std::string err = link().TagError("dipl"); if (!err.empty()) Desc(err.c_str());
            if (!m.empty() && ImGui::BeginTable("dtab", 3, ImGuiTableFlags_RowBg | ImGuiTableFlags_SizingStretchProp)) {
                ImGui::TableSetupColumn(""); ImGui::TableSetupColumn(A.c_str()); ImGui::TableSetupColumn(B.c_str()); ImGui::TableHeadersRow();
                auto row = [&](const char* l, const std::string& a, const std::string& b) { ImGui::TableNextRow(); ImGui::TableNextColumn(); ImGui::TextUnformatted(l); ImGui::TableNextColumn(); ImGui::TextUnformatted(a.c_str()); ImGui::TableNextColumn(); ImGui::TextUnformatted(b.c_str()); };
                row("Relation toward the other", Nz(m["relAB"]), Nz(m["relBA"])); row("Influence over the other", Nz(m["influenceAB"]), Nz(m["influenceBA"])); row("Non-aggression pact", Nz(m["pactAB"]), Nz(m["pactBA"]));
                row("Is an ally", Nz(m["alliedA"]), Nz(m["alliedB"])); row("Alliance", Nz(m["allianceA"]), Nz(m["allianceB"])); row("Ally of", Nz(m["allyOfA"]), Nz(m["allyOfB"])); row("Is a puppet", Nz(m["puppetA"]), Nz(m["puppetB"])); row("Puppet master", Nz(m["masterA"]), Nz(m["masterB"])); row("Liberty desire", Nz(m["libertyA"]), Nz(m["libertyB"]));
                ImGui::EndTable(); }
            static int rel = 100; ImGui::SetNextItemWidth(ImGui::GetFontSize() * 18); ImGui::SliderInt("Relation (both directions)", &rel, -100, 100);
            ImGui::SameLine(); if (ImGui::Button("Apply relation")) Cmd(Fmt("relpair %s %s %d", EncodeName(A).c_str(), EncodeName(B).c_str(), rel)); UI::Tip("Sets how A feels about B and how B feels about A.");
            if (ImGui::Button("Friendly (+100)")) { rel = 100; Cmd(Fmt("relpair %s %s 100", EncodeName(A).c_str(), EncodeName(B).c_str())); } ImGui::SameLine(); if (ImGui::Button("Neutral (0)")) { rel = 0; Cmd(Fmt("relpair %s %s 0", EncodeName(A).c_str(), EncodeName(B).c_str())); }
            ImGui::SameLine(); if (ImGui::Button("Hostile (-100)")) { rel = -100; Cmd(Fmt("relpair %s %s -100", EncodeName(A).c_str(), EncodeName(B).c_str())); }
            ImGui::Separator(); bool aMe = me && A == me->name; ImGui::BeginDisabled(!aMe);
            static int inf = 100; ImGui::SetNextItemWidth(ImGui::GetFontSize() * 18); ImGui::SliderInt("Your influence over B", &inf, 0, 1000); ImGui::SameLine(); if (ImGui::Button("Apply influence")) Cmd(Fmt("influence %s %d", B.c_str(), inf));
            if (ImGui::Button("Make B a puppet")) Cmd("puppet on " + B); ImGui::SameLine(); if (ImGui::Button("Free B")) Cmd("puppet off " + B); ImGui::SameLine(); if (ImGui::Button("Annex B")) Cmd("console annex " + B); ImGui::SameLine(); if (ImGui::Button("Declare war on B")) Cmd("console declareWar " + B);
            ImGui::EndDisabled(); if (!aMe) Desc("Influence, puppet, annex and war actions act from your own country. Set Country A to your country to use them.");
            Desc("Alliances and peace treaties are not exposed as a reliable single call in this game version, so they are not offered here. Raise relations to +100 and use the in-game diplomacy screen.");
        }
        EndCard();
    }
    if (ImGui::CollapsingHeader("All countries at once")) GlobalDiplomacy();
}
