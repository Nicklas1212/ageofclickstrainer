#include "Map/MapData.h"
#include "Map/MapView.h"
#include "UI/Common.h"
#include "UI/Tabs.h"

void DrawMapTab() {
    MapView::DrawToolbar();
    float panelW = ImGui::GetFontSize() * 17; ImVec2 av = ImGui::GetContentRegionAvail();
    MapView::DrawCanvas(ImVec2(std::max(200.0f, av.x - panelW - 8), av.y)); ImGui::SameLine();
    ImGui::BeginChild("mapside", ImVec2(0, 0), ImGuiChildFlags_Borders);
    MapView::DrawSidePanel();
    if (ImGui::CollapsingHeader("Map setup & diagnostics")) MapView::DrawSetup();
    ImGui::EndChild();
}
