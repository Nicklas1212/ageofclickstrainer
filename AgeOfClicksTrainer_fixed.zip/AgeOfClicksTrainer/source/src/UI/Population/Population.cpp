#include <algorithm>
#include <cmath>
#include <cstring>
#include <vector>
#include "UI/Common.h"
#include "UI/Tabs.h"
#include "UI/App.h"

void DrawPopulation() {
    if (Card("p1", "Population", "Citizens are the base of your economy: workers produce, soldiers fight.")) {
        ImGui::Text("Total population: %s     Workers: %s     Military: %s     Conscripted: %s", Val("getTotalPopulation").c_str(), Val("getWorkersCount").c_str(), Val("getMilitaryCount").c_str(), Val("getConscriptedCount").c_str());
        static char pop[64] = ""; ImGui::SetNextItemWidth(160); ImGui::InputText("Target population", pop, 64); ImGui::SameLine();
        if (ImGui::Button("Set population")) Cmd(Fmt("pop %s", pop)); if (ImGui::IsItemHovered()) ImGui::SetTooltip("Adjusts the game's 'population bonus' so your total population equals the number you typed.");
        EditRow({"Population bonus", "populationBonus", "country", "Flat citizens added on top of the natural population."});
        EditRow({"Growth modifier", "growthModifier", "country", "Population growth multiplier/offset used by the game. Raise for faster growth (Freeze to hold it)."});
        EditRow({"Conscription (workforce split)", "targetConscription", "country", "Percent of people drafted. Lower it for more available workers, raise it for more soldiers - this is the game's 'workforce / available workers' control."}, false);
        EditRow({"Social security (happiness)", "targetSocialSecurity", "country", "Social spending slider. Raising it is the strongest direct way to raise happiness / stability."}, false);
    } EndCard();
    if (Card("p2", "Happiness, unrest & stability", "Happiness itself is calculated by the game from many factors (so it can't be typed directly). These switches attack the inputs.")) {
        ImGui::Text("Happiness now: %s%%", Val("getHappinessPercent").c_str());
        EditRow({"War exhaustion", "warExhaustion", "country", "Fatigue from war - drags happiness down. Set to 0 and freeze to ignore it."});
        EditRow({"Revolution risk", "revolutionRisk", "country", "Risk of a revolution/coup. Freeze at 0 = stability."});
        EditRow({"Strike risk", "strikeRisk", "country", "Chance of workers striking. Freeze at 0."});
        EditRow({"Liberty desire", "libertyDesire", "country", "Desire for independence (relevant for puppets). Freeze at 0."});
        FlagToggle("Suppress unrest (no rebellions)", "norebellion", "Every 40 ms: rebellion stage, revolution risk and strike risk are set to 0 - 'suppress unrest instantly' and 'freeze unrest'.");
        FlagToggle("No epidemics", "noepidemic", "Clears any epidemic and its severity continuously.");
        Button("Max social security", "Sets the social security slider to 100.", "set country targetSocialSecurity 100");
    } EndCard();
    if (Card("p3", "Not available in this game", nullptr)) {
        NotMapped("Set migration", "Age of Clicks has no migration mechanic; use population bonus / growth instead.");
        NotMapped("Freeze population", "just use Freeze on 'Population bonus' + 'Growth modifier'.");
        NotMapped("Set stability", "stability is expressed through happiness, revolution risk and strike risk above.");
    } EndCard();
}
