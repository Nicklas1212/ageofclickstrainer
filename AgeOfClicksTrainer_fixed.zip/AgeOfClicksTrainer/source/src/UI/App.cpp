#include "UI/App.h"
#include <algorithm>
#include <set>
#include <vector>
#include "Core/Host.h"
#include "Core/Link.h"
#include "GameState/GameState.h"
#include "Hotkeys/Hotkeys.h"
#include "Map/MapData.h"
#include "Map/MapView.h"
#include "Notifications/Notifications.h"
#include "Palette/Palette.h"
#include "Presets/Presets.h"
#include "UI/Common.h"
#include "UI/Tabs.h"

namespace App {
bool g_mainOpen = true;
namespace {
Tab g_tab = T_DASH; std::string g_navSearch; bool g_focusSearch = false; std::set<int> g_pop; double g_nextStatus = 0, g_nextSave = 0;
struct Group { const char* name; std::vector<Tab> tabs; };
const std::vector<Group>& Groups() {
    static const std::vector<Group> g = {{"Overview", {T_DASH, T_MAP, T_COUNTRIES, T_RANK, T_COMPARE, T_EVENTS}}, {"Your country", {T_ECO, T_POP, T_MIL, T_RSCH, T_RES, T_IND}}, {"World", {T_DIPL, T_TERR, T_POL, T_WORLD}},
        {"Tools", {T_PLAN, T_TIME, T_AUTO, T_PRESETS, T_HIST, T_VARS}}, {"System", {T_STATE, T_SAVE, T_CON, T_DIAG, T_HELP, T_SET}}};
    return g;
}
bool NeedsGame(Tab t) { return !(t == T_DASH || t == T_SET || t == T_STATE || t == T_SAVE || t == T_CON || t == T_DIAG || t == T_HELP); }
const char* kBlurb[T_COUNT] = {"Your country at a glance, with live graphs and rankings.", "The world map. Click a country to inspect it; right-click a territory for actions.", "Every country, sortable. Select one to inspect and edit it.", "A log of what changed in the game while you played.",
    "Money, income, taxes and the economy.", "Citizens, happiness and stability.", "Army, manpower and equipment.", "Technologies and science points.", "Stockpiles, income and multipliers for every resource.", "Buildings and upgrade levels.",
    "Relations and agreements between two countries.", "Territory ownership, population and resources.", "Government form and political support.", "World-wide controls: time, war, AI and sandbox.",
    "Tell it the economy you want; it works out the upgrades to buy.", "Auto-clicker and game speed.", "Hands-off helpers and resource alerts.", "Save and load groups of changes.", "Every change you made, with undo and redo.", "Browse and edit any value the game exposes.",
    "Back up and restore the running game.", "Edit save files on disk.", "Send commands straight to the bridge.", "Appearance, hotkeys, notifications and map options.",
    "Countries ranked by any statistic.", "Put two to four countries side by side.", "What works in this session, how fast it runs, and what is connected.", "Guides, shortcuts, troubleshooting and the changelog."};
bool Visible(Tab t) { return cfg().tabOn[t] || t == T_DASH || t == T_SET; }
void DrawTab(Tab t) {
    if (NeedsGame(t) && UI::NeedGame()) return;
    switch (t) {
        case T_DASH: DrawDashboard(); break; case T_MAP: DrawMapTab(); break; case T_COUNTRIES: DrawCountries(); break; case T_EVENTS: DrawEvents(); break;
        case T_ECO: DrawEconomy(); break; case T_POP: DrawPopulation(); break; case T_MIL: DrawMilitary(); break; case T_RSCH: DrawResearch(); break; case T_RES: DrawResources(); break; case T_IND: DrawIndustry(); break;
        case T_DIPL: DrawDiplomacy(); break; case T_TERR: DrawTerritory(); break; case T_POL: DrawPolitics(); break; case T_WORLD: DrawWorld(); break;
        case T_PLAN: DrawPlanner(); break; case T_TIME: DrawTime(); break; case T_AUTO: DrawAutomation(); break; case T_PRESETS: DrawPresets(); break; case T_HIST: DrawHistory(); break; case T_VARS: DrawVariables(); break;
        case T_RANK: DrawRankings(); break; case T_COMPARE: DrawCompare(); break; case T_DIAG: DrawDiagnostics(); break; case T_HELP: DrawHelp(); break;
        case T_STATE: DrawStates(); break; case T_SAVE: DrawSaveEditor(); break; case T_CON: DrawConsole(); break; default: DrawSettings(); break;
    }
}
}

void Init() {
    UI::ApplyTheme(); Presets::Load();
    link().notify = [](NoteType t, const std::string& m) { Notify::Push(t, m); };
}
void Shutdown() { SaveConfig(); MapView::Release(); }
void GoTo(Tab t) { g_tab = t; }
Tab Current() { return g_tab; }
void PopOut(Tab t) { g_pop.insert(t); }

void Tick(double now) {
    state().Update(now);
    if (now > g_nextStatus && link().connected) { g_nextStatus = now + 0.25; link().Submit("status", "status"); }
    if (now > g_nextSave) { g_nextSave = now + 15; SaveConfig(); }
    Hotkeys::UpdateCapture(); Hotkeys::Poll();
    if (g_tab == T_MAP || g_pop.count(T_MAP)) MapView::Tick(now);
}

void DrawHud() {
    GameState& s = state(); Link& L = link();
    ImGuiViewport* vp = ImGui::GetMainViewport(); ImGui::SetNextWindowPos(ImVec2(vp->Pos.x + vp->Size.x * 0.5f, vp->Pos.y + 8), ImGuiCond_FirstUseEver, ImVec2(0.5f, 0));
    ImGui::SetNextWindowBgAlpha(cfg().opacity);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(12, 6));
    if (ImGui::Begin("Quick values##hud", nullptr, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoScrollbar)) {
        if (!s.Ready()) { ImGui::TextColored(kWarn, "%s", L.StateMessage().c_str()); }
        else {
            ImGui::TextColored(kAccent, "%s", L.Get("getName").c_str()); ImGui::SameLine(); ImGui::TextDisabled("%s", L.Get("date").c_str());
            struct V { const char* label; const char* field; ImVec4 c; } vals[] = {{"Money", "gold", kGood}, {"Population", "getTotalPopulation", kGood}, {"Science", "sciencePoints", kGood}, {"Manpower", "manpower", kGood}, {"Steel", "steel", kGood}, {"Fuel", "fuel", kGood}, {"Ammo", "ammo", kGood}};
            for (auto& v : vals) { ImGui::SameLine(0, 18); ImGui::TextDisabled("%s", v.label); ImGui::SameLine(0, 5); ClickValue(v.field, "country", v.field, Val(v.field), v.label, v.c); }
            double r = s.Rate("gold", 5); ImGui::SameLine(0, 18); ImGui::TextDisabled("Income"); ImGui::SameLine(0, 5); ImGui::TextColored(r >= 0 ? kGood : kBad, "%s%s/s", r >= 0 ? "+" : "", Human(r).c_str());
            if (IsFlag("autoclick")) { ImGui::SameLine(0, 18); ImGui::TextColored(kGood, "Auto-click"); } if (L.Get("paused") == "true") { ImGui::SameLine(0, 18); ImGui::TextColored(kWarn, "PAUSED"); }
        }
        ImGui::SameLine(0, 18); if (ImGui::SmallButton(g_mainOpen ? "Hide tools" : "Show tools")) g_mainOpen = !g_mainOpen;
        ImGui::TextDisabled("Click any value to edit it.");
    }
    ImGui::End(); ImGui::PopStyleVar();
}

namespace {
bool NavItem(const char* label, bool active, const char* tip) {
    float h = ImGui::GetTextLineHeight() + 9; ImVec2 p = ImGui::GetCursorScreenPos(); float w = ImGui::GetContentRegionAvail().x;
    ImGui::PushStyleColor(ImGuiCol_Header, ImGui::GetStyleColorVec4(ImGuiCol_FrameBg)); ImGui::PushStyleColor(ImGuiCol_Text, active ? kAccent : ImGui::GetStyleColorVec4(ImGuiCol_Text));
    bool hit = ImGui::Selectable((std::string("   ") + label).c_str(), active, 0, ImVec2(0, h)); ImGui::PopStyleColor(2);
    if (active) ImGui::GetWindowDrawList()->AddRectFilled(ImVec2(p.x, p.y + 3), ImVec2(p.x + 3, p.y + h - 3), ImGui::GetColorU32(kAccent), 2);
    if (tip && ImGui::IsItemHovered(ImGuiHoveredFlags_DelayNormal)) ImGui::SetTooltip("%s", tip); (void)w; return hit;
}
void DrawHeader(bool ok) {
    GameState& s = state(); Link& L = link(); (void)s;
    UI::PushFont(UI::fontHead); ImGui::TextUnformatted("Age of Clicks"); UI::PopFont(); ImGui::SameLine(0, 10); ImGui::AlignTextToFramePadding(); ImGui::TextDisabled("Control Center"); ImGui::SameLine(0, 18);
    UI::Pill(L.multiplayer ? "Multiplayer - changes blocked" : ok ? "Single-player connected" : L.StateMessage().c_str(), L.multiplayer ? kBad : ok ? kGood : kWarn);
    float bw = ImGui::GetFontSize() * 9; float right = ImGui::GetWindowWidth() - ImGui::GetStyle().WindowPadding.x;
    float need = bw + 2 * (ImGui::GetFontSize() * 3.6f) + (host().toggleCompact ? ImGui::GetFontSize() * 5.5f : 0) + (host().overlay ? ImGui::GetFontSize() * 5 : 0) + (host().requestClose ? ImGui::GetFontSize() * 4.5f : 0) + 40;
    ImGui::SameLine(std::max(ImGui::GetCursorPosX() + 20, right - need));
    if (ImGui::Button("Search   Ctrl+K", ImVec2(bw, 0))) Palette::Open(); UI::Tip("Find any page, country, preset or action.");
    ImGui::SameLine(); ImGui::BeginDisabled(!ok); if (ImGui::Button("Undo")) Cmd("undo"); UI::Tip("Undo the last change (Ctrl+Z)."); ImGui::SameLine(); if (ImGui::Button("Redo")) Cmd("redo"); UI::Tip("Redo (Ctrl+Y)."); ImGui::EndDisabled();
    if (host().toggleCompact) { ImGui::SameLine(); if (ImGui::Button("Compact")) host().toggleCompact(); UI::Tip("Small always-on-top stats window."); }
    if (host().overlay) { ImGui::SameLine(); if (ImGui::Button("Pop out")) PopOut(g_tab); UI::Tip("Open the current page in its own movable window."); }
    if (host().requestClose) { ImGui::SameLine(); if (ImGui::Button("Close")) host().requestClose(); UI::Tip("Hide the overlay (Insert)."); }
}
void DrawQuickBar() {
    if (!cfg().quickBar || cfg().quick.empty()) return;
    for (size_t i = 0; i < cfg().quick.size(); i++) {
        const std::string& id = cfg().quick[i]; bool page = id.rfind("page:", 0) == 0, here = page && Palette::Label(id) == kTabNames[g_tab], ok = Palette::Available(id);
        if (i) ImGui::SameLine(0, 4); ImGui::PushID((int)i); ImGui::BeginDisabled(!ok);
        if (here) { ImGui::PushStyleColor(ImGuiCol_Button, ImGui::GetStyleColorVec4(ImGuiCol_FrameBg)); ImGui::PushStyleColor(ImGuiCol_Text, kAccent); }
        if (ImGui::SmallButton(Palette::Label(id).c_str())) Palette::Run(id); if (here) ImGui::PopStyleColor(2); ImGui::EndDisabled(); ImGui::PopID();
    }
}
void DrawStatusBar(bool ok) {
    if (!cfg().statusBar) return; ImGuiIO& io = ImGui::GetIO(); Link& L = link();
    ImGui::Separator(); ImGui::PushStyleColor(ImGuiCol_Text, kDim); UI::PushFont(UI::fontMono);
    ImGui::Text("%s", ok ? (L.Get("getName") + "  " + L.Get("date")).c_str() : "no game"); ImGui::SameLine(0, 22);
    ImGui::Text("%s", L.connected ? "bridge: connected" : "bridge: waiting"); ImGui::SameLine(0, 22); ImGui::Text("%.0f fps  %.1f ms", io.Framerate, io.Framerate > 0 ? 1000.0f / io.Framerate : 0.0f);
    if (!state().selected.empty()) { ImGui::SameLine(0, 22); ImGui::Text("selected: %s", state().selected.c_str()); }
    UI::PopFont(); ImGui::PopStyleColor();
}
}

void DrawMain() {
    GameState& s = state(); Link& L = link(); ImGuiIO& io = ImGui::GetIO();
    bool ok = s.Ready();
    DrawHeader(ok); DrawQuickBar(); ImGui::Spacing();
    if (L.multiplayer) { ImGui::PushStyleColor(ImGuiCol_Text, kBad); ImGui::TextWrapped("MULTIPLAYER DETECTED - every change is blocked. This tool is for single-player only."); ImGui::PopStyleColor(); }
    if (io.KeyCtrl && ImGui::IsKeyPressed(ImGuiKey_K, false)) Palette::Open();
    if (!io.WantTextInput) {
        if (io.KeyCtrl && ImGui::IsKeyPressed(ImGuiKey_Z, false)) Cmd("undo"); if (io.KeyCtrl && ImGui::IsKeyPressed(ImGuiKey_Y, false)) Cmd("redo");
        if (io.KeyCtrl && (ImGui::IsKeyPressed(ImGuiKey_PageDown, false) || ImGui::IsKeyPressed(ImGuiKey_PageUp, false))) { int d = ImGui::IsKeyPressed(ImGuiKey_PageDown, false) ? 1 : -1; int t = g_tab; for (int i = 0; i < T_COUNT; i++) { t = (t + d + T_COUNT) % T_COUNT; if (Visible((Tab)t)) break; } g_tab = (Tab)t; }
    }
    if (io.KeyCtrl && ImGui::IsKeyPressed(ImGuiKey_F, false)) g_focusSearch = true;
    float statusH = cfg().statusBar ? ImGui::GetTextLineHeightWithSpacing() + 10 : 0, navW = ImGui::GetFontSize() * 12.5f;
    ImGui::BeginChild("nav", ImVec2(navW, -statusH), ImGuiChildFlags_Borders);
    if (g_focusSearch) { ImGui::SetKeyboardFocusHere(); g_focusSearch = false; }
    UI::Search("##navsearch", g_navSearch, "filter pages (Ctrl+F)", -1);
    if (ImGui::BeginChild("navlist", ImVec2(0, 0), ImGuiChildFlags_None)) {
        if (!g_navSearch.empty()) { for (int i = 0; i < T_COUNT; i++) { if (!Visible((Tab)i)) continue; if (!(ContainsNoCase(kTabNames[i], g_navSearch) || ContainsNoCase(kTabKeywords[i], g_navSearch))) continue; if (NavItem(kTabNames[i], g_tab == i, kBlurb[i])) g_tab = (Tab)i; } }
        else {
            for (auto& g : Groups()) { bool any = false; for (Tab t : g.tabs) if (Visible(t)) any = true; if (!any) continue;
                ImGui::Spacing(); ImGui::PushStyleColor(ImGuiCol_Text, kDim); ImGui::TextUnformatted(g.name); ImGui::PopStyleColor();
                for (Tab t : g.tabs) { if (!Visible(t)) continue; if (NavItem(kTabNames[t], g_tab == t, kBlurb[t])) g_tab = t; } }
            if (!cfg().favorites.empty() && ok) { ImGui::Spacing(); ImGui::PushStyleColor(ImGuiCol_Text, kDim); ImGui::TextUnformatted("Pinned countries"); ImGui::PopStyleColor();
                for (auto& f : cfg().favorites) { const CountryRow* c = s.Find(f); if (!c) continue; if (NavItem(f.c_str(), g_tab == T_COUNTRIES && s.selected == f, "Click to inspect")) Palette::Run("country:" + f); } }
        }
    }
    ImGui::EndChild(); ImGui::EndChild(); ImGui::SameLine();
    ImGui::BeginChild("content", ImVec2(0, -statusH), ImGuiChildFlags_None);
    UI::PushFont(UI::fontHead); ImGui::TextUnformatted(kTabNames[g_tab]); UI::PopFont(); ImGui::SameLine(0, 14); ImGui::AlignTextToFramePadding(); ImGui::TextDisabled("%s", kBlurb[g_tab]); ImGui::Spacing();
    ImGui::BeginChild("page", ImVec2(0, 0), ImGuiChildFlags_None);
    DrawTab(g_tab);
    ImGui::EndChild(); ImGui::EndChild();
    DrawStatusBar(ok);
    Palette::Draw();
}

void DrawWindows() {
    DrawHud();
    if (g_mainOpen) {
        ImGuiViewport* vp = ImGui::GetMainViewport(); ImGui::SetNextWindowPos(ImVec2(vp->Pos.x + vp->Size.x * 0.5f, vp->Pos.y + vp->Size.y * 0.5f), ImGuiCond_FirstUseEver, ImVec2(0.5f, 0.5f));
        ImGui::SetNextWindowSize(ImVec2(std::min(1150.0f, vp->Size.x * 0.8f), std::min(760.0f, vp->Size.y * 0.8f)), ImGuiCond_FirstUseEver); ImGui::SetNextWindowBgAlpha(cfg().opacity);
        if (ImGui::Begin("Age of Clicks Tools", &g_mainOpen, ImGuiWindowFlags_NoCollapse)) DrawMain(); ImGui::End();
    }
    for (auto it = g_pop.begin(); it != g_pop.end();) {
        bool open = true; ImGui::SetNextWindowSize(ImVec2(620, 480), ImGuiCond_FirstUseEver); ImGui::SetNextWindowBgAlpha(cfg().opacity);
        if (ImGui::Begin((std::string(kTabNames[*it]) + "##pop" + std::to_string(*it)).c_str(), &open)) DrawTab((Tab)*it); ImGui::End();
        if (!open) it = g_pop.erase(it); else ++it;
    }
}
}
