#include <algorithm>
#include "UI/Common.h"
#include "UI/Tabs.h"
#include "UI/App.h"

static void ConnectionCard() {
    if (!Card("conn", "Connection", host().overlay ? "This overlay runs inside the game, so it is already attached. Everything stays on your PC." : "The trainer attaches to the running game by loading a small helper DLL into it (the game is a Java program; the helper talks to its objects). Everything stays on your PC (127.0.0.1).")) { EndCard(); return; }
    Link& L = link();
    ImGui::TextColored(L.connected ? kGood : kBad, "\xE2\x97\x8F"); ImGui::SameLine(); ImGui::TextWrapped("%s", L.StateMessage().c_str());
    if (host().inject) {
        if (!host().injectStatus.empty()) Desc(host().injectStatus.c_str());
        if (ImGui::Button("Inject / Connect", ImVec2(160, 0))) host().inject(); UI::Tip("Finds 'Age of Clicks.exe', loads AgeOfClicksTrainerCore.dll into it and connects. Safe to press again.");
        ImGui::SameLine(); ImGui::Checkbox("Auto-inject when the game is detected", &cfg().autoInject);
    }
    EndCard();
}

static void TopCountries() {
    auto cs = state().Countries(); if (cs.empty()) { state().PollWorld(2.0); Desc("Loading the world table..."); return; }
    struct Col { const char* name; double CountryRow::* f; } cols[] = {{"Population", &CountryRow::pop}, {"Money", &CountryRow::gold}, {"Military", &CountryRow::strength}};
    if (ImGui::BeginTable("top", 3, ImGuiTableFlags_SizingStretchSame | ImGuiTableFlags_RowBg)) {
        for (auto& c : cols) ImGui::TableSetupColumn(c.name); ImGui::TableHeadersRow(); ImGui::TableNextRow();
        for (auto& c : cols) { ImGui::TableNextColumn(); std::vector<const CountryRow*> v; for (auto& r : cs) v.push_back(&r); std::sort(v.begin(), v.end(), [&](auto a, auto b) { return a->*(c.f) > b->*(c.f); });
            for (int i = 0; i < 6 && i < (int)v.size(); i++) { ImGui::PushID(v[i]->name.c_str()); if (ImGui::Selectable(Fmt("%d. %s", i + 1, v[i]->name.c_str()).c_str(), v[i]->me)) { state().Select(v[i]->name); App::GoTo(T_COUNTRIES); } ImGui::SameLine(ImGui::GetContentRegionAvail().x - 60); ImGui::TextDisabled("%s", Human(v[i]->*(c.f)).c_str()); ImGui::PopID(); }
            int rank = 0; for (size_t i = 0; i < v.size(); i++) if (v[i]->me) rank = (int)i + 1; if (rank > 6) ImGui::TextColored(kGood, "You: #%d", rank); }
        ImGui::EndTable(); }
}

void DrawDashboard() {
    ConnectionCard();
    if (UI::NeedGame()) return;
    Link& L = link(); GameState& S = state();
    if (Card("country", "Your country", "Click any highlighted value to edit it.")) {
        ImGui::Text("%s  [%s]   Date: %s   Speed: %s   %s", L.Get("getName").c_str(), L.Get("getTag").c_str(), L.Get("date").c_str(), L.Get("speed").c_str(), L.Get("paused") == "true" ? "(PAUSED)" : "");
        struct V { const char* label; const char* field; } v[] = {{"Money", "gold"}, {"Population", "getTotalPopulation"}, {"Science points", "sciencePoints"}, {"Territory", "territorySize"}, {"Manpower", "manpower"}};
        for (int i = 0; i < 5; i++) { if (i) ImGui::SameLine(0, 20); ImGui::TextDisabled("%s", v[i].label); ImGui::SameLine(0, 5); ClickValue(v[i].field, "country", v[i].field, Val(v[i].field), v[i].label); }
        ImGui::Text("Happiness %s%%   Workers %s   Army %s   Strength %s", Val("getHappinessPercent").c_str(), Val("getWorkersCount").c_str(), Val("getMilitaryCount").c_str(), Val("calculateTotalStrength").c_str());
        ImGui::Text("Government %s   Science +%s/day   Research queue %s   Techs known %s", L.Get("govForm").c_str(), Val("getDailyScienceRate").c_str(), L.Get("queued").c_str(), L.Get("researched").c_str());
        if (L.Get("sandbox") == "true") ImGui::TextColored(kWarn, "Sandbox mode is ON");
        EndCard();
    }
    if (Card("graphs", "Live graphs", "The last two minutes, sampled once per second.")) {
        struct G { const char* title; const char* key; } g[] = {{"Money", "gold"}, {"Net income per second", "getDynamicGoldIncomePerSec"}, {"Population", "getTotalPopulation"}, {"Happiness %", "getHappinessPercent"}, {"Science points", "sciencePoints"}, {"Military strength", "calculateTotalStrength"}};
        float w = (ImGui::GetContentRegionAvail().x - 16) / 2;
        for (int i = 0; i < 6; i++) { if (i % 2) ImGui::SameLine(); ImGui::BeginGroup(); ImGui::TextDisabled("%s   now %s", g[i].title, Val(g[i].key).c_str()); ImGui::PushID(i); UI::LineGraph("##g", S.Spark(g[i].key), ImVec2(w, 78)); ImGui::PopID(); ImGui::EndGroup(); }
        EndCard();
    }
    if (Card("rank", "World ranking", "Top countries. Click a name to inspect it.")) { TopCountries(); EndCard(); }
    if (Card("mon", "Resource monitor", "Live amounts with income/expense rates. 'per sec' is real time over the last few seconds; 'per game day' follows the in-game calendar.")) {
        static bool nz = false; ImGui::Checkbox("Hide zero resources", &nz);
        if (ImGui::BeginTable("rm", 5, ImGuiTableFlags_RowBg | ImGuiTableFlags_SizingStretchProp)) {
            ImGui::TableSetupColumn("Resource", 0, 2.2f); ImGui::TableSetupColumn("Amount", 0, 1.4f); ImGui::TableSetupColumn("per sec", 0, 1.2f); ImGui::TableSetupColumn("per game day", 0, 1.3f); ImGui::TableSetupColumn("trend", 0, 2.f); ImGui::TableHeadersRow();
            for (int i = 0; i < kResCount; i++) { double v = L.Num(kResKeys[i]); if (nz && v == 0) continue; ImGui::TableNextRow(); ImGui::PushID(i);
                ImGui::TableNextColumn(); ImGui::TextUnformatted(kResNames[i]); ImGui::TableNextColumn(); ClickValue("amt", "country", kResKeys[i], Human(v), kResNames[i]);
                double r = S.Rate(kResKeys[i], 5), rd = S.Rate(kResKeys[i], 8, "days"); ImGui::TableNextColumn(); ImGui::TextColored(r > 0 ? kGood : r < 0 ? kBad : kDim, "%s%s", r > 0 ? "+" : "", Human(r).c_str());
                ImGui::TableNextColumn(); ImGui::TextColored(rd > 0 ? kGood : rd < 0 ? kBad : kDim, "%s%s", rd > 0 ? "+" : "", Human(rd).c_str());
                ImGui::TableNextColumn(); auto& sp = S.Spark(kResKeys[i]); if (sp.size() > 2) ImGui::PlotLines("##s", sp.data(), (int)sp.size(), 0, nullptr, FLT_MAX, FLT_MAX, ImVec2(-1, 22)); ImGui::PopID(); }
            ImGui::EndTable(); }
        EndCard();
    }
}
