#include <algorithm>
#include <cmath>
#include <cstring>
#include <vector>
#include "UI/Common.h"
#include "UI/Tabs.h"
#include "UI/App.h"

void DrawTime() {
    if (Card("c1", "Auto-clicker", "Presses the game's real 'click' for you (earns click gold exactly like clicking). CPS = clicks per second; randomization varies the rate +/- the given % every 40 ms so it isn't perfectly regular; the multiplier presses several clicks per click.")) {
        bool on = IsFlag("autoclick"); static float cps = (float)cfg().cps, jit = (float)cfg().jitter, mul = (float)cfg().clickMul;
        ImGui::SetNextItemWidth(300); bool c1 = ImGui::SliderFloat("Clicks per second", &cps, 1, 500, "%.0f", ImGuiSliderFlags_Logarithmic);
        ImGui::SetNextItemWidth(300); bool c2 = ImGui::SliderFloat("Randomization (+/- %)", &jit, 0, 90, "%.0f%%");
        ImGui::SetNextItemWidth(300); bool c3 = ImGui::SliderFloat("Click multiplier (clicks per click)", &mul, 1, 1000, "x%.0f", ImGuiSliderFlags_Logarithmic);
        cfg().cps = cps; cfg().jitter = jit; cfg().clickMul = mul;
        if (ImGui::Checkbox("Auto-clicker ON", &on) || ((c1 || c2 || c3) && on)) Cmd(Fmt("autoclick %s %g %g %g", on ? "on" : "off", cps, jit, mul));
        ImGui::SameLine(); Desc(Fmt("Effective rate ~ %.0f clicks/s", on ? cps * mul : 0.0).c_str());
        Desc("Instant clicks: use the buttons below to fire a burst at once.");
        for (int n : {10, 100, 1000, 10000}) { ImGui::SameLine(0, 6); std::string l = Fmt("Click x%d", n); if (ImGui::Button(l.c_str())) Cmd(Fmt("click %d", n)); }
        FlagToggle("No cooldowns (instant clicks of the game's boosters)", "nocooldown", "Clears the cooldown timers of the game's economy/diplomacy/military auto-clicker boosters continuously.");
    } EndCard();
    if (Card("c2", "Game speed", "The game's own speed levels (same as its speed buttons) plus a 'days per tick' multiplier that makes the calendar run faster than the top level.")) {
        ImGui::Text("Current level: %s    Effective speed: %s    Days per tick: %s", link().Get("speed").c_str(), link().Get("effspeed").c_str(), link().Get("dpt").c_str());
        for (int s : {1, 2, 3, 4, 5, 6}) { if (s > 1) ImGui::SameLine(0, 6); std::string l = Fmt("Level %d", s); if (ImGui::Button(l.c_str())) Cmd(Fmt("speed %d", s)); }
        Desc("Levels map to the game's speed buttons (roughly x1, x2, x5, x10...). Use 'Days per tick' below for x25/x50 effects.");
        static int dpt = 1; ImGui::SetNextItemWidth(260); ImGui::SliderInt("Days per tick", &dpt, 1, 50); ImGui::SameLine(); if (ImGui::Button("Apply##dpt")) Cmd(Fmt("dpt %d", dpt)); ImGui::SameLine(); if (ImGui::Button("Reset to 1")) { dpt = 1; Cmd("dpt 1"); }
        ImGui::Separator();
        bool paused = link().Get("paused") == "true"; if (ImGui::Button(paused ? "Resume game" : "Pause game")) Cmd(Fmt("pause %s", paused ? "off" : "on")); ImGui::SameLine();
        FlagToggle("Freeze time (keep paused)", "pauselock", nullptr);
        Desc("Freeze time keeps the game paused even if something tries to resume it (the game's own pause toggle).");
    } EndCard();
    if (Card("c3", "Skip time", "Advances the game clock by running the game's own 'simulate' console command for a number of seconds of simulation.", "experimental")) {
        for (auto p : std::vector<std::pair<const char*, int>>{{"Skip 1 day", 1}, {"Skip 1 month", 30}, {"Skip 1 year", 365}}) { if (ImGui::Button(p.first)) Cmd(Fmt("console simulate %d", p.second)); ImGui::SameLine(); }
        ImGui::NewLine(); Desc("If the number of seconds does not match one day in your version, check 'help' in the Console tab for the exact meaning of simulate.");
    } EndCard();
}

void DrawAutomation() {
    Poll("upgrades", "upgrades", 0.7); std::string raw = link().Payload("upgrades");
    if (Card("a1", "AFK mode", "One switch for hands-off play: auto-clicker + auto-upgrade + auto-research + no cooldowns. Everything stays inside the normal rules of the game (it just presses what you would press).")) {
        bool afk = IsFlag("autoclick") && IsFlag("autobuy") && IsFlag("autoresearch");
        if (ImGui::Checkbox("AFK mode", &afk)) { Cmd(afk ? "preset afk" : "flag autoclick off"); if (!afk) { SetFlag("autobuy", false); SetFlag("autoresearch", false); SetFlag("nocooldown", false); } }
        ImGui::SameLine(); Desc("Use the sliders on 'Time & Clicker' for the CPS.");
    } EndCard();
    if (Card("a2", "Upgrade assistant / production automation", "Every second, buys the cheapest affordable upgrade from the groups you tick. On the Industry tab affordable upgrades are highlighted green.")) {
        static bool g[6] = {true, true, true, true, true, true}; static const char* gn[] = {"eco", "raw", "prod", "mil", "sci", "dip"}; static const char* gl[] = {"Economy", "Raw materials", "Production", "Military", "Science", "Diplomacy"};
        for (int i = 0; i < 6; i++) { if (i) ImGui::SameLine(); ImGui::Checkbox(gl[i], &g[i]); }
        std::string cats; for (int i = 0; i < 6; i++) if (g[i]) cats += std::string(cats.empty() ? "" : ",") + gn[i];
        if (ImGui::Button("Apply groups")) Cmd("opt autobuy " + cats);
        FlagToggle("Auto-upgrade", "autobuy", "Buys upgrades automatically from the selected groups when you can afford them (cheapest first).");
        int aff = 0; for (auto& r : Split(raw, '\x1e')) { auto c = Split(r, '\x1f'); if (c.size() >= 7 && c[6] == "1") aff++; } ImGui::Text("Affordable right now: %d upgrades", aff);
    } EndCard();
    if (Card("a3", "Research queue helper", "Keeps your research queue filled with the cheapest researchable technology.")) {
        static int br = 0; static const char* bn[] = {"all", "economy", "military", "politics"}; ImGui::SetNextItemWidth(160); if (ImGui::Combo("Branch", &br, "All\0Economy\0Military\0Politics\0")) Cmd(Fmt("opt autoresearch %s", bn[br]));
        FlagToggle("Auto-research", "autoresearch", "When the queue has fewer than 3 items, adds the cheapest researchable tech of the chosen branch.");
    } EndCard();
    if (Card("a4", "Auto-collect", nullptr)) {
        Desc("Collecting income in this game is done by clicking (and the game's boosters). Auto-collect = the Auto-clicker ('Time & Clicker') plus 'No cooldowns'.");
        FlagToggle("No cooldowns", "nocooldown", nullptr);
    } EndCard();
    if (Card("a5", "Resource alerts", "Get a toast + sound when a resource reaches a threshold.")) {
        if (ImGui::Button("Add alert")) cfg().alerts.push_back(Alert());
        ImGui::Checkbox("Play sound", &cfg().beep);
        for (size_t i = 0; i < cfg().alerts.size(); i++) { auto& a = cfg().alerts[i]; ImGui::PushID((int)i); ImGui::Checkbox("##on", &a.on); ImGui::SameLine(); ImGui::SetNextItemWidth(180);
            if (ImGui::BeginCombo("##res", kResNames[a.res])) { for (int k = 0; k < kResCount; k++) if (ImGui::Selectable(kResNames[k], k == a.res)) a.res = k; ImGui::EndCombo(); }
            ImGui::SameLine(); ImGui::SetNextItemWidth(110); int dir = a.above ? 1 : 0; if (ImGui::Combo("##dir", &dir, "falls below\0rises above\0")) a.above = dir == 1;
            ImGui::SameLine(); ImGui::SetNextItemWidth(130); float t = (float)a.thr; if (ImGui::InputFloat("##thr", &t, 0, 0, "%.0f")) a.thr = t;
            ImGui::SameLine(); if (ImGui::SmallButton("Remove")) { cfg().alerts.erase(cfg().alerts.begin() + i); ImGui::PopID(); break; } ImGui::PopID(); }
    } EndCard();
}
