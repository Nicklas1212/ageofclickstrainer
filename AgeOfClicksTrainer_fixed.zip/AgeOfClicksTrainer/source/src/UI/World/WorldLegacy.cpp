#include <algorithm>
#include <cmath>
#include <cstring>
#include <vector>
#include "UI/Common.h"
#include "UI/Tabs.h"
#include "UI/App.h"

void DrawWarRules() {
    if (Card("w1", "War state", "Fatigue and devastation from war.")) {
        EditRow({"War exhaustion", "warExhaustion", "country", "Fatigue from war. 0 = fresh. Freeze at 0 to ignore it."});
        EditRow({"Nuclear devastation", "nuclearDevastation", "country", "Fallout damage. 0 = none."});
        Button("Clear exhaustion & devastation", "Sets both to 0.", "war exhaustion0");
    } EndCard();
    if (Card("w2", "Rules", nullptr)) {
        Button("Disable capitulation (you never surrender)", "Prevents countries - including you - from capitulating.", "war nocapitulation"); ImGui::SameLine(); Button("Enable capitulation", "Back to normal.", "war capitulation");
        Button("Disable AI (freeze all computer countries)", "Computer-controlled countries stop acting.", "war noai"); ImGui::SameLine(); Button("Enable AI", "Back to normal.", "war ai");
        Desc("Force peace / end war / war score / peace conference values: no stable single call exists in this version. Use relations (+100) and the game's own peace screen, or check 'help' in the Console tab.");
    } EndCard();
}
