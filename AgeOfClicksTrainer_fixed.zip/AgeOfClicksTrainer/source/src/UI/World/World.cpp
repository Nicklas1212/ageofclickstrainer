#include <algorithm>
#include "UI/Common.h"
#include "UI/Tabs.h"

void DrawWarRules();

void DrawWorld() {
    state().PollWorld(3.0); auto& cs = state().Countries();
    if (Card("wo0", "World overview", "Totals across all countries in the current game.")) {
        double pop = 0, gold = 0, hap = 0, str = 0, terr = 0; for (auto& c : cs) { pop += c.pop; gold += c.gold; hap += c.happiness; str += c.strength; terr += c.territory; }
        if (cs.empty()) Desc("Loading the world table..."); else {
            ImGui::Text("Countries: %zu     Date: %s     Speed level: %s     %s", cs.size(), link().Get("date").c_str(), link().Get("speed").c_str(), link().Get("paused") == "true" ? "(PAUSED)" : "");
            ImGui::Text("World population %s    Total money %s    Total military %s    Average happiness %s    Mapped territory %s", Human(pop).c_str(), Human(gold).c_str(), Human(str).c_str(), Human(hap / cs.size()).c_str(), Human(terr).c_str()); }
        bool paused = link().Get("paused") == "true"; if (ImGui::Button(paused ? "Resume game" : "Pause game")) Cmd(Fmt("pause %s", paused ? "off" : "on")); ImGui::SameLine();
        for (int s : {1, 2, 3, 4, 5}) { if (ImGui::Button(Fmt("Speed %d", s).c_str())) Cmd(Fmt("speed %d", s)); ImGui::SameLine(); } ImGui::NewLine();
        EndCard();
    }
    if (Card("wo1", "Sandbox", "The game ships its own map and country editors in sandbox mode. Turning sandbox on unlocks them.")) {
        Button("Enable sandbox mode", "Calls the game's own sandbox switch.", "sandbox on"); ImGui::SameLine(); Button("Disable sandbox mode", "Back to normal rules.", "sandbox off");
        ImGui::TextColored(link().Get("sandbox") == "true" ? kGood : kDim, "Sandbox is %s", link().Get("sandbox") == "true" ? "ON" : "off"); EndCard();
    }
    DrawWarRules();
    if (Card("wo2", "Not available in this game", nullptr)) {
        NotMapped("Reveal the whole map", "this version has no fog of war.");
        NotMapped("Force peace / end all wars", "no stable single call exists; use relations and the game's own peace screen.");
        NotMapped("Weather, seasons, disasters", "the game has none of these systems.");
        EndCard();
    }
}
