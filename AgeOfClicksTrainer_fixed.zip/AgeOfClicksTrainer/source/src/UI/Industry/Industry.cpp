#include <algorithm>
#include <cmath>
#include <cstring>
#include <vector>
#include "UI/Common.h"
#include "UI/Tabs.h"
#include "UI/App.h"

void DrawIndustry() {
    Poll("upgrades", "upgrades", 0.7); std::string raw = link().Payload("upgrades");
    if (Card("i1", "Buildings & upgrades", "Every building the game has, with its level and the cost of the next level. Buy one level, set a level directly, or max everything.")) {
        Button("Max ALL building levels", "Sets every building to the game's maximum level and refreshes incomes. Use Undo to revert.", "maxbuildings"); ImGui::SameLine();
        static char lv[16] = "10"; ImGui::SetNextItemWidth(70); ImGui::InputText("##lv", lv, 16); ImGui::SameLine(); if (ImGui::Button("Set ALL to level")) Cmd(Fmt("maxbuildings %s", lv));
        FlagToggle("Instant construction", "instantconstruction", "Advances your construction queue by a huge step every 40 ms so projects finish immediately.", "experimental");
        if (ImGui::BeginTable("up", 7, ImGuiTableFlags_RowBg | ImGuiTableFlags_ScrollY | ImGuiTableFlags_SizingStretchProp, ImVec2(0, 420))) {
            ImGui::TableSetupColumn("Building", 0, 2.5f); ImGui::TableSetupColumn("Group", 0, 0.8f); ImGui::TableSetupColumn("Level", 0, 0.8f); ImGui::TableSetupColumn("Next cost", 0, 1.2f); ImGui::TableSetupColumn("", 0, 0.9f); ImGui::TableSetupColumn("Set level", 0, 1.6f); ImGui::TableSetupColumn("", 0, 0.8f); ImGui::TableHeadersRow();
            for (auto& row : Split(raw, '\x1e')) { auto c = Split(row, '\x1f'); if (c.size() < 7) continue; bool aff = c[6] == "1"; ImGui::TableNextRow(); ImGui::PushID(c[5].c_str());
                ImGui::TableNextColumn(); ImGui::TextColored(aff ? kGood : ImGui::GetStyle().Colors[ImGuiCol_Text], "%s", c[0].c_str()); ImGui::TableNextColumn(); ImGui::TextDisabled("%s", c[4].c_str());
                ImGui::TableNextColumn(); ImGui::Text("%s/%s", c[1].c_str(), c[3].c_str()); ImGui::TableNextColumn(); ImGui::TextColored(aff ? kGood : kDim, "%s", Human(atof(c[2].c_str())).c_str());
                ImGui::TableNextColumn(); if (ImGui::SmallButton("Buy +1")) Cmd("upgrade " + c[5]);
                ImGui::TableNextColumn(); static std::map<std::string, std::string> lb; auto& b = lb[c[5]]; b.resize(8); ImGui::SetNextItemWidth(60); ImGui::InputText("##l", b.data(), 8); ImGui::SameLine();
                if (ImGui::SmallButton("Set")) Cmd(Fmt("setlevel %s %s", c[5].c_str(), b.c_str()));
                ImGui::TableNextColumn(); if (ImGui::SmallButton("Max")) Cmd(Fmt("setlevel %s max", c[5].c_str())); ImGui::PopID(); }
            ImGui::EndTable(); }
        Desc("Green = you can afford the next level right now ('upgrade assistant' highlight).");
    } EndCard();
    if (Card("i2", "Production", nullptr)) {
        Button("Max production (all buildings)", "Same as 'Max ALL building levels': production scales with building level.", "maxbuildings"); ImGui::SameLine();
        Button("Unlock everything (all technologies)", "Unlocks every technology so every production line / building tier is available.", "techs all");
        FlagToggle("Auto-upgrade production buildings", "autobuy", "Production automation: buys the cheapest affordable upgrade every second. Choose groups on the Automation tab.");
    } EndCard();
    if (Card("i3", "Not available in this game", nullptr)) {
        NotMapped("Civilian vs military factories / allocation", "this game uses per-resource buildings (Steel Mill, Munitions Factory, Tank Factory...) instead - use the table above.");
        NotMapped("Set construction speed / remove construction costs", "use 'Instant construction' and 'Infinite budget' (Economy tab).");
        NotMapped("Production efficiency / freeze production", "use Max building levels and resource Freeze.");
    } EndCard();
}
