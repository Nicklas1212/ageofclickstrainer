#include <algorithm>
#include <cmath>
#include <map>
#include "UI/Common.h"
#include "UI/Tabs.h"

namespace {
struct Res { const char* key; const char* name; };
std::vector<Res> PlanResources() { std::vector<Res> v; for (int i = 0; i < kResCount; i++) if (std::string(kResKeys[i]) != "manpower") v.push_back({kResKeys[i], kResNames[i]}); return v; }
struct Target { std::string key, note; double want = 0, first = 0, got = 0; bool reached = false; };
struct Building { std::string label; int from = 0, to = 0; };
struct Plan { bool valid = false; double cost = 0, gold = 0; std::vector<Target> targets; std::vector<Building> buildings; std::string error; };
Plan g_plan; uint64_t g_seen = 0; bool g_waiting = false; std::map<std::string, std::string> g_stockWant;

void Parse(const std::string& raw) {
    Plan p; auto parts = Split(raw, '\x1e'); if (parts.empty()) return; auto h = Split(parts[0], '\x1f'); if (h.size() >= 2) { p.cost = atof(h[0].c_str()); p.gold = atof(h[1].c_str()); }
    bool b = false; for (size_t i = 1; i < parts.size(); i++) { if (parts[i] == "#BUILDINGS") { b = true; continue; } auto c = Split(parts[i], '\x1f');
        if (!b && c.size() >= 6) { Target t; t.key = c[0]; t.want = atof(c[1].c_str()); t.first = atof(c[2].c_str()); t.got = atof(c[3].c_str()); t.reached = c[4] == "1"; t.note = c[5]; p.targets.push_back(t); }
        else if (b && c.size() >= 3) p.buildings.push_back({c[0], atoi(c[1].c_str()), atoi(c[2].c_str())}); }
    p.valid = true; g_plan = p;
}
const char* NameOf(const std::string& key) { for (int i = 0; i < kResCount; i++) if (key == kResKeys[i]) return kResNames[i]; return key.c_str(); }
}

void DrawPlanner() {
    Poll("rates", "rates", 3.0); auto res = PlanResources();
    std::map<std::string, double> gross; for (auto& r : Split(link().Payload("rates"), '\x1e')) { auto c = Split(r, '\x1f'); if (c.size() >= 3 && !c[1].empty() && c[1] != "null") gross[c[0]] = atof(c[1].c_str()); }
    if (Card("pl0", "Economy Planner", "Type how much of each resource you want to PRODUCE per day. The planner reads the game's own building costs and measures what each upgrade really adds to your economy, then picks the cheapest set of upgrades that reaches your targets. Nothing changes until you press Apply.", "experimental")) {
        if (ImGui::BeginTable("plan_in", 5, ImGuiTableFlags_RowBg | ImGuiTableFlags_ScrollY | ImGuiTableFlags_SizingStretchProp, ImVec2(0, 330))) {
            ImGui::TableSetupColumn("Resource", 0, 2); ImGui::TableSetupColumn("In stock now"); ImGui::TableSetupColumn("Production now (per day)"); ImGui::TableSetupColumn("Wanted production per day", 0, 1.6f); ImGui::TableSetupColumn("Wanted stock now (optional)", 0, 1.6f); ImGui::TableSetupScrollFreeze(0, 1); ImGui::TableHeadersRow();
            for (auto& r : res) { ImGui::TableNextRow(); ImGui::PushID(r.key); ImGui::TableNextColumn(); ImGui::TextUnformatted(r.name); ImGui::TableNextColumn(); ImGui::TextUnformatted(Val(r.key).c_str());
                ImGui::TableNextColumn(); if (gross.count(r.key)) ImGui::Text("%s", Human(gross[r.key]).c_str()); else ImGui::TextDisabled("n/a");
                ImGui::TableNextColumn(); ImGui::SetNextItemWidth(-1); ImGui::InputTextWithHint("##w", "e.g. 50k", Buf(std::string("pw_") + r.key), 64);
                ImGui::TableNextColumn(); ImGui::SetNextItemWidth(-1); ImGui::InputTextWithHint("##s", "e.g. 1m", Buf(std::string("ps_") + r.key), 64); ImGui::PopID(); }
            ImGui::EndTable(); }
        std::string args; int n = 0; for (auto& r : res) { std::string w = BufStr(std::string("pw_") + r.key); if (!w.empty()) { args += " " + std::string(r.key) + "=" + w; n++; } }
        ImGui::BeginDisabled(n == 0 || g_waiting);
        if (ImGui::Button(g_waiting ? "Calculating..." : "Calculate plan", ImVec2(180, 0))) { g_plan = Plan(); link().ClearTag("plan"); g_seen = 0; g_waiting = true; link().Submit("plan" + args, "plan"); }
        ImGui::EndDisabled(); ImGui::SameLine(); if (ImGui::Button("Clear inputs")) { for (auto& r : res) { Buf(std::string("pw_") + r.key)[0] = 0; Buf(std::string("ps_") + r.key)[0] = 0; } g_plan = Plan(); }
        ImGui::SameLine(); ImGui::TextDisabled("%d resource target(s)", n);
        uint64_t s = link().Serial("plan"); if (s != g_seen) { g_seen = s; g_waiting = false; std::string e = link().TagError("plan"); if (!e.empty()) { g_plan = Plan(); g_plan.error = e; } else Parse(link().Payload("plan")); }
        EndCard();
    }
    if (!g_plan.error.empty()) { ImGui::PushStyleColor(ImGuiCol_Text, kBad); ImGui::TextWrapped("%s", g_plan.error.c_str()); ImGui::PopStyleColor(); }
    if (g_plan.valid && Card("pl1", "Result", nullptr)) {
        bool all = true; for (auto& t : g_plan.targets) all = all && t.reached;
        ImGui::TextColored(all ? kGood : kWarn, "%s", all ? "Every target can be reached." : "Some targets cannot be reached fully (see notes).");
        ImGui::Text("Total upgrade cost: %s     Your money: %s", Human(g_plan.cost).c_str(), Human(g_plan.gold).c_str());
        if (ImGui::BeginTable("plan_out", 5, ImGuiTableFlags_RowBg | ImGuiTableFlags_SizingStretchProp)) {
            ImGui::TableSetupColumn("Resource", 0, 1.5f); ImGui::TableSetupColumn("Wanted"); ImGui::TableSetupColumn("Now"); ImGui::TableSetupColumn("After plan"); ImGui::TableSetupColumn("Note", 0, 3); ImGui::TableHeadersRow();
            for (auto& t : g_plan.targets) { ImGui::TableNextRow(); ImGui::TableNextColumn(); ImGui::TextUnformatted(NameOf(t.key)); ImGui::TableNextColumn(); ImGui::TextUnformatted(Human(t.want).c_str()); ImGui::TableNextColumn(); ImGui::TextUnformatted(Human(t.first).c_str());
                ImGui::TableNextColumn(); ImGui::TextColored(t.reached ? kGood : kWarn, "%s", Human(t.got).c_str()); ImGui::TableNextColumn(); ImGui::TextWrapped("%s", t.note.c_str()); }
            ImGui::EndTable(); }
        ImGui::Spacing(); UI::Heading("Upgrades that would change");
        if (g_plan.buildings.empty()) Desc("No building changes are needed.");
        else if (ImGui::BeginTable("plan_b", 3, ImGuiTableFlags_RowBg | ImGuiTableFlags_SizingStretchProp)) { ImGui::TableSetupColumn("Building", 0, 3); ImGui::TableSetupColumn("Level now"); ImGui::TableSetupColumn("Planned level"); ImGui::TableHeadersRow();
            for (auto& b : g_plan.buildings) { ImGui::TableNextRow(); ImGui::TableNextColumn(); ImGui::TextUnformatted(b.label.c_str()); ImGui::TableNextColumn(); ImGui::Text("%d", b.from); ImGui::TableNextColumn(); ImGui::TextColored(kGood, "%d", b.to); } ImGui::EndTable(); }
        ImGui::Spacing(); static int mode = 0; static bool fund = false;
        ImGui::RadioButton("Buy upgrades (spends your money)", &mode, 0); UI::Tip("Pays the planned cost from your treasury and raises the levels, like buying them one by one."); ImGui::SameLine(); ImGui::RadioButton("Set levels directly (free)", &mode, 1); UI::Tip("Sets the building levels without paying.");
        if (mode == 0) { ImGui::Checkbox("Add the missing money automatically", &fund); UI::Tip("If you cannot afford the plan, your treasury is raised to the exact cost first."); }
        bool affordable = g_plan.gold >= g_plan.cost; ImGui::BeginDisabled(mode == 0 && !affordable && !fund);
        if (ImGui::Button("Apply plan", ImVec2(180, 0))) {
            Cmd(mode == 0 ? Fmt("planapply buy %d", fund ? 1 : 0) : std::string("planapply set"));
            for (auto& r : res) { std::string sv = BufStr(std::string("ps_") + r.key); if (!sv.empty()) Cmd("rset " + std::string(r.key) + " set " + sv); }
            g_plan = Plan(); }
        ImGui::EndDisabled(); if (mode == 0 && !affordable && !fund) ImGui::TextColored(kWarn, "Not enough money for this plan. Tick 'Add the missing money' or use 'Set levels directly'.");
        Desc("Production figures come from the game's own resource ledger, so the unit is whatever the ledger reports per day. If a resource does not react to buildings, the planner says so instead of guessing.");
        EndCard();
    } else if (!g_plan.valid) {
        bool anyStock = false; for (auto& r : res) if (!BufStr(std::string("ps_") + r.key).empty()) anyStock = true;
        if (anyStock && ImGui::Button("Set the wanted stock amounts now")) for (auto& r : res) { std::string sv = BufStr(std::string("ps_") + r.key); if (!sv.empty()) Cmd("rset " + std::string(r.key) + " set " + sv); }
    }
}
