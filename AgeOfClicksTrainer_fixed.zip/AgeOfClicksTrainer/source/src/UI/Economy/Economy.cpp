#include <algorithm>
#include <cmath>
#include <cstring>
#include <vector>
#include "UI/Common.h"
#include "UI/Tabs.h"
#include "UI/App.h"

void DrawEconomy() {
    if (Card("eco1", "Treasury & income", "Direct control of your money. 'Freeze' keeps a value locked, 'Min' stops it falling under the number you typed, 'Inf' keeps it at 9 trillion. Numbers accept 1.5m, 20k, 3b, 2t.")) {
        EditRow({"Money (gold)", "gold", "country", "Your treasury. Set = exact value, + / - = add or remove the typed amount."});
        EditRow({"Base income", "baseGoldIncome", "country", "Base gold income before multipliers. The game recomputes it from your buildings, so use Freeze to keep your value."});
        EditRow({"Gross income (last)", "lastGrossGold", "country", "Income before expenses in the last cycle (the game's tax/trade revenue figure)."});
        EditRow({"Net income (last)", "lastNetGoldIncome", "country", "Last computed net income. Mostly informational - the game overwrites it."});
        EditRow({"Management cost", "lastMgmtCost", "country", "Running cost of your administration (an expense). Freeze at 0 to remove it."});
        EditRow({"Army cost", "lastArmyCost", "country", "Upkeep of your army (an expense). Freeze at 0 to remove it."});
    } EndCard();
    if (Card("eco2", "Budget switches", "One-click behaviours. Each can be turned off again.")) {
        LockToggle("Infinite budget", "country.gold", "floor", "9t", "Keeps your treasury at 9 trillion or more so nothing is ever unaffordable (it also means upgrades, construction and recruitment cost nothing in effect).");
        LockToggle("Freeze money", "country.gold", "exact", "", "Keeps your gold at exactly the amount it has right now - spending is refunded instantly. (Switch off 'Infinite budget' first; they share the same lock.)");
        LockToggle("Freeze income", "country.baseGoldIncome", "exact", "", "Locks your base income at its current value so events or upkeep cannot change it.");
        LockToggle("Freeze expenses at 0", "country.lastMgmtCost", "exact", "0", "Forces management cost to 0 every 40 ms.");
        LockToggle("Freeze army upkeep at 0", "country.lastArmyCost", "exact", "0", "Forces army upkeep cost to 0 every 40 ms.");
        ImGui::Separator(); Desc("Gold gain multiplier: multiplies every increase of your treasury while active (clicks, income, trade).");
        for (double m : {2.0, 5.0, 10.0, 100.0}) { ImGui::SameLine(0, 6); std::string l = Fmt("x%g##g", m); if (ImGui::Button(l.c_str())) Cmd(Fmt("gainmult gold %g", m)); } ImGui::SameLine(); if (ImGui::Button("Off##g")) Cmd("gainmult gold 1");
        if (HasGainMultiplier("country.gold")) { ImGui::SameLine(); ImGui::TextColored(kGood, "ACTIVE"); }
    } EndCard();
    if (Card("eco3", "Debt, loans & credit", "Market debt is the game's loan from the world market. Credit rating decides how much you can borrow.")) {
        EditRow({"Market debt", "marketDebt", "country", "Total outstanding market loan. Set to 0 or press 'Repay all'."}, false);
        EditRow({"Daily debt payment", "marketDailyPayment", "country", "How much of the loan is paid every day."}, false);
        EditRow({"War reparations owed", "reparationsDebtRemaining", "country", "Reparations you still owe after losing a war."}, false);
        EditRow({"Credit rating", "creditRating", "country", "Your creditworthiness (decimal; higher = better). Affects loan limits and interest."}, true);
        EditRow({"Missed payments", "marketMissedPayments", "country", "How many payments you missed. Reset to 0 to avoid default penalties."}, false);
        ImGui::Text("Current market interest rate: %s    Max market loan: %s", Val("getMarketInterestRate").c_str(), Val("getMaxMarketLoan").c_str());
        Desc("Interest is calculated by the game from your credit rating, so it cannot be typed directly - raise the credit rating to lower it.");
        Button("Instant repay all debts", "Sets market debt, daily payment, reparations and missed payments to 0 and removes your loans.", "debt repay");
        ImGui::SameLine(); Button("Instant bankruptcy", "Sets your gold to -2 billion and marks missed payments, to trigger the game's bankruptcy handling. Use Undo to revert.", "bankrupt on");
        ImGui::SameLine(); Button("Remove bankruptcy", "Resets negative gold, missed payments, default cooldown and debt.", "bankrupt off");
    } EndCard();
    if (Card("eco4", "Taxes, living standard & economy state", nullptr)) {
        EditRow({"Tax rate (target %)", "targetTaxation", "country", "Policy slider for taxation. Higher = more income but lower happiness. Tax revenue itself is derived from this and your workers."}, false);
        EditRow({"Living standard", "livingStandard", "country", "How well off your citizens are. Freeze it to keep it from decaying."});
        EditRow({"Economic cycle value", "economicCycleValue", "country", "The game's boom/bust state (the 'economic state'). Higher is a boom."});
        EditRow({"Economic development", "cycleDevelopment", "country", "Underlying development of your economy cycle (this is the game's economic growth value)."});
        NotMapped("Inflation", "the game has no inflation value, so there is nothing to edit.");
    } EndCard();
}
