#include "UI/Common.h"
#include <algorithm>
#include <cmath>
#include <cstring>

namespace UI {
const char* kThemeNames[5] = {"Midnight Blue", "Slate Gold", "Emerald", "Light", "Chartroom"};
ImFont *fontBody = nullptr, *fontHead = nullptr, *fontMono = nullptr, *fontBig = nullptr;
static ImFont* Try(ImGuiIO& io, std::initializer_list<const char*> files, float px) { for (auto f : files) { FILE* fp = fopen(f, "rb"); if (fp) { fclose(fp); if (ImFont* r = io.Fonts->AddFontFromFileTTF(f, px)) return r; } } return nullptr; }
void LoadFonts(ImGuiIO& io) {
    // Body: Segoe UI. Headings: Segoe UI Semibold. Numbers: Consolas, so digits line up in columns and tiles.
    fontBody = Try(io, {"C:\\Windows\\Fonts\\segoeui.ttf", "C:\\Windows\\Fonts\\arial.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"}, 17.0f);
    fontHead = Try(io, {"C:\\Windows\\Fonts\\seguisb.ttf", "C:\\Windows\\Fonts\\segoeuib.ttf", "C:\\Windows\\Fonts\\arialbd.ttf"}, 22.0f);
    fontMono = Try(io, {"C:\\Windows\\Fonts\\consola.ttf", "C:\\Windows\\Fonts\\cour.ttf"}, 17.0f);
    fontBig = Try(io, {"C:\\Windows\\Fonts\\consolab.ttf", "C:\\Windows\\Fonts\\consola.ttf", "C:\\Windows\\Fonts\\courbd.ttf"}, 28.0f);
    if (!fontBody) fontBody = io.Fonts->AddFontDefault(); io.FontDefault = fontBody;
}
void PushFont(ImFont* f) { ImGui::PushFont(f); }
void PopFont() { ImGui::PopFont(); }
ImU32 Rgb(uint32_t c, float a) { return IM_COL32((c >> 16) & 255, (c >> 8) & 255, c & 255, (int)(255 * a)); }

void ApplyTheme() {
    Config& c = cfg(); ImGuiStyle& st = ImGui::GetStyle(); ImGui::StyleColorsDark(&st);
    // Shape language: the window is softly rounded, panels and controls are tighter, scrollbars are slim.
    st.WindowRounding = 8; st.ChildRounding = 3; st.FrameRounding = 3; st.GrabRounding = 2; st.TabRounding = 3; st.PopupRounding = 5; st.ScrollbarRounding = 8; st.ScrollbarSize = 11;
    st.ItemSpacing = ImVec2(8, 7); st.FramePadding = ImVec2(9, 5); st.WindowPadding = ImVec2(12, 10); st.WindowBorderSize = 1; st.ChildBorderSize = 1; st.FrameBorderSize = 0; st.CellPadding = ImVec2(8, 4); st.SeparatorTextBorderSize = 1;
    ImVec4* k = st.Colors;
    struct Pal { ImVec4 bg, child, border, frame, btn, btnHot, btnAct, accent; };
    static const Pal pal[5] = {
        {{0.075f, 0.082f, 0.10f, 1}, {0.10f, 0.11f, 0.135f, 1}, {0.20f, 0.22f, 0.27f, 1}, {0.14f, 0.15f, 0.19f, 1}, {0.18f, 0.34f, 0.60f, 1}, {0.24f, 0.44f, 0.75f, 1}, {0.20f, 0.38f, 0.66f, 1}, {0.30f, 0.62f, 1.0f, 1}},
        {{0.09f, 0.09f, 0.10f, 1}, {0.12f, 0.12f, 0.13f, 1}, {0.26f, 0.24f, 0.20f, 1}, {0.17f, 0.16f, 0.15f, 1}, {0.55f, 0.42f, 0.14f, 1}, {0.70f, 0.54f, 0.20f, 1}, {0.62f, 0.48f, 0.16f, 1}, {0.95f, 0.78f, 0.35f, 1}},
        {{0.06f, 0.09f, 0.08f, 1}, {0.09f, 0.13f, 0.12f, 1}, {0.17f, 0.27f, 0.23f, 1}, {0.12f, 0.17f, 0.15f, 1}, {0.14f, 0.45f, 0.34f, 1}, {0.19f, 0.58f, 0.44f, 1}, {0.16f, 0.50f, 0.38f, 1}, {0.35f, 0.90f, 0.65f, 1}},
        {{0.94f, 0.95f, 0.96f, 1}, {0.99f, 0.99f, 1.0f, 1}, {0.75f, 0.77f, 0.80f, 1}, {0.88f, 0.89f, 0.91f, 1}, {0.26f, 0.52f, 0.90f, 1}, {0.32f, 0.60f, 0.98f, 1}, {0.22f, 0.46f, 0.82f, 1}, {0.15f, 0.40f, 0.85f, 1}},
        // Chartroom: blue-black sea-chart ground, slate-teal controls, one brass accent for "where you are"
        {{0.055f, 0.075f, 0.082f, 1}, {0.075f, 0.098f, 0.108f, 1}, {0.150f, 0.200f, 0.220f, 1}, {0.105f, 0.140f, 0.153f, 1}, {0.140f, 0.260f, 0.285f, 1}, {0.185f, 0.340f, 0.370f, 1}, {0.160f, 0.300f, 0.330f, 1}, {0.86f, 0.66f, 0.30f, 1}}};
    const Pal& p = pal[std::max(0, std::min(4, c.theme))];
    if (c.theme == 3) ImGui::StyleColorsLight(&st);
    k[ImGuiCol_WindowBg] = p.bg; k[ImGuiCol_ChildBg] = p.child; k[ImGuiCol_PopupBg] = p.child; k[ImGuiCol_Border] = p.border; k[ImGuiCol_FrameBg] = p.frame;
    k[ImGuiCol_Button] = p.btn; k[ImGuiCol_ButtonHovered] = p.btnHot; k[ImGuiCol_ButtonActive] = p.btnAct;
    k[ImGuiCol_Header] = ImVec4(p.btn.x, p.btn.y, p.btn.z, 0.55f); k[ImGuiCol_HeaderHovered] = ImVec4(p.btnHot.x, p.btnHot.y, p.btnHot.z, 0.75f); k[ImGuiCol_HeaderActive] = p.btnAct;
    k[ImGuiCol_CheckMark] = p.accent; k[ImGuiCol_SliderGrab] = p.accent; k[ImGuiCol_TableRowBgAlt] = ImVec4(1, 1, 1, c.theme == 3 ? 0.0f : 0.03f);
    k[ImGuiCol_TitleBg] = p.child; k[ImGuiCol_TitleBgActive] = p.btn; k[ImGuiCol_Tab] = p.child; k[ImGuiCol_TabHovered] = p.btnHot; k[ImGuiCol_TabSelected] = p.btn;
    if (c.theme == 4) { k[ImGuiCol_Text] = ImVec4(0.86f, 0.89f, 0.87f, 1); k[ImGuiCol_TextDisabled] = ImVec4(0.50f, 0.58f, 0.57f, 1); k[ImGuiCol_Separator] = p.border; k[ImGuiCol_TableBorderLight] = p.border; k[ImGuiCol_TableBorderStrong] = p.border; k[ImGuiCol_TableHeaderBg] = p.frame;
        k[ImGuiCol_FrameBgHovered] = ImVec4(0.14f, 0.19f, 0.21f, 1); k[ImGuiCol_FrameBgActive] = ImVec4(0.17f, 0.23f, 0.25f, 1); k[ImGuiCol_ScrollbarBg] = ImVec4(0, 0, 0, 0); k[ImGuiCol_ScrollbarGrab] = p.border; k[ImGuiCol_TextSelectedBg] = ImVec4(p.accent.x, p.accent.y, p.accent.z, 0.30f); k[ImGuiCol_NavCursor] = p.accent; }
    kAccent = p.accent; kDim = c.theme == 3 ? ImVec4(0.36f, 0.38f, 0.42f, 1) : ImVec4(0.62f, 0.66f, 0.72f, 1);
    kGood = c.theme == 3 ? ImVec4(0.05f, 0.55f, 0.20f, 1) : c.theme == 4 ? ImVec4(0.38f, 0.80f, 0.66f, 1) : ImVec4(0.35f, 0.85f, 0.5f, 1); kBad = c.theme == 3 ? ImVec4(0.80f, 0.15f, 0.15f, 1) : c.theme == 4 ? ImVec4(0.93f, 0.44f, 0.38f, 1) : ImVec4(0.95f, 0.38f, 0.38f, 1);
    kWarn = c.theme == 3 ? ImVec4(0.75f, 0.45f, 0.0f, 1) : c.theme == 4 ? ImVec4(0.95f, 0.82f, 0.45f, 1) : ImVec4(1.0f, 0.75f, 0.30f, 1);
    ImGui::GetIO().FontGlobalScale = std::max(0.6f, std::min(2.0f, c.uiScale));
}

bool NeedGame() {
    GameState& s = state();
    if (s.Ready()) return false;
    ImGui::Spacing();
    if (link().multiplayer) { ImGui::PushStyleColor(ImGuiCol_Text, kBad); ImGui::TextWrapped("Blocked: multiplayer detected. This tool only works in single-player."); ImGui::PopStyleColor(); }
    else if (!link().connected) Desc(host().overlay ? "The in-game bridge is not responding yet. Wait a moment, or reload a game." : "Not connected to the game. Open the Dashboard and press 'Inject / Connect'.");
    else Desc("Connected. Load or start a single-player game and this page will fill in.");
    return true;
}
void Tip(const char* t) { if (t && *t && ImGui::IsItemHovered(ImGuiHoveredFlags_DelayShort)) ImGui::SetTooltip("%s", t); }
bool Search(const char* id, std::string& text, const char* hint, float w) {
    char tmp[128]; snprintf(tmp, sizeof tmp, "%s", text.c_str()); ImGui::SetNextItemWidth(w);
    bool ch = ImGui::InputTextWithHint(id, hint, tmp, sizeof tmp); if (ch) text = tmp; return ch;
}
void LineGraph(const char* id, const std::vector<float>& v, ImVec2 size, const char* unit) {
    if (v.size() < 2) { ImGui::Dummy(size); ImGui::SameLine(); ImGui::TextDisabled("collecting data..."); return; }
    float mn = *std::min_element(v.begin(), v.end()), mx = *std::max_element(v.begin(), v.end()); if (mx - mn < 1e-6f) { mx += 1; mn -= 1; }
    if (size.x <= 0) size.x = ImGui::GetContentRegionAvail().x;
    ImGui::PlotLines(id, v.data(), (int)v.size(), 0, nullptr, mn, mx, size);
    ImVec2 a = ImGui::GetItemRectMin(); ImDrawList* d = ImGui::GetWindowDrawList();
    std::string hi = Human(mx) + unit, lo = Human(mn) + unit; d->AddText(ImVec2(a.x + 4, a.y + 2), ImGui::GetColorU32(ImGuiCol_TextDisabled), hi.c_str());
    d->AddText(ImVec2(a.x + 4, a.y + size.y - ImGui::GetFontSize() - 2), ImGui::GetColorU32(ImGuiCol_TextDisabled), lo.c_str());
}
void Heading(const char* t) { PushFont(fontHead); ImGui::TextUnformatted(t); PopFont(); ImGui::Separator(); }
void Pill(const char* text, ImVec4 col) {
    ImVec2 ts = ImGui::CalcTextSize(text), p = ImGui::GetCursorScreenPos(); float h = ImGui::GetTextLineHeight() + 4, w = ts.x + h + 6; ImDrawList* d = ImGui::GetWindowDrawList();
    d->AddRectFilled(p, ImVec2(p.x + w, p.y + h), ImGui::GetColorU32(ImVec4(col.x, col.y, col.z, 0.16f)), h * 0.5f);
    d->AddCircleFilled(ImVec2(p.x + h * 0.5f, p.y + h * 0.5f), 3.2f, ImGui::GetColorU32(col));
    d->AddText(ImVec2(p.x + h * 0.5f + 8, p.y + 2), ImGui::GetColorU32(ImGuiCol_Text), text); ImGui::Dummy(ImVec2(w, h));
}
void Bar(float f, ImVec2 size, ImVec4 col) {
    if (size.x <= 0) size.x = ImGui::GetContentRegionAvail().x; ImVec2 p = ImGui::GetCursorScreenPos(); ImDrawList* d = ImGui::GetWindowDrawList(); f = std::max(0.0f, std::min(1.0f, f));
    d->AddRectFilled(p, ImVec2(p.x + size.x, p.y + size.y), ImGui::GetColorU32(ImGuiCol_FrameBg), 2); if (f > 0) d->AddRectFilled(p, ImVec2(p.x + size.x * f, p.y + size.y), ImGui::GetColorU32(col), 2); ImGui::Dummy(size);
}
bool StatTile(const char* id, const char* label, const std::string& shown, const std::string& field, const std::string& note, ImVec4 noteCol, const std::vector<float>* spark, float width) {
    bool acted = false; ImGui::PushID(id);
    ImGui::BeginChild("tile", ImVec2(width, ImGui::GetFontSize() * 6.2f), ImGuiChildFlags_Borders, ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse);
    ImGui::TextDisabled("%s", label);
    PushFont(fontBig); acted = ClickValue("v", "country", field, shown, label); PopFont();
    if (!note.empty()) { ImGui::PushStyleColor(ImGuiCol_Text, noteCol); PushFont(fontMono); ImGui::TextUnformatted(note.c_str()); PopFont(); ImGui::PopStyleColor(); }
    if (spark && spark->size() > 2) { ImVec2 p = ImGui::GetWindowPos(), sz = ImGui::GetWindowSize(); float mn = *std::min_element(spark->begin(), spark->end()), mx = *std::max_element(spark->begin(), spark->end()); if (mx - mn < 1e-6f) { mx += 1; mn -= 1; }
        ImDrawList* d = ImGui::GetWindowDrawList(); int n = (int)spark->size(); float x0 = p.x + sz.x * 0.52f, x1 = p.x + sz.x - 10, y0 = p.y + 12, y1 = p.y + sz.y * 0.45f; ImVec2 prev;
        for (int i = 0; i < n; i++) { ImVec2 q(x0 + (x1 - x0) * i / (n - 1), y1 - (y1 - y0) * ((*spark)[i] - mn) / (mx - mn)); if (i) d->AddLine(prev, q, ImGui::GetColorU32(kAccent), 1.5f); prev = q; } }
    ImGui::EndChild(); ImGui::PopID(); return acted;
}
bool IsFav(const std::string& n) { auto& f = cfg().favorites; return std::find(f.begin(), f.end(), n) != f.end(); }
void ToggleFav(const std::string& n) { auto& f = cfg().favorites; auto it = std::find(f.begin(), f.end(), n); if (it == f.end()) f.push_back(n); else f.erase(it); }
bool Fuzzy(const std::string& hay, const std::string& needle, int* score) {
    if (needle.empty()) { if (score) *score = 0; return true; }
    std::string h = LowerCase(hay), n = LowerCase(needle); size_t hi = 0; int sc = 0, run = 0;
    for (char ch : n) { if (ch == ' ') continue; size_t f = h.find(ch, hi); if (f == std::string::npos) return false; run = (f == hi && hi > 0) ? run + 1 : 0; sc += 10 + run * 6 - (int)std::min<size_t>(f - hi, 8) + ((f == 0 || h[f - 1] == ' ') ? 8 : 0); hi = f + 1; }
    if (h.find(n) != std::string::npos) sc += 60; if (score) *score = sc; return true;
}
}

void Desc(const char* t) { ImGui::PushStyleColor(ImGuiCol_Text, kDim); ImGui::TextWrapped("%s", t); ImGui::PopStyleColor(); }
void Badge(const char* t, ImVec4 c) {
    ImGui::SameLine(); ImGui::PushStyleColor(ImGuiCol_Text, c); ImGui::Text("[%s]", t); ImGui::PopStyleColor();
    if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s", strcmp(t, "experimental") == 0 ? "Best-effort feature: it uses game internals that could not be verified offline. Use Undo if the result is odd." : "This feature is mapped to the nearest mechanic the game actually has.");
}
bool Card(const char* id, const char* title, const char* desc, const char* badge) {
    ImGui::PushStyleVar(ImGuiStyleVar_ChildRounding, 6); ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(12, 10));
    ImGui::BeginChild(id, ImVec2(0, 0), ImGuiChildFlags_Borders | ImGuiChildFlags_AutoResizeY, ImGuiWindowFlags_NoScrollbar);   // an auto-sized child reports "hidden" on its first frame, so the content below always runs and EndCard() must always be called
    ImGui::PopStyleVar(2);
    ImGui::PushStyleColor(ImGuiCol_Text, kAccent); ImGui::TextUnformatted(title); ImGui::PopStyleColor();
    if (badge) Badge(badge, strcmp(badge, "experimental") == 0 ? kWarn : kDim);
    if (desc && *desc) Desc(desc); ImGui::Spacing(); return true;
}
void EndCard() { ImGui::EndChild(); ImGui::Spacing(); }
static std::map<std::string, std::string> g_buf;
char* Buf(const std::string& id, const char* def) { auto& s = g_buf[id]; if (s.empty() && *def) s = def; s.resize(63); return s.data(); }
std::string BufStr(const std::string& id) { std::string s = g_buf[id]; size_t z = s.find('\0'); if (z != std::string::npos) s.resize(z); return s; }

bool ClickValue(const char* id, const std::string& target, const std::string& field, const std::string& shown, const char* label, ImVec4 col) {
    bool acted = false; ImGui::PushID(id);
    ImGui::PushStyleColor(ImGuiCol_Text, col); ImGui::TextUnformatted(shown.empty() ? "-" : shown.c_str()); ImGui::PopStyleColor();
    bool hov = ImGui::IsItemHovered(); ImVec2 a = ImGui::GetItemRectMin(), b = ImGui::GetItemRectMax();
    if (hov) { ImGui::SetMouseCursor(ImGuiMouseCursor_Hand); ImGui::GetWindowDrawList()->AddLine(ImVec2(a.x, b.y), ImVec2(b.x, b.y), ImGui::GetColorU32(col), 1.0f); ImGui::SetTooltip("Click to edit: %s", label); }
    if ((hov && (ImGui::IsMouseClicked(0) || ImGui::IsMouseClicked(1))) || g_testForcePopups) ImGui::OpenPopup("##edit");
    ImGui::SetNextWindowSizeConstraints(ImVec2(300, 0), ImVec2(520, 600));
    if (ImGui::BeginPopup("##edit")) {
        std::string key = target + "." + field, bid = std::string("pv_") + key;
        UI::Heading((std::string("Edit: ") + label).c_str()); ImGui::TextDisabled("%s", key.c_str());
        if (!shown.empty()) { ImGui::Text("Current value:"); ImGui::SameLine(); ImGui::TextColored(col, "%s", shown.c_str()); }
        ImGui::SetNextItemWidth(-1); if (ImGui::IsWindowAppearing()) ImGui::SetKeyboardFocusHere();
        bool enter = ImGui::InputTextWithHint("##v", "new value, e.g. 5m, 20k, 3b", Buf(bid), 64, ImGuiInputTextFlags_EnterReturnsTrue);
        std::string v = BufStr(bid); bool can = !v.empty(); ImGui::BeginDisabled(!can);
        if (ImGui::Button("Set") || (enter && can)) { Game::Set(target, field, v); acted = true; } UI::Tip("Replace the value with the typed number.");
        ImGui::SameLine(); if (ImGui::Button("Add")) { Game::Add(target, field, v); acted = true; }
        ImGui::SameLine(); if (ImGui::Button("Subtract")) { Game::Add(target, field, "-" + v); acted = true; }
        ImGui::SameLine(); if (ImGui::Button("Multiply")) { Game::Multiply(target, field, v); acted = true; } UI::Tip("Multiply the current value by the typed factor (original value is remembered for Reset).");
        ImGui::EndDisabled();
        ImGui::TextDisabled("Quick:"); ImGui::SameLine();
        for (const char* f : {"0.5", "2", "10"}) { std::string l = std::string("x") + f; if (ImGui::SmallButton(l.c_str())) { Game::Multiply(target, field, f); acted = true; } ImGui::SameLine(); }
        if (ImGui::SmallButton("+1k")) { Game::Add(target, field, "1k"); acted = true; } ImGui::SameLine(); if (ImGui::SmallButton("+1m")) { Game::Add(target, field, "1m"); acted = true; } ImGui::SameLine(); if (ImGui::SmallButton("+1b")) { Game::Add(target, field, "1b"); acted = true; }
        ImGui::Separator();
        bool lk = IsLocked(key); if (ImGui::Checkbox("Freeze", &lk)) { Game::Freeze(target, field, lk); acted = true; } UI::Tip("Keep the value exactly as it is now (re-applied every 40 ms).");
        ImGui::SameLine(); if (ImGui::Button("Minimum")) { Game::Floor(target, field, can ? v : "0"); acted = true; } UI::Tip("Never let the value fall below the typed number.");
        ImGui::SameLine(); if (ImGui::Button("Infinite")) { Game::Floor(target, field, "9t"); acted = true; } UI::Tip("Keep the value at 9 trillion or more.");
        ImGui::SameLine(); if (ImGui::Button("Reset")) { Game::Reset(target, field); acted = true; } UI::Tip("Restore the value this tool first saw.");
        if (ImGui::Button("Close")) ImGui::CloseCurrentPopup();
        ImGui::EndPopup();
    }
    ImGui::PopID(); return acted;
}

void EditRowT(const std::string& label, const std::string& field, const std::string& target, const std::string& desc, bool locks, const std::string& shownIn) {
    std::string key = target + "." + field, id = "ed_" + key;
    ImGui::PushID(id.c_str());
    ImGui::AlignTextToFramePadding(); ImGui::TextUnformatted(label.c_str()); ImGui::SameLine(ImGui::GetFontSize() * 13);
    std::string shown = shownIn.empty() ? (target == "country" ? Val(field) : std::string("(click)")) : shownIn;
    ClickValue("cv", target, field, shown, label.c_str());
    ImGui::SameLine(ImGui::GetFontSize() * 21); ImGui::SetNextItemWidth(ImGui::GetFontSize() * 7); ImGui::InputText("##v", Buf(id), 64);
    std::string v = BufStr(id); bool can = !v.empty();
    ImGui::SameLine(); ImGui::BeginDisabled(!can);
    if (ImGui::SmallButton("Set")) Game::Set(target, field, v); ImGui::SameLine();
    if (ImGui::SmallButton("+")) Game::Add(target, field, v); ImGui::SameLine();
    if (ImGui::SmallButton("-")) Game::Add(target, field, "-" + v); ImGui::SameLine();
    if (ImGui::SmallButton("x")) Game::Multiply(target, field, v); UI::Tip("Multiply by the typed factor.");
    ImGui::EndDisabled();
    ImGui::SameLine(); if (ImGui::SmallButton("Reset")) Game::Reset(target, field); UI::Tip("Restore the value this tool first saw (only works after an edit made here).");
    if (locks) {
        bool lk = IsLocked(key); ImGui::SameLine(); if (ImGui::Checkbox("Freeze", &lk)) Game::Freeze(target, field, lk); UI::Tip("Freeze: keeps this value exactly as it is now, every 40 ms. Un-tick to release.");
        ImGui::SameLine(); if (ImGui::SmallButton("Min")) Game::Floor(target, field, can ? v : "0"); UI::Tip("Never drop below the typed value (it can still grow). Release with Freeze on/off.");
        ImGui::SameLine(); if (ImGui::SmallButton("Inf")) Game::Floor(target, field, "9t"); UI::Tip("Infinite: keeps it at 9 trillion minimum so it can never run out.");
    }
    if (!desc.empty()) { ImGui::PushStyleColor(ImGuiCol_Text, kDim); ImGui::TextWrapped("%s", desc.c_str()); ImGui::PopStyleColor(); }
    ImGui::Separator(); ImGui::PopID();
}
void EditRow(const Stat& s, bool locks) { EditRowT(s.label, s.field, s.target, s.desc, locks); }
void Button(const char* label, const char* tip, const std::string& cmd, ImVec2 sz) { if (ImGui::Button(label, sz)) Cmd(cmd); if (tip && ImGui::IsItemHovered()) ImGui::SetTooltip("%s", tip); }
bool FlagToggle(const char* label, const char* flag, const char* desc, const char* badge) {
    bool on = IsFlag(flag); ImGui::PushID(flag); bool ch = ImGui::Checkbox(label, &on); if (ch) SetFlag(flag, on); if (badge) Badge(badge, kWarn); if (desc) Desc(desc); ImGui::PopID(); return ch;
}
bool LockToggle(const char* label, const char* key, const char* mode, const char* val, const char* desc) {
    bool on = IsLocked(key); ImGui::PushID(key); bool ch = ImGui::Checkbox(label, &on);
    if (ch) Cmd(on ? Fmt("lock %s %s %s", key, mode, val) : Fmt("lock %s off", key)); if (desc) Desc(desc); ImGui::PopID(); return ch;
}
void NotMapped(const char* what, const char* why) { ImGui::PushStyleColor(ImGuiCol_Text, kDim); ImGui::BulletText("%s - %s", what, why); ImGui::PopStyleColor(); }
