// One draw function per tab. Each draws into the current ImGui window/child.
#pragma once
void DrawDashboard(); void DrawMapTab(); void DrawCountries(); void DrawEvents();
void DrawEconomy(); void DrawPopulation(); void DrawMilitary(); void DrawResearch(); void DrawResources(); void DrawIndustry();
void DrawDiplomacy(); void DrawTerritory(); void DrawPolitics(); void DrawWorld();
void DrawPlanner(); void DrawTime(); void DrawAutomation(); void DrawPresets(); void DrawHistory(); void DrawVariables();
void DrawStates(); void DrawSaveEditor(); void DrawConsole(); void DrawSettings();
void DrawRankings(); void DrawCompare(); void DrawDiagnostics(); void DrawHelp();
