#include <algorithm>
#include <cmath>
#include <cstring>
#include <vector>
#include "UI/Common.h"
#include "UI/Tabs.h"
#include "UI/App.h"

void DrawResearch() {
    Poll("techs list", "techs", 2.0);
    if (Card("s1", "Research controls", "Science points are spent on technologies. These tools skip or speed that up.")) {
        EditRow({"Science points", "sciencePoints", "country", "Your research points pool. Raise it to afford more technologies; Min keeps a reserve."});
        EditRow({"Science funding (%)", "targetScienceFunding", "country", "Budget slider for science - higher funding = faster research."}, false);
        ImGui::Text("Science per day: %s", Val("getDailyScienceRate").c_str());
        Desc("Research speed multiplier - multiplies every gain of science points while active.");
        for (double m : {2.0, 5.0, 10.0, 100.0}) { ImGui::SameLine(0, 6); std::string l = Fmt("x%g##sm", m); if (ImGui::Button(l.c_str())) Cmd(Fmt("gainmult sciencePoints %g", m)); } ImGui::SameLine(); if (ImGui::Button("Off##sm")) Cmd("gainmult sciencePoints 1");
        FlagToggle("Instant research", "instantresearch", "Anything you put in the research queue is completed immediately (with all prerequisites).");
        ImGui::Separator();
        Button("Unlock ALL technologies", "Researches every technology in the game.", "techs all"); ImGui::SameLine(); Button("Military", "Unlock the whole military branch.", "techs military"); ImGui::SameLine();
        Button("Economy", "Unlock the whole economy branch.", "techs economy"); ImGui::SameLine(); Button("Politics", "Unlock the whole politics branch.", "techs politics"); ImGui::SameLine();
        Button("Reset research", "Forgets ALL researched technologies and clears the queue. Undo available.", "techs reset");
        ImGui::Text("Research focus now: %s", link().Get("focus").c_str()); ImGui::SameLine();
        Button("Focus: economy", "Selects the economy research focus instantly.", "focus economy"); ImGui::SameLine(); Button("military", "Selects the military research focus.", "focus military"); ImGui::SameLine(); Button("politics", "Selects the politics research focus.", "focus politics");
        Desc("Removing research requirements: 'Unlock ALL' + 'Instant research' skip every prerequisite and cost.");
    } EndCard();
    if (Card("s2", "Technology list / queue helper", "Click 'Queue' to add a technology to the research queue (prerequisites are researched with it when you use Unlock). Cheapest researchable ones are highlighted.")) {
        static char flt[64] = ""; static int br = 0; ImGui::SetNextItemWidth(200); ImGui::InputTextWithHint("##tf", "filter by name...", flt, 64); ImGui::SameLine(); ImGui::SetNextItemWidth(140); ImGui::Combo("##br", &br, "All branches\0economy\0military\0politics\0");
        ImGui::SameLine(); ImGui::Text("Queue: %s   Known: %s", link().Get("queued").c_str(), link().Get("researched").c_str());
        std::string raw = link().Payload("techs");
        if (ImGui::BeginTable("tl", 6, ImGuiTableFlags_RowBg | ImGuiTableFlags_ScrollY | ImGuiTableFlags_SizingStretchProp, ImVec2(0, 380))) {
            ImGui::TableSetupColumn("Technology", 0, 3); ImGui::TableSetupColumn("Branch"); ImGui::TableSetupColumn("Epoch"); ImGui::TableSetupColumn("Cost"); ImGui::TableSetupColumn("Status"); ImGui::TableSetupColumn("Actions", 0, 2); ImGui::TableHeadersRow();
            static const char* bn[] = {"", "economy", "military", "politics"};
            for (auto& r : Split(raw, '\x1e')) { auto c = Split(r, '\x1f'); if (c.size() < 6) continue; if (*flt && c[0].find(flt) == std::string::npos) continue; if (br && c[1].find(bn[br]) == std::string::npos) continue;
                bool done = c[4] == "1", can = c[5] == "1"; ImGui::TableNextRow(); ImGui::PushID(c[0].c_str());
                ImGui::TableNextColumn(); ImGui::TextColored(done ? kDim : can ? kGood : ImGui::GetStyle().Colors[ImGuiCol_Text], "%s", c[0].c_str()); ImGui::TableNextColumn(); ImGui::TextUnformatted(c[1].c_str()); ImGui::TableNextColumn(); ImGui::TextUnformatted(c[2].c_str());
                ImGui::TableNextColumn(); ImGui::TextUnformatted(Human(atof(c[3].c_str())).c_str()); ImGui::TableNextColumn(); ImGui::TextUnformatted(done ? "known" : can ? "researchable" : "locked");
                ImGui::TableNextColumn(); ImGui::BeginDisabled(done); if (ImGui::SmallButton("Queue")) Cmd("enqueue " + c[0]); ImGui::SameLine(); if (ImGui::SmallButton("Unlock now")) Cmd("techunlock " + c[0]); ImGui::EndDisabled(); ImGui::PopID(); }
            ImGui::EndTable(); }
        Button("Clear queue", "Empties the research queue.", "dequeue");
    } EndCard();
}
