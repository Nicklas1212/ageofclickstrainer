#include <algorithm>
#include "Palette/Palette.h"
#include "UI/Common.h"
#include "UI/Tabs.h"

namespace {
struct Metric { const char* name; double (*get)(const CountryRow&); };
const Metric kMetrics[] = {
    {"Population", [](const CountryRow& c) { return c.pop; }}, {"Money", [](const CountryRow& c) { return c.gold; }}, {"Military strength", [](const CountryRow& c) { return c.strength; }},
    {"Happiness", [](const CountryRow& c) { return c.happiness; }}, {"Stability", [](const CountryRow& c) { return c.Stability(); }}, {"Territory size", [](const CountryRow& c) { return c.territory; }},
    {"Income", [](const CountryRow& c) { return c.income; }}, {"Manpower", [](const CountryRow& c) { return c.manpower; }}, {"Science points", [](const CountryRow& c) { return c.science; }}, {"Living standard", [](const CountryRow& c) { return c.living; }}};
}

void DrawRankings() {
    state().PollWorld(2.0); auto& cs = state().Countries();
    static int metric = 0, resMetric = 0; static bool useRes = false, pinnedOnly = false, asc = false; static int topN = 25; static std::string flt;
    Config& c = cfg(); (void)c;
    ImGui::SetNextItemWidth(ImGui::GetFontSize() * 13);
    if (ImGui::BeginCombo("Rank by", useRes ? kResNames[resMetric] : kMetrics[metric].name)) {
        ImGui::TextDisabled("Statistics"); for (int i = 0; i < (int)(sizeof kMetrics / sizeof *kMetrics); i++) if (ImGui::Selectable(kMetrics[i].name, !useRes && metric == i)) { metric = i; useRes = false; }
        ImGui::Separator(); ImGui::TextDisabled("Resource stockpile"); for (int i = 0; i < kResCount; i++) if (ImGui::Selectable(kResNames[i], useRes && resMetric == i)) { resMetric = i; useRes = true; }
        ImGui::EndCombo(); }
    ImGui::SameLine(); ImGui::Checkbox("Lowest first", &asc); ImGui::SameLine(); ImGui::Checkbox("Pinned only", &pinnedOnly); UI::Tip("Show only the countries you pinned with the star.");
    ImGui::SameLine(); ImGui::SetNextItemWidth(ImGui::GetFontSize() * 7); ImGui::SliderInt("Show", &topN, 5, 100); ImGui::SameLine(); UI::Search("##rf", flt, "filter by name", ImGui::GetFontSize() * 11);
    if (cs.empty()) { Desc("Loading the world table..."); return; }
    auto val = [&](const CountryRow& r) { return useRes ? r.stock[resMetric] : kMetrics[metric].get(r); };
    std::vector<const CountryRow*> all; for (auto& r : cs) all.push_back(&r);
    std::stable_sort(all.begin(), all.end(), [&](const CountryRow* a, const CountryRow* b) { return asc ? val(*a) < val(*b) : val(*a) > val(*b); });
    int myRank = 0; for (size_t i = 0; i < all.size(); i++) if (all[i]->me) myRank = (int)i + 1;
    double mx = 0; for (auto* r : all) mx = std::max(mx, std::abs(val(*r)));
    if (myRank) { ImGui::Spacing(); ImGui::Text("You are"); ImGui::SameLine(); UI::PushFont(UI::fontMono); ImGui::TextColored(kAccent, "#%d of %d", myRank, (int)all.size()); UI::PopFont(); }
    ImGui::Spacing();
    if (ImGui::BeginTable("rank", 4, ImGuiTableFlags_RowBg | ImGuiTableFlags_ScrollY | ImGuiTableFlags_SizingStretchProp | ImGuiTableFlags_PadOuterX)) {
        ImGui::TableSetupColumn("Rank", ImGuiTableColumnFlags_WidthFixed, ImGui::GetFontSize() * 3.2f); ImGui::TableSetupColumn("Country", 0, 2.4f); ImGui::TableSetupColumn("Value", ImGuiTableColumnFlags_WidthFixed, ImGui::GetFontSize() * 7); ImGui::TableSetupColumn("Share of the leader", 0, 3.0f);
        ImGui::TableSetupScrollFreeze(0, 1); ImGui::TableHeadersRow(); int shown = 0;
        for (size_t i = 0; i < all.size() && shown < topN; i++) { const CountryRow& r = *all[i]; if (pinnedOnly && !UI::IsFav(r.name)) continue; if (!flt.empty() && !ContainsNoCase(r.name, flt)) continue; shown++;
            ImGui::TableNextRow(); ImGui::PushID(r.name.c_str()); ImGui::TableNextColumn(); UI::PushFont(UI::fontMono); ImGui::TextDisabled("%d", (int)i + 1); UI::PopFont();
            ImGui::TableNextColumn(); bool fav = UI::IsFav(r.name); if (ImGui::SmallButton(fav ? "\xE2\x98\x85" : "\xE2\x98\x86")) UI::ToggleFav(r.name); UI::Tip(fav ? "Unpin this country." : "Pin this country to the sidebar."); ImGui::SameLine();
            ImGui::ColorButton("##c", ImGui::ColorConvertU32ToFloat4(UI::Rgb(r.color)), ImGuiColorEditFlags_NoTooltip | ImGuiColorEditFlags_NoPicker | ImGuiColorEditFlags_NoDragDrop, ImVec2(10, 10)); ImGui::SameLine();
            if (ImGui::Selectable(r.name.c_str(), r.me, ImGuiSelectableFlags_None)) Palette::Run("country:" + r.name); if (r.me) { ImGui::SameLine(); ImGui::TextColored(kAccent, "you"); }
            ImGui::TableNextColumn(); UI::PushFont(UI::fontMono); ImGui::TextUnformatted(Human(val(r)).c_str()); UI::PopFont();
            ImGui::TableNextColumn(); ImGui::Dummy(ImVec2(0, 3)); UI::Bar(mx > 0 ? (float)(std::abs(val(r)) / mx) : 0, ImVec2(-1, 8), r.me ? kAccent : kDim); ImGui::PopID(); }
        ImGui::EndTable(); }
}
