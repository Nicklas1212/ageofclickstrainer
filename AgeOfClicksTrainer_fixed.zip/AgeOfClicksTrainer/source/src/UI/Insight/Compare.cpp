#include <algorithm>
#include "Palette/Palette.h"
#include "UI/Common.h"
#include "UI/Tabs.h"

void DrawCompare() {
    state().PollWorld(2.0); auto& cs = state().Countries();
    static std::vector<std::string> sel; static std::string pick;
    if (cs.empty()) { Desc("Loading the world table..."); return; }
    if (sel.empty()) for (auto& r : cs) if (r.me) sel.push_back(r.name);
    sel.erase(std::remove_if(sel.begin(), sel.end(), [&](const std::string& n) { return !state().Find(n); }), sel.end());
    ImGui::SetNextItemWidth(ImGui::GetFontSize() * 14);
    if (ImGui::BeginCombo("##add", "Add a country...")) { UI::Search("##pf", pick, "type to filter", -1); if (ImGui::IsWindowAppearing()) ImGui::SetKeyboardFocusHere(-1);
        for (auto& r : cs) { if (!pick.empty() && !ContainsNoCase(r.name, pick)) continue; if (std::find(sel.begin(), sel.end(), r.name) != sel.end()) continue; if (ImGui::Selectable(r.name.c_str()) && sel.size() < 4) { sel.push_back(r.name); } }
        ImGui::EndCombo(); }
    ImGui::SameLine(); if (!state().selected.empty() && ImGui::Button("Add selected country") && sel.size() < 4 && std::find(sel.begin(), sel.end(), state().selected) == sel.end()) sel.push_back(state().selected);
    ImGui::SameLine(); if (ImGui::Button("Add pinned")) for (auto& f : cfg().favorites) if (sel.size() < 4 && state().Find(f) && std::find(sel.begin(), sel.end(), f) == sel.end()) sel.push_back(f);
    ImGui::SameLine(); if (ImGui::Button("Clear")) sel.clear(); ImGui::SameLine(); ImGui::TextDisabled("Up to four countries");
    if (sel.size() < 2) { ImGui::Spacing(); Desc("Add at least two countries to compare them. The best value in each row is highlighted."); }
    if (sel.empty()) return;
    struct Row { const char* label; double (*get)(const CountryRow&); } rows[] = {{"Population", [](const CountryRow& c) { return c.pop; }}, {"Money", [](const CountryRow& c) { return c.gold; }}, {"Military strength", [](const CountryRow& c) { return c.strength; }},
        {"Happiness", [](const CountryRow& c) { return c.happiness; }}, {"Stability", [](const CountryRow& c) { return c.Stability(); }}, {"Territory size", [](const CountryRow& c) { return c.territory; }}, {"Income", [](const CountryRow& c) { return c.income; }},
        {"Manpower", [](const CountryRow& c) { return c.manpower; }}, {"Science points", [](const CountryRow& c) { return c.science; }}, {"Living standard", [](const CountryRow& c) { return c.living; }}};
    ImGui::Spacing();
    if (ImGui::BeginTable("cmp", (int)sel.size() + 1, ImGuiTableFlags_RowBg | ImGuiTableFlags_SizingStretchProp | ImGuiTableFlags_PadOuterX)) {
        ImGui::TableSetupColumn(""); for (auto& n : sel) ImGui::TableSetupColumn(n.c_str()); ImGui::TableHeadersRow();
        ImGui::TableNextRow(); ImGui::TableNextColumn(); ImGui::TextDisabled("Open");
        for (size_t i = 0; i < sel.size(); i++) { ImGui::TableNextColumn(); ImGui::PushID((int)i); if (ImGui::SmallButton("Inspect")) Palette::Run("country:" + sel[i]); ImGui::SameLine(); if (ImGui::SmallButton("Map")) Palette::Run("map:" + sel[i]); ImGui::SameLine(); if (ImGui::SmallButton("Remove")) { sel.erase(sel.begin() + i); ImGui::PopID(); break; } ImGui::PopID(); }
        for (auto& r : rows) { ImGui::TableNextRow(); ImGui::TableNextColumn(); ImGui::TextUnformatted(r.label); double best = -1e300, mx = 0; for (auto& n : sel) if (auto* c = state().Find(n)) { best = std::max(best, r.get(*c)); mx = std::max(mx, std::abs(r.get(*c))); }
            for (auto& n : sel) { ImGui::TableNextColumn(); auto* c = state().Find(n); if (!c) continue; double v = r.get(*c); bool top = sel.size() > 1 && v == best; UI::PushFont(UI::fontMono); ImGui::TextColored(top ? kGood : ImGui::GetStyleColorVec4(ImGuiCol_Text), "%s", Human(v).c_str()); UI::PopFont(); UI::Bar(mx > 0 ? (float)(std::abs(v) / mx) : 0, ImVec2(-1, 5), top ? kGood : kDim); } }
        ImGui::EndTable(); }
}
