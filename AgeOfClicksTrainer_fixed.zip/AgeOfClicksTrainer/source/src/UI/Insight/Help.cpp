#include "Input/Keys.h"
#include "UI/Common.h"
#include "UI/Tabs.h"

void DrawHelp() {
    if (Card("h_start", "Getting started", nullptr)) {
        ImGui::BulletText("Load or start a single-player game. The status pill at the top turns green when the tool is connected.");
        ImGui::BulletText("Click any highlighted number to edit it: set it, add, subtract, multiply, freeze it or reset it.");
        ImGui::BulletText("Press Ctrl+K to jump to any page, country, preset or action by typing a few letters.");
        ImGui::BulletText("Use the Economy Planner to state the economy you want; it works out which upgrades to buy.");
        ImGui::BulletText("Make a backup on the Save States page before big changes. Undo covers value edits, not territory owner changes.");
        EndCard();
    }
    if (Card("h_keys", "Keyboard shortcuts", nullptr)) {
        if (ImGui::BeginTable("keys", 2, ImGuiTableFlags_RowBg | ImGuiTableFlags_SizingStretchProp)) {
            struct K { const char* k; const char* d; } fixed[] = {{"Ctrl+K", "Command palette"}, {"Ctrl+F", "Filter the page list"}, {"Ctrl+Z / Ctrl+Y", "Undo / redo"}, {"Ctrl+PageUp / PageDown", "Previous / next page"}, {"Esc", "Close the palette or a popup"}};
            for (auto& k : fixed) { ImGui::TableNextRow(); ImGui::TableNextColumn(); UI::PushFont(UI::fontMono); ImGui::TextUnformatted(k.k); UI::PopFont(); ImGui::TableNextColumn(); ImGui::TextUnformatted(k.d); }
            for (int i = 0; i < A_COUNT; i++) { if (!cfg().vk[i]) continue; ImGui::TableNextRow(); ImGui::TableNextColumn(); UI::PushFont(UI::fontMono); ImGui::TextUnformatted(KeyName(cfg().vk[i]).c_str()); UI::PopFont(); ImGui::TableNextColumn(); ImGui::TextUnformatted(kActNames[i]); }
            ImGui::EndTable(); }
        Desc("Game hotkeys can be changed on the Settings page.");
        EndCard();
    }
    if (Card("h_fix", "Troubleshooting", nullptr)) {
        if (ImGui::CollapsingHeader("The status pill never turns green")) Desc("Start the game and load a single-player save. In the external window, press Inject / Connect on the Dashboard. If it still fails, check the Console page for the last error.");
        if (ImGui::CollapsingHeader("The map is grey or has no countries")) Desc("Open Settings > Map detection and press Detect again. If it still fails, press Write diagnostics and Dump classes to file, then send aoc_map_diag.txt and aoc_class_dump.txt from the game folder.");
        if (ImGui::CollapsingHeader("A value jumps back after I edit it")) Desc("The game recalculates some values every day. Tick Freeze on that value, or use Minimum to keep it from falling.");
        if (ImGui::CollapsingHeader("Everything is blocked")) Desc("The tool refuses changes in multiplayer. It only works in single-player.");
        if (ImGui::CollapsingHeader("The overlay does not appear")) Desc("Press Insert with the game window focused. The overlay needs OpenGL 3.0 or newer; the log aoc_trainer_dll.log in the game folder says what failed.");
        EndCard();
    }
    if (Card("h_log", "Version and changelog", nullptr)) {
        ImGui::Text("Version 2.1");
        ImGui::BulletText("New Chartroom look: custom fonts, header, status bar and sidebar.");
        ImGui::BulletText("Command palette, quick-action bar and pinned countries.");
        ImGui::BulletText("New pages: Rankings, Compare, Diagnostics and Help.");
        ImGui::BulletText("Map detection checks every candidate grid and rejects land masks.");
        Desc("Everything was tested against a simulated game. It has not been run against the real game here.");
        EndCard();
    }
}
