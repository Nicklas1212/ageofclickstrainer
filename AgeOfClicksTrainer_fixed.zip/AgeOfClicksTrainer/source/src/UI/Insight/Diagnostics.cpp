#include <algorithm>
#include "Map/MapData.h"
#include "UI/Common.h"
#include "UI/Tabs.h"

namespace {
enum class S { Yes, Experimental, No, Waiting };
struct Feat { const char* name; S st; std::string why; };
void StatusCell(S s) { switch (s) { case S::Yes: UI::Pill("Supported", kGood); break; case S::Experimental: UI::Pill("Experimental", kWarn); break; case S::Waiting: UI::Pill("Waiting", kDim); break; default: UI::Pill("Not available", kBad); } }
}

void DrawDiagnostics() {
    Link& L = link(); GameState& G = state(); ImGuiIO& io = ImGui::GetIO(); bool ok = G.Ready();
    static std::vector<float> fps; static double next = 0; static uint64_t lastSerial = 0; static double rate = 0, rateT = 0; double now = ImGui::GetTime();
    if (now > next) { next = now + 0.25; fps.push_back(io.Framerate); if (fps.size() > 240) fps.erase(fps.begin()); }
    if (now - rateT > 2.0) { uint64_t s = L.StatusSerial(); rate = rateT > 0 ? (s - lastSerial) / (now - rateT) : 0; lastSerial = s; rateT = now; }
    if (Card("d_conn", "Connection", nullptr)) {
        UI::Pill(L.connected ? "Bridge connected" : "Bridge not connected", L.connected ? kGood : kBad); ImGui::SameLine(); UI::Pill(L.multiplayer ? "Multiplayer detected" : "Single-player", L.multiplayer ? kBad : kGood); ImGui::SameLine(); UI::Pill(ok ? "Game ready" : "Game not ready", ok ? kGood : kWarn);
        ImGui::TextWrapped("%s", L.StateMessage().c_str()); Desc(host().overlay ? "Running inside the game (overlay)." : "Running as the external window.");
        EndCard();
    }
    bool mapReady = MapData::GetStage() == MapData::Stage::Ready;
    std::vector<Feat> f = {
        {"Live stats, graphs and rankings", ok ? S::Yes : S::Waiting, ok ? "" : "Start or load a single-player game."},
        {"Click-to-edit values (set, add, multiply, freeze)", ok ? S::Yes : S::Waiting, ok ? "Works on every numeric field the game exposes." : "Needs a running single-player game."},
        {"Economy, population, military, resources editing", ok ? S::Yes : S::Waiting, ok ? "Some values are recalculated by the game each day; use Freeze if one snaps back." : "Needs a running single-player game."},
        {"Economy Planner (target economy to upgrades)", ok ? S::Experimental : S::Waiting, "Costs come from the game; the result depends on its upgrade rules."},
        {"Undo and redo", ok ? S::Yes : S::Waiting, "Covers value edits. Territory owner changes are not covered."},
        {"World map display", mapReady ? S::Yes : MapData::GetStage() == MapData::Stage::Failed ? S::No : S::Waiting, mapReady ? Fmt("%d%% of land matched to countries via %s.", MapData::Coverage(), MapData::Extractor().c_str()) : MapData::Message()},
        {"Territory owner editing on the map", mapReady && MapData::Writable() ? S::Experimental : S::No, mapReady && MapData::Writable() ? "Writes the map grid. The game may redraw only after a reload." : "Needs a detected, writable map grid."},
        {"In-game overlay (Insert)", host().overlay ? S::Yes : S::No, host().overlay ? "" : "This is the external window. Inject the helper to use the overlay."},
        {"Global hotkeys", host().hotkeysActive ? S::Yes : S::Waiting, host().hotkeysActive ? "" : "Another window has the focus."},
        {"Command palette and quick actions", S::Yes, "Ctrl+K opens the palette."}};
    if (Card("d_feat", "Feature detection", "What works in this session right now. Anything marked Not available is switched off instead of pretending to work.")) {
        if (ImGui::BeginTable("feat", 3, ImGuiTableFlags_RowBg | ImGuiTableFlags_SizingStretchProp)) {
            ImGui::TableSetupColumn("Feature", 0, 3); ImGui::TableSetupColumn("Status", ImGuiTableColumnFlags_WidthFixed, ImGui::GetFontSize() * 9); ImGui::TableSetupColumn("Detail", 0, 4);
            for (auto& x : f) { ImGui::TableNextRow(); ImGui::TableNextColumn(); ImGui::TextUnformatted(x.name); ImGui::TableNextColumn(); StatusCell(x.st); ImGui::TableNextColumn(); ImGui::TextWrapped("%s", x.why.c_str()); }
            ImGui::EndTable(); }
        EndCard();
    }
    if (Card("d_todo", "Not built yet", "These ideas are not in this version. They are listed here so nothing looks available that is not.")) {
        const char* todo[] = {"Scenario manager (custom starting scenarios)", "Technology tree viewer with prerequisites", "Drag-and-drop dashboard widgets", "Docking and saved window layouts", "Data export and import (CSV and JSON)",
            "Map markers, camera bookmarks and distance measuring", "Individual army unit editor and production queues", "Custom theme editor (accent colours)", "Threshold monitors for any value (resource alerts exist on the Automation page)"};
        for (auto t : todo) ImGui::BulletText("%s", t);
        EndCard();
    }
    if (Card("d_perf", "Performance", nullptr)) {
        UI::PushFont(UI::fontMono); ImGui::Text("%.0f fps   %.2f ms/frame   status updates %.1f/s", io.Framerate, io.Framerate > 0 ? 1000.0f / io.Framerate : 0.0f, rate); UI::PopFont();
        UI::LineGraph("##fps", fps, ImVec2(-1, 70), " fps"); Desc("Memory use is not shown: the game does not expose it to this tool.");
        EndCard();
    }
}
