#include <algorithm>
#include <cmath>
#include <map>
#include "UI/Common.h"
#include "UI/Tabs.h"

// ---- the old hard-coded detail cards (deposits / base production) are kept below the dynamic list
static void LegacyResourceCards() {
    if (Card("r1", "Global resource tools", "Act on ALL resources at once (raw materials, industrial goods, consumer goods and manpower).")) {
        Desc("Gain multiplier: every increase of any resource is multiplied while active (production, trade, captures).");
        for (double m : {2.0, 5.0, 10.0, 100.0}) { ImGui::SameLine(0, 6); std::string l = Fmt("x%g##rm", m); if (ImGui::Button(l.c_str())) Cmd(Fmt("gainmult resources %g", m)); }
        ImGui::SameLine(); if (ImGui::Button("Off##rm")) Cmd("gainmult resources 1");
        Button("Infinite resources", "Keeps every resource at 9 trillion or more.", "preset infinite_economy"); ImGui::SameLine();
        Button("Release all locks", "Removes every freeze / infinite / gain-multiplier lock.", "unlock all");
        static char amt[64] = "1m"; ImGui::SetNextItemWidth(120); ImGui::InputText("##amt", amt, 64); ImGui::SameLine();
        if (ImGui::Button("Instant resource generation")) { for (auto k : {"iron","coal","oil","timber","rubber","aluminum","uranium","copper","steel","fuel","ammo","mechParts","electronics","trucks","consumerGoods","manpower"}) Cmd(Fmt("add country %s %s", k, amt)); }
        if (ImGui::IsItemHovered()) ImGui::SetTooltip("Adds the typed amount to every resource right now.");
        Desc("'Freeze resources' = use the Freeze box on a single row below, or 'Release all locks' to undo.");
    } EndCard();
    if (Card("r4", "Resource deposits", "How rich your territory is in each resource. These fractions scale your raw-material output.", "experimental")) {
        for (auto p : std::vector<std::pair<const char*, const char*>>{{"Iron richness", "ironFrac"}, {"Coal richness", "coalFrac"}, {"Oil richness", "oilFrac"}, {"Timber richness", "timberFrac"}, {"Rubber richness", "rubberFrac"}, {"Aluminum richness", "aluminumFrac"}, {"Uranium richness", "uraniumFrac"}, {"Copper richness", "copperFrac"}})
            EditRow({p.first, p.second, "country", "Deposit share used by the game to compute this resource's output. The game may recalculate it."});
        Button("Recalculate production now", "Asks the game to refresh its resource multipliers immediately.", "recalc");
    } EndCard();
    if (Card("r5", "Resource base production", "Raw production per day before upgrades. The game recalculates it periodically - freeze to keep your number.")) {
        for (auto p : std::vector<std::pair<const char*, const char*>>{{"Iron", "baseIronIncome"}, {"Coal", "baseCoalIncome"}, {"Oil", "baseOilIncome"}, {"Timber", "baseTimberIncome"}, {"Rubber", "baseRubberIncome"}, {"Aluminum", "baseAluminumIncome"}, {"Uranium", "baseUraniumIncome"}, {"Copper", "baseCopperIncome"}, {"Manpower", "baseManpowerIncome"}})
            EditRow({p.first, p.second, "country", "Base daily production of this resource."});
    } EndCard();
}

namespace {
struct ResRow { std::string name, key, kind; double amount = 0, gross = NAN, delta = NAN; };
std::vector<ResRow> Rows() {
    Poll("resources", "resources", 1.0); Poll("rates", "rates", 2.0); std::vector<ResRow> out;
    for (auto& r : Split(link().Payload("resources"), '\x1e')) { auto c = Split(r, '\x1f'); if (c.size() < 4) continue; ResRow x; x.name = c[0]; x.key = c[1]; x.amount = atof(c[2].c_str()); x.kind = c[3]; out.push_back(x); }
    for (auto& r : Split(link().Payload("rates"), '\x1e')) { auto c = Split(r, '\x1f'); if (c.size() < 3) continue; for (auto& x : out) if (x.key == c[0]) { if (!c[1].empty() && c[1] != "null") x.gross = atof(c[1].c_str()); if (!c[2].empty() && c[2] != "null") x.delta = atof(c[2].c_str()); } }
    return out;
}
std::string Pretty(std::string s) { for (auto& c : s) if (c == '_') c = ' '; bool up = true; for (auto& c : s) { if (up && isalpha((unsigned char)c)) { c = (char)toupper(c); up = false; } if (c == ' ') up = true; } return s; }
void ResourceEdit(const ResRow& r) {
    std::string id = "rv_" + r.key; ImGui::PushID(r.key.c_str());
    ImGui::TextColored(kGood, "%s", Human(r.amount).c_str()); bool hov = ImGui::IsItemHovered(); ImVec2 a = ImGui::GetItemRectMin(), b = ImGui::GetItemRectMax();
    if (hov) { ImGui::SetMouseCursor(ImGuiMouseCursor_Hand); ImGui::GetWindowDrawList()->AddLine(ImVec2(a.x, b.y), ImVec2(b.x, b.y), ImGui::GetColorU32(kGood)); ImGui::SetTooltip("Click to edit %s (exact: %.0f)", r.name.c_str(), r.amount); if (ImGui::IsMouseClicked(0)) ImGui::OpenPopup("##re"); }
    if (ImGui::BeginPopup("##re")) {
        UI::Heading(("Edit: " + Pretty(r.name)).c_str()); ImGui::Text("Current: %s", Grouped(r.amount).c_str()); if (ImGui::IsWindowAppearing()) ImGui::SetKeyboardFocusHere();
        ImGui::SetNextItemWidth(-1); bool en = ImGui::InputTextWithHint("##v", "5m, 20k, 3b ...", Buf(id), 64, ImGuiInputTextFlags_EnterReturnsTrue); std::string v = BufStr(id); bool can = !v.empty();
        ImGui::BeginDisabled(!can);
        if (ImGui::Button("Set") || (en && can)) Cmd("rset " + r.key + " set " + v); ImGui::SameLine(); if (ImGui::Button("Add")) Cmd("rset " + r.key + " add " + v);
        ImGui::SameLine(); if (ImGui::Button("Subtract")) Cmd("rset " + r.key + " add -" + v);
        ImGui::SameLine(); if (ImGui::Button("Multiply")) { char* e = nullptr; double f = strtod(v.c_str(), &e); if (e && *e == 0) Cmd(Fmt("rset %s set %.0f", r.key.c_str(), r.amount * f)); else Notify::Push(NoteType::Error, "Type a plain factor like 2 or 0.5 for Multiply."); }
        ImGui::EndDisabled();
        std::string lk = "country." + r.key; bool known = false; for (int i = 0; i < kResCount; i++) if (r.key == kResKeys[i]) known = true;
        if (known) { bool l = IsLocked(lk); if (ImGui::Checkbox("Freeze", &l)) Game::Freeze("country", r.key, l); ImGui::SameLine(); if (ImGui::Button("Infinite")) Game::Floor("country", r.key, "9t"); ImGui::SameLine(); if (ImGui::Button("Reset")) Game::Reset("country", r.key); }
        else Desc("Freeze / Reset are not available for this resource.");
        ImGui::EndPopup(); }
    ImGui::PopID();
}
}

void DrawResources() {
    auto rows = Rows(); static std::string flt; static bool hideZero = false;
    if (Card("rdyn", "Resources", "The list comes straight from the game, so it always matches your version (including any custom resources). Click an amount to edit it.")) {
        UI::Search("##rf", flt, "filter resources...", 220); ImGui::SameLine(); ImGui::Checkbox("Hide empty", &hideZero);
        if (rows.empty()) Desc(link().TagError("resources").empty() ? "Loading the resource list..." : link().TagError("resources").c_str());
        if (ImGui::BeginTable("res", 6, ImGuiTableFlags_RowBg | ImGuiTableFlags_ScrollY | ImGuiTableFlags_SizingStretchProp | ImGuiTableFlags_Sortable, ImVec2(0, 360))) {
            ImGui::TableSetupColumn("Resource", 0, 2.5f); ImGui::TableSetupColumn("Amount", 0, 1.5f); ImGui::TableSetupColumn("Production per day", 0, 1.5f); ImGui::TableSetupColumn("Net per day", 0, 1.5f); ImGui::TableSetupColumn("Source", 0, 0.8f); ImGui::TableSetupColumn("Quick", ImGuiTableColumnFlags_NoSort, 1.6f); ImGui::TableSetupScrollFreeze(0, 1); ImGui::TableHeadersRow();
            if (ImGuiTableSortSpecs* sp = ImGui::TableGetSortSpecs()) if (sp->SpecsCount > 0) { int col = sp->Specs[0].ColumnIndex; bool asc = sp->Specs[0].SortDirection == ImGuiSortDirection_Ascending;
                std::stable_sort(rows.begin(), rows.end(), [&](const ResRow& a, const ResRow& b) { if (col == 0) return asc ? a.name < b.name : a.name > b.name; double x = col == 1 ? a.amount : col == 2 ? a.gross : a.delta, y = col == 1 ? b.amount : col == 2 ? b.gross : b.delta; if (std::isnan(x)) x = -1e300; if (std::isnan(y)) y = -1e300; return asc ? x < y : x > y; }); }
            for (auto& r : rows) { if (!flt.empty() && !ContainsNoCase(r.name, flt) && !ContainsNoCase(r.key, flt)) continue; if (hideZero && r.amount == 0) continue;
                ImGui::TableNextRow(); ImGui::PushID(r.key.c_str()); ImGui::TableNextColumn(); ImGui::TextUnformatted(Pretty(r.name).c_str()); ImGui::TableNextColumn(); ResourceEdit(r);
                ImGui::TableNextColumn(); if (std::isnan(r.gross)) ImGui::TextDisabled("n/a"); else ImGui::Text("%s", Human(r.gross).c_str());
                ImGui::TableNextColumn(); if (std::isnan(r.delta)) ImGui::TextDisabled("n/a"); else ImGui::TextColored(r.delta >= 0 ? kGood : kBad, "%s%s", r.delta > 0 ? "+" : "", Human(r.delta).c_str());
                ImGui::TableNextColumn(); ImGui::TextDisabled("%s", r.kind.c_str()); ImGui::TableNextColumn();
                if (ImGui::SmallButton("+1m")) Cmd("rset " + r.key + " add 1m"); ImGui::SameLine(); if (ImGui::SmallButton("x2")) Cmd(Fmt("rset %s set %.0f", r.key.c_str(), r.amount * 2)); ImGui::SameLine(); if (ImGui::SmallButton("0")) Cmd("rset " + r.key + " set 0"); ImGui::PopID(); }
            ImGui::EndTable(); }
        Desc("'Production per day' and 'Net per day' come from the game's own resource ledger. 'n/a' means the game does not report a flow for that resource.");
        EndCard();
    }
    if (ImGui::CollapsingHeader("Deposits, base production and global tools")) LegacyResourceCards();
}
