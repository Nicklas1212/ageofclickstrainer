#include <algorithm>
#include "Map/MapData.h"
#include "Map/MapView.h"
#include "UI/Common.h"
#include "UI/Tabs.h"
#include "UI/App.h"

#include "TerrLegacy.inc"

void DrawTerritory() {
    const MapView::Focus& f = MapView::GetFocus();
    if (Card("te0", "Territory editor", "Right-click a territory on the Map and choose 'Edit Territory' to work on it here.", "experimental")) {
        if (MapData::GetStage() != MapData::Stage::Ready) { Desc(MapData::Message().c_str()); if (ImGui::Button("Open the map")) App::GoTo(T_MAP); }
        else if (!f.valid) { Desc("No territory chosen yet."); if (ImGui::Button("Open the map")) App::GoTo(T_MAP); }
        else {
            const CountryRow* o = f.owner >= 0 && f.owner < (int)state().Countries().size() ? &state().Countries()[f.owner] : nullptr;
            ImGui::Text("Owner: %s", o ? o->name.c_str() : "nobody"); ImGui::Text("Cell: %d, %d     Region size: ~%s cells%s", f.sx, f.sy, Human((double)f.cells).c_str(), f.countryShare > 0 ? Fmt("   (%.1f%% of the country)", f.countryShare).c_str() : "");
            if (o) { ImGui::Text("Owner population %s   money %s   military %s", Human(o->pop).c_str(), Human(o->gold).c_str(), Human(o->strength).c_str()); }
            if (ImGui::Button("Center camera")) { App::GoTo(T_MAP); MapView::CenterOnFocus(); } ImGui::SameLine(); if (o && ImGui::Button("Inspect owner")) { state().Select(o->name, false); App::GoTo(T_COUNTRIES); }
            ImGui::Separator(); UI::Heading("Change owner");
            if (!MapData::Writable()) Desc("The detected map grid is read-only, so ownership cannot be changed.");
            else {
                static std::string flt; UI::Search("##tof", flt, "find new owner...", 240); ImGui::BeginChild("towner", ImVec2(0, 200), ImGuiChildFlags_Borders);
                for (auto& n : MapData::CountryNames()) { if (!flt.empty() && !ContainsNoCase(n, flt)) continue; if (ImGui::Selectable(n.c_str())) MapView::RequestChangeOwner(n); }
                ImGui::EndChild(); Desc("Experimental: the whole connected area is reassigned. You will be asked to confirm. The standard Undo does not cover map changes.");
            }
        }
        EndCard();
    }
    MapView::DrawDialogs();
    LegacyTerritory();
}
