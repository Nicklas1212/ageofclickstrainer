#include <algorithm>
#include <cmath>
#include <cstring>
#include <vector>
#include "UI/Common.h"
#include "UI/Tabs.h"
#include "UI/App.h"

void DrawMilitary() {
    if (Card("m1", "Army size & equipment", "Your armed forces and stockpiles. Units are counted per category; the game derives your strength from them.")) {
        EditRow({"Manpower (recruits)", "manpower", "country", "Available recruits. Raising it lets you recruit instantly."});
        EditRow({"Infantry", "infantry", "country", "Infantry divisions/units in your army."}); EditRow({"Artillery", "artillery", "country", "Artillery pieces."}); EditRow({"Tanks", "tanks", "country", "Armored vehicles."});
        EditRow({"Aircraft", "aircraft", "country", "Aircraft."}); EditRow({"Ships", "ships", "country", "Naval vessels."}); EditRow({"Nuclear weapons", "nuclearWeapons", "country", "Nuclear warheads available to launch."});
        EditRow({"Ammunition stockpile", "ammo", "country", "Ammunition for your army."}); EditRow({"Fuel stockpile", "fuel", "country", "Fuel for vehicles."});
        EditRow({"Military spending (%)", "targetMilitarySpending", "country", "Policy slider for military budget."}, false);
        EditRow({"War economy (%)", "targetWarEconomy", "country", "Policy slider converting the economy to war production."}, false);
    } EndCard();
    if (Card("m2", "Field units (organization & readiness)", "The actual units on the map. Heal restores strength, organization and supply of your units.")) {
        ImGui::Text("Army strength rating: %s", Val("calculateTotalStrength").c_str());
        Button("Restore all my units now", "Sets strength to max and refills organization/supply on all of your map units.", "units heal", ImVec2(220, 0));
        FlagToggle("Freeze army losses (invincible units)", "godunits", "Every 40 ms your units are restored to full strength, organization and supply - they can't die or break.", "experimental");
    } EndCard();
    if (Card("m3", "Military technology", nullptr)) {
        Button("Unlock all military technology", "Researches every technology on the military branch (and prerequisites).", "techs military"); ImGui::SameLine();
        Button("Unlock ALL technology", "Researches everything.", "techs all");
        Button("Max military buildings", "Sets all buildings to max level (includes barracks and factories).", "maxbuildings");
    } EndCard();
    if (Card("m4", "Not available in this game", nullptr)) {
        NotMapped("Instant deployment", "units are placed with the game's own map tools.");
        NotMapped("Edit individual army values", "the unit list below shows each unit's values; changes are made through 'Restore'.");
    } EndCard();
    Poll("units list", "units", 2.0);
    std::string raw = link().Payload("units");
    if (!raw.empty() && Card("m5", "Your units", nullptr)) {
        if (ImGui::BeginTable("ul", 5, ImGuiTableFlags_RowBg | ImGuiTableFlags_ScrollY, ImVec2(0, 220))) {
            ImGui::TableSetupColumn("Unit"); ImGui::TableSetupColumn("Strength"); ImGui::TableSetupColumn("Max"); ImGui::TableSetupColumn("Organization"); ImGui::TableSetupColumn("Supply"); ImGui::TableHeadersRow();
            for (auto& r : Split(raw, '\x1e')) { auto c = Split(r, '\x1f'); if (c.size() < 5) continue; ImGui::TableNextRow(); for (int i = 0; i < 5; i++) { ImGui::TableNextColumn(); ImGui::TextUnformatted(c[i].c_str()); } }
            ImGui::EndTable(); }
    } if (!raw.empty()) EndCard();
}
