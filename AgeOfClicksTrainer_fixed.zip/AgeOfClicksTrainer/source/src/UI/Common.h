// Shared widgets and styling for every tab. All text is English.
#pragma once
#include <string>
#include <map>
#include <vector>
#include "imgui.h"
#include "Core/Config.h"
#include "Core/Host.h"
#include "Core/Link.h"
#include "Core/Util.h"
#include "Game/GameApi.h"
#include "GameState/GameState.h"
#include "GameState/Resources.h"
#include "Notifications/Notifications.h"

inline ImVec4 kDim(0.62f, 0.66f, 0.72f, 1), kAccent(0.30f, 0.62f, 1.0f, 1), kGood(0.35f, 0.85f, 0.5f, 1), kBad(0.95f, 0.38f, 0.38f, 1), kWarn(1.0f, 0.75f, 0.30f, 1);

inline bool g_testForcePopups = false;   // test hook: makes click-to-edit popups open on their own

namespace UI {
extern const char* kThemeNames[5];
extern ImFont *fontBody, *fontHead, *fontMono, *fontBig;   // null when the system fonts are missing: the default font is used
void LoadFonts(ImGuiIO& io);                         // call before the font atlas is built
void PushFont(ImFont* f); void PopFont();            // safe with null fonts
void Pill(const char* text, ImVec4 col);             // small rounded status label drawn inline
void Bar(float frac, ImVec2 size, ImVec4 col);       // flat horizontal bar, frac 0..1
bool StatTile(const char* id, const char* label, const std::string& shown, const std::string& field, const std::string& note, ImVec4 noteCol, const std::vector<float>* spark, float width);   // big mono number, click to edit
bool IsFav(const std::string& country); void ToggleFav(const std::string& country);   // pinned countries (saved in settings)
bool Fuzzy(const std::string& hay, const std::string& needle, int* score = nullptr);   // subsequence match used by the palette
void ApplyTheme();                                   // colours + UI scale from the settings
ImU32 Rgb(uint32_t rgb, float alpha = 1.0f);         // 0xRRGGBB -> ImU32
bool NeedGame();                                     // draws a hint and returns true when no usable single-player game is attached
void Tip(const char* text);                          // tooltip for the previous item
bool Search(const char* id, std::string& text, const char* hint, float width = 220);
void LineGraph(const char* id, const std::vector<float>& v, ImVec2 size, const char* unit = "");
void Heading(const char* text);
}

void Desc(const char* t);
void Badge(const char* t, ImVec4 c);
bool Card(const char* id, const char* title, const char* desc, const char* badge = nullptr);
void EndCard();
char* Buf(const std::string& id, const char* def = "");
std::string BufStr(const std::string& id);

// Click-to-edit: draws `shown` as a clickable value. Clicking it opens a popup with Set / Add / Subtract /
// Multiply / Freeze / Infinite / Reset for target.field (target is "country" or "c:Country_Name").
bool ClickValue(const char* id, const std::string& target, const std::string& field, const std::string& shown, const char* label, ImVec4 col = kGood);

struct Stat { const char* label; const char* field; const char* target; const char* desc; };
void EditRowT(const std::string& label, const std::string& field, const std::string& target, const std::string& desc, bool locks = true, const std::string& shown = "");
void EditRow(const Stat& s, bool locks = true);
void Button(const char* label, const char* tip, const std::string& cmd, ImVec2 sz = ImVec2(0, 0));
bool FlagToggle(const char* label, const char* flag, const char* desc, const char* badge = nullptr);
bool LockToggle(const char* label, const char* key, const char* mode, const char* val, const char* desc);
void NotMapped(const char* what, const char* why);
