#include "UI/Common.h"
#include "UI/Tabs.h"

void DrawEvents() {
    static std::string flt; static int type = 0;
    if (Card("ev", "Event feed", "Things that happened in your game (government changes, epidemics, rebellions, research, alerts) as seen by this tool. Alerts can be set up on the Automation page.")) {
        UI::Search("##ef", flt, "search events...", 240); ImGui::SameLine(); ImGui::SetNextItemWidth(140); ImGui::Combo("##et", &type, "All types\0Info\0Success\0Warning\0Error\0"); 
        ImGui::BeginChild("evlist", ImVec2(0, 300), ImGuiChildFlags_Borders);
        int n = 0; for (auto& e : state().Events()) { if (type && (int)e.type != type - 1) continue; if (!flt.empty() && !ContainsNoCase(e.text, flt)) continue; n++;
            ImVec4 c = e.type == NoteType::Error ? kBad : e.type == NoteType::Warning ? kWarn : e.type == NoteType::Success ? kGood : kAccent; ImGui::TextDisabled("%s", e.time.c_str()); ImGui::SameLine(); ImGui::TextColored(c, "%s", Notify::TypeName(e.type)); ImGui::SameLine(); ImGui::TextWrapped("%s", e.text.c_str()); }
        if (!n) Desc("Nothing yet. Events appear here as the game changes.");
        ImGui::EndChild(); EndCard();
    }
    if (Card("nh", "Notification history", "Every message this tool has shown, including ones hidden by your notification settings.")) {
        if (ImGui::Button("Clear history")) Notify::ClearHistory();
        ImGui::BeginChild("nhl", ImVec2(0, 260), ImGuiChildFlags_Borders); auto h = Notify::History();
        for (int i = (int)h.size() - 1; i >= 0; i--) { ImVec4 c = h[i].type == NoteType::Error ? kBad : h[i].type == NoteType::Warning ? kWarn : h[i].type == NoteType::Success ? kGood : kAccent; ImGui::TextDisabled("%s", h[i].time.c_str()); ImGui::SameLine(); ImGui::TextColored(c, "%s", Notify::TypeName(h[i].type)); ImGui::SameLine(); ImGui::TextWrapped("%s", h[i].text.c_str()); }
        ImGui::EndChild(); EndCard();
    }
}
