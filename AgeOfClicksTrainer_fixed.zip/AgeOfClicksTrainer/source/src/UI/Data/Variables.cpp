#include <map>
#include <set>
#include "UI/Common.h"
#include "UI/Tabs.h"

namespace {
struct Row { std::string seg, type, preview; bool leaf, editable, hasOrig; };
std::map<std::string, double> g_next; std::set<std::string> g_open; std::string g_editPath;
std::vector<Row> Children(const std::string& path) {
    double now = state().Now(); double& n = g_next[path]; std::string tag = "vx:" + path;
    if (now >= n) { n = now + 1.5; link().Submit("vx " + path, tag); }
    std::vector<Row> out; for (auto& r : Split(link().Payload(tag), '\x1e')) { auto c = Split(r, '\x1f'); if (c.size() < 6) continue; out.push_back({c[0], c[1], c[2], c[3] == "L", c[4] == "1", c[5] == "1"}); } return out;
}
void DrawValue(const std::string& path, const Row& r) {
    ImGui::PushID(path.c_str());
    ImGui::TextColored(r.editable ? kGood : kDim, "%s", r.preview.c_str()); bool hov = ImGui::IsItemHovered();
    if (hov && r.editable) { ImGui::SetMouseCursor(ImGuiMouseCursor_Hand); ImGui::SetTooltip("Click to edit"); if (ImGui::IsMouseClicked(0)) { ImGui::OpenPopup("##ve"); g_editPath = path; } }
    else if (hov && !r.editable) ImGui::SetTooltip("Read-only value");
    if (ImGui::BeginPopup("##ve")) {
        UI::Heading(r.seg.c_str()); ImGui::TextDisabled("%s", path.c_str()); ImGui::Text("Type: %s   Current: %s", r.type.c_str(), r.preview.c_str());
        std::string bid = "vxe_" + path; if (ImGui::IsWindowAppearing()) ImGui::SetKeyboardFocusHere(); ImGui::SetNextItemWidth(-1);
        static std::map<std::string, std::string> buf; std::string& b = buf[bid]; if (b.empty()) b = r.preview; b.resize(std::max<size_t>(b.size(), 128)); bool en = ImGui::InputText("##v", b.data(), 127, ImGuiInputTextFlags_EnterReturnsTrue);
        std::string v = b.c_str();
        if (ImGui::Button("Set") || en) { Cmd("vxset " + path + " " + v); link().ClearTag("vx:" + path.substr(0, path.rfind('/') == std::string::npos ? 0 : path.rfind('/'))); ImGui::CloseCurrentPopup(); }
        ImGui::SameLine(); ImGui::BeginDisabled(!r.hasOrig); if (ImGui::Button("Reset to original")) { Cmd("vxreset " + path); ImGui::CloseCurrentPopup(); } ImGui::EndDisabled(); UI::Tip("Restores the value this tool first saw for this variable.");
        ImGui::SameLine(); if (ImGui::Button("Close")) ImGui::CloseCurrentPopup(); ImGui::EndPopup(); }
    ImGui::PopID();
}
void Node(const std::string& path, int depth, const std::string& filter) {
    for (auto& r : Children(path)) {
        std::string p = path.empty() ? r.seg : path + "/" + r.seg; if (!filter.empty() && r.leaf && !ContainsNoCase(r.seg, filter) && !ContainsNoCase(r.preview, filter)) continue;
        ImGui::PushID(p.c_str());
        if (!r.leaf) {
            bool open = ImGui::TreeNodeEx(r.seg.c_str(), ImGuiTreeNodeFlags_SpanAvailWidth | (depth == 0 ? 0 : 0)); ImGui::SameLine(ImGui::GetContentRegionAvail().x > 520 ? ImGui::GetFontSize() * 20 : 0); ImGui::TextDisabled("%s  %s", r.type.c_str(), r.preview.c_str());
            if (open) { if (depth < 14) Node(p, depth + 1, filter); ImGui::TreePop(); }
        } else {
            ImGui::AlignTextToFramePadding(); ImGui::Bullet(); ImGui::TextUnformatted(r.seg.c_str()); ImGui::SameLine(ImGui::GetFontSize() * 18); ImGui::TextDisabled("%s", r.type.c_str()); ImGui::SameLine(ImGui::GetFontSize() * 25); DrawValue(p, r);
            ImGui::SameLine(ImGui::GetFontSize() * 40); ImGui::TextDisabled("%s", r.editable ? "editable" : "read-only"); if (r.hasOrig) { ImGui::SameLine(); if (ImGui::SmallButton("Reset")) Cmd("vxreset " + p); }
        }
        ImGui::PopID();
    }
}
}

void DrawVariables() {
    static std::string flt, find; static bool searching = false;
    if (Card("vx", "Variable Explorer", "Browse the game's live objects. Expand a node to load its children; click a value to edit it. Edits are remembered so they can be reset. Careful: these are the game's raw internals.", "experimental")) {
        UI::Search("##vf", flt, "filter visible rows...", 240); ImGui::SameLine(); UI::Search("##vfind", find, "deep search by name...", 240); ImGui::SameLine();
        if (ImGui::Button("Search") && !find.empty()) { link().ClearTag("vxfind"); link().Submit("vxfind " + find, "vxfind"); searching = true; }
        UI::Tip("Searches the whole object graph (bounded) for variable names or exact values.");
        if (searching) { std::string raw = link().Payload("vxfind"); ImGui::SameLine(); if (ImGui::SmallButton("Close results")) searching = false;
            ImGui::BeginChild("vxres", ImVec2(0, 160), ImGuiChildFlags_Borders); if (!link().TagError("vxfind").empty()) Desc(link().TagError("vxfind").c_str());
            for (auto& r : Split(raw, '\x1e')) { auto c = Split(r, '\x1f'); if (c.size() < 6) continue; Row row{c[0].substr(c[0].rfind('/') == std::string::npos ? 0 : c[0].rfind('/') + 1), c[1], c[2], c[3] == "L", c[4] == "1", false}; ImGui::PushID(c[0].c_str());
                ImGui::TextUnformatted(c[0].c_str()); ImGui::SameLine(); ImGui::TextDisabled("%s", c[1].c_str()); ImGui::SameLine(); if (row.leaf) DrawValue(c[0], row); else ImGui::TextDisabled("%s", c[2].c_str()); ImGui::PopID(); }
            ImGui::EndChild(); }
        ImGui::BeginChild("vxtree", ImVec2(0, 0), ImGuiChildFlags_Borders); Node("", 0, flt); ImGui::EndChild();
        EndCard();
    }
}
