#include "UI/Common.h"
#include "UI/Tabs.h"

void DrawHistory() {
    Poll("history", "history", 0.8);
    if (Card("hi", "Change history", "Every change made through this tool, with the value before and after. Undo and Redo step through it; the game keeps the last 40 steps.")) {
        if (ImGui::Button("Undo")) Cmd("undo"); ImGui::SameLine(); if (ImGui::Button("Redo")) Cmd("redo"); ImGui::SameLine(); if (ImGui::Button("Clear history")) Cmd("histclear"); UI::Tip("Clears this list and the undo steps. Values stay as they are.");
        ImGui::SameLine(); ImGui::TextDisabled("Undo steps: %s", link().Get("undo").c_str());
        std::string raw = link().Payload("history");
        if (ImGui::BeginTable("hist", 4, ImGuiTableFlags_RowBg | ImGuiTableFlags_ScrollY | ImGuiTableFlags_SizingStretchProp, ImVec2(0, 440))) {
            ImGui::TableSetupColumn("Time", 0, 0.8f); ImGui::TableSetupColumn("Action", 0, 2.f); ImGui::TableSetupColumn("Before \xE2\x86\x92 after", 0, 3.f); ImGui::TableSetupColumn("State", 0, 0.8f); ImGui::TableSetupScrollFreeze(0, 1); ImGui::TableHeadersRow();
            auto rows = Split(raw, '\x1e'); for (size_t i = 0; i < rows.size(); i++) { auto c = Split(rows[i], '\x1f'); if (c.size() < 4) continue; bool undone = c[3] == "undone"; ImGui::TableNextRow();
                ImGui::TableNextColumn(); ImGui::TextDisabled("%s", c[0].c_str()); ImGui::TableNextColumn(); ImGui::TextColored(undone ? kDim : ImGui::GetStyleColorVec4(ImGuiCol_Text), "%s", c[1].c_str());
                ImGui::TableNextColumn(); ImGui::TextWrapped("%s", c[2].c_str()); ImGui::TableNextColumn(); ImGui::TextColored(undone ? kWarn : kGood, "%s", undone ? "undone" : "applied"); }
            ImGui::EndTable(); }
        if (raw.empty()) Desc("No changes recorded yet."); EndCard();
    }
}
