#include <windows.h>
#include <shellapi.h>
#include <zlib.h>
#include <algorithm>
#include <filesystem>
#include <fstream>
#include <set>
#include <sstream>
#include "Core/Json.h"
#include "UI/Common.h"
#include "UI/Tabs.h"
namespace fs = std::filesystem;

static std::vector<fs::path> FindSaveDirs() {
    std::vector<fs::path> roots; auto add = [&](const char* env, const char* sub = "") { const char* e = getenv(env); if (e) roots.push_back(fs::path(e) / sub); };
    std::string gd = host().gameDir ? host().gameDir() : std::string(); if (!gd.empty()) { fs::path d = fs::path(gd); roots.push_back(d); roots.push_back(d.parent_path()); }
    add("APPDATA"); add("LOCALAPPDATA"); add("USERPROFILE", ".prefs"); add("USERPROFILE", "Documents"); add("USERPROFILE", "Saved Games"); add("USERPROFILE", "AppData\\LocalLow"); add("USERPROFILE");
    std::vector<std::pair<fs::file_time_type, fs::path>> hits; std::set<std::string> seen;
    for (auto& r : roots) { std::error_code ec; if (!fs::exists(r, ec)) continue; int budget = 4000;
        for (fs::recursive_directory_iterator it(r, fs::directory_options::skip_permission_denied, ec), end; it != end && budget > 0; it.increment(ec)) { if (ec) break; budget--;
            if (it.depth() > 3) { it.disable_recursion_pending(); continue; } auto p = it->path(); std::string lp = p.string(); for (auto& c : lp) c = (char)tolower(c);
            if (it->is_directory(ec)) { if (lp.find("windows") != std::string::npos || lp.find("microsoft") != std::string::npos || lp.find("node_modules") != std::string::npos || lp.find("runtime") != std::string::npos) it.disable_recursion_pending(); continue; }
            std::string ext = p.extension().string(); for (auto& c : ext) c = (char)tolower(c);
            bool ext_ok = ext == ".sav" || ext == ".save" || ext == ".json" || ext == ".dat" || ext == ".gz" || ext == ".bin" || ext == ".cgs";
            bool name_ok = lp.find("age of clicks") != std::string::npos || lp.find("ageofclicks") != std::string::npos || lp.find("\\cgs") != std::string::npos || lp.find("/cgs") != std::string::npos || lp.find("save") != std::string::npos;
            if (ext_ok && name_ok && lp.find("backups") == std::string::npos) { std::string d = p.parent_path().string(); if (seen.insert(d).second) hits.push_back({fs::last_write_time(p, ec), p.parent_path()}); } } }
    std::sort(hits.begin(), hits.end(), [](auto& a, auto& b) { return a.first > b.first; }); std::vector<fs::path> out; for (auto& h : hits) out.push_back(h.second); return out;
}
static std::vector<fs::path> g_saveDirs; static std::string g_stateMsg;
static fs::path BackupRoot() { return fs::path(host().baseDir) / "backups"; }
static std::string Stamp() { SYSTEMTIME t; GetLocalTime(&t); return Fmt("%04d%02d%02d_%02d%02d%02d", t.wYear, t.wMonth, t.wDay, t.wHour, t.wMinute, t.wSecond); }

void DrawStates() {
    if (Card("v1", "Live save-states (in memory)", "Snapshots of your country's numbers, research and levels - instantly restorable while the game is running. They are lost when the game closes. For permanent copies use the file backups below.")) {
        for (int i = 1; i <= 5; i++) { ImGui::PushID(i); bool has = link().Has(Fmt("slot%d", i)); ImGui::Text("Slot %d: %s", i, has ? "saved" : "empty"); ImGui::SameLine(120); if (ImGui::SmallButton("Save here")) Cmd(Fmt("snapshot %d", i)); ImGui::SameLine(); ImGui::BeginDisabled(!has); if (ImGui::SmallButton("Restore")) Cmd(Fmt("restore %d", i)); ImGui::EndDisabled(); ImGui::PopID(); }
        Button("Undo last modification", "Reverts the last change made by the trainer.", "undo");
    } EndCard();
    if (Card("v2", "Save-file backups (on disk)", "Copies the game's save folder to a timestamped folder next to the trainer, and restores it later. Close the game (or reload the save) before restoring.")) {
        if (g_saveDirs.empty() && cfg().saveDir.empty()) { g_saveDirs = FindSaveDirs(); if (!g_saveDirs.empty()) cfg().saveDir = g_saveDirs[0].string(); }
        static char dir[512]; static bool init = false; if (!init) { snprintf(dir, sizeof dir, "%s", cfg().saveDir.c_str()); init = true; }
        ImGui::SetNextItemWidth(-190); ImGui::InputText("Save folder", dir, sizeof dir); cfg().saveDir = dir; ImGui::SameLine(); if (ImGui::Button("Auto-detect")) { g_saveDirs = FindSaveDirs(); if (!g_saveDirs.empty()) { snprintf(dir, sizeof dir, "%s", g_saveDirs[0].string().c_str()); cfg().saveDir = dir; g_stateMsg = "Found " + std::to_string(g_saveDirs.size()) + " candidate folder(s)."; } else g_stateMsg = "Nothing found automatically - paste the folder path (File Explorer address bar)."; }
        if (g_saveDirs.size() > 1) { ImGui::TextUnformatted("Other candidates:"); for (size_t i = 1; i < g_saveDirs.size() && i < 6; i++) if (ImGui::SmallButton(g_saveDirs[i].string().c_str())) { snprintf(dir, sizeof dir, "%s", g_saveDirs[i].string().c_str()); cfg().saveDir = dir; } }
        if (ImGui::Button("Create backup now")) { std::error_code ec; fs::path d = BackupRoot() / Stamp(); fs::create_directories(d, ec); fs::copy(cfg().saveDir, d, fs::copy_options::recursive | fs::copy_options::overwrite_existing, ec); g_stateMsg = ec ? "Backup failed: " + ec.message() : "Backup saved to " + d.string(); }
        ImGui::SameLine(); if (ImGui::Button("Open backups folder")) { std::error_code ec; fs::create_directories(BackupRoot(), ec); ShellExecuteW(nullptr, L"open", BackupRoot().wstring().c_str(), nullptr, nullptr, SW_SHOW); }
        if (!g_stateMsg.empty()) Desc(g_stateMsg.c_str());
        std::error_code ec; if (fs::exists(BackupRoot(), ec)) { std::vector<fs::path> bs; for (auto& e : fs::directory_iterator(BackupRoot(), ec)) if (e.is_directory()) bs.push_back(e.path()); std::sort(bs.rbegin(), bs.rend());
            for (auto& b : bs) { ImGui::PushID(b.string().c_str()); ImGui::TextUnformatted(b.filename().string().c_str()); ImGui::SameLine(220); if (ImGui::SmallButton("Restore")) { std::error_code e2; fs::copy(b, cfg().saveDir, fs::copy_options::recursive | fs::copy_options::overwrite_existing, e2); g_stateMsg = e2 ? "Restore failed: " + e2.message() : "Restored " + b.filename().string() + " - reload the save in the game."; }
                ImGui::SameLine(); if (ImGui::SmallButton("Delete")) { std::error_code e3; fs::remove_all(b, e3); } ImGui::PopID(); } }
    } EndCard();
}

// ------------------------------------------------------------------ save editor
struct SaveDoc { fs::path path; std::string raw; int kind = 0; /*0 none,1 json,2 gz json,3 binary*/ JV root; std::string err; bool dirty = false; };
static SaveDoc g_doc;
static bool Inflate(const std::string& in, std::string& out) {
    z_stream z{}; if (inflateInit2(&z, 15 + 32) != Z_OK) return false; z.next_in = (Bytef*)in.data(); z.avail_in = (uInt)in.size(); char buf[1 << 16]; int r;
    do { z.next_out = (Bytef*)buf; z.avail_out = sizeof buf; r = inflate(&z, Z_NO_FLUSH); if (r != Z_OK && r != Z_STREAM_END) { inflateEnd(&z); return false; } out.append(buf, sizeof buf - z.avail_out); } while (r != Z_STREAM_END);
    inflateEnd(&z); return true;
}
static bool Deflate(const std::string& in, std::string& out) {
    z_stream z{}; if (deflateInit2(&z, 6, Z_DEFLATED, 15 + 16, 8, Z_DEFAULT_STRATEGY) != Z_OK) return false; z.next_in = (Bytef*)in.data(); z.avail_in = (uInt)in.size(); char buf[1 << 16]; int r;
    do { z.next_out = (Bytef*)buf; z.avail_out = sizeof buf; r = deflate(&z, Z_FINISH); out.append(buf, sizeof buf - z.avail_out); } while (r != Z_STREAM_END && r == Z_OK); deflateEnd(&z); return r == Z_STREAM_END;
}
static void LoadDoc(const fs::path& p) {
    g_doc = SaveDoc(); g_doc.path = p; std::ifstream f(p, std::ios::binary); std::stringstream ss; ss << f.rdbuf(); g_doc.raw = ss.str();
    std::string text = g_doc.raw; bool gz = text.size() > 2 && (unsigned char)text[0] == 0x1f && (unsigned char)text[1] == 0x8b;
    if (gz) { std::string o; if (!Inflate(g_doc.raw, o)) { g_doc.kind = 3; g_doc.err = "Corrupt gzip data."; return; } text = o; }
    size_t i = 0; while (i < text.size() && isspace((unsigned char)text[i])) i++;
    if (i < text.size() && (text[i] == '{' || text[i] == '[')) { std::string e; if (JParse(text, g_doc.root, e)) { g_doc.kind = gz ? 2 : 1; return; } g_doc.err = "Looks like JSON but could not be parsed: " + e; }
    g_doc.kind = 3; if (g_doc.err.empty()) g_doc.err = "This save is not JSON text (it is a binary format). The file editor can't safely edit it - use the live editing tabs while the game is running, then save in-game.";
}
static void DrawJV(JV& v, const std::string& name, int depth, const std::string& flt) {
    ImGui::PushID(&v);
    if (v.t == JV::Obj || v.t == JV::Arr) {
        size_t n = v.t == JV::Obj ? v.o.size() : v.a.size(); std::string lab = Fmt("%s  {%zu}", name.c_str(), n);
        if (depth == 0) ImGui::SetNextItemOpen(true, ImGuiCond_Once);
        if (ImGui::TreeNode(lab.c_str())) { size_t lim = std::min<size_t>(n, 300);
            for (size_t i = 0; i < lim; i++) { if (v.t == JV::Obj) DrawJV(v.o[i].second, v.o[i].first, depth + 1, flt); else DrawJV(v.a[i], Fmt("[%zu]", i), depth + 1, flt); }
            if (n > lim) ImGui::TextDisabled("... %zu more (use the search box)", n - lim); ImGui::TreePop(); }
    } else {
        ImGui::AlignTextToFramePadding(); ImGui::Text("%s", name.c_str()); ImGui::SameLine(300); ImGui::SetNextItemWidth(260);
        if (v.t == JV::Bool) { if (ImGui::Checkbox("##b", &v.b)) g_doc.dirty = true; }
        else if (v.t == JV::Num) { static std::map<const void*, std::string> eb; auto& b = eb[&v]; if (b.empty()) { b = v.num; } b.resize(std::max<size_t>(b.size(), 40)); if (ImGui::InputText("##n", b.data(), 40)) { std::string t = b.c_str(); char* e = nullptr; double d = strtod(t.c_str(), &e); if (e && *e == 0 && !t.empty()) { v.n = d; v.num = t; g_doc.dirty = true; } } }
        else if (v.t == JV::Str) { std::string tmp = v.s; tmp.resize(std::max<size_t>(tmp.size() + 256, 512)); if (ImGui::InputText("##s", tmp.data(), tmp.size())) { v.s = tmp.c_str(); g_doc.dirty = true; } }
        else ImGui::TextDisabled("null");
    }
    ImGui::PopID();
}
static void Flatten(JV& v, const std::string& path, const std::string& flt, std::vector<std::pair<std::string, JV*>>& out) {
    if (out.size() > 2000) return;
    if (v.t == JV::Obj) for (auto& kv : v.o) Flatten(kv.second, path + "/" + kv.first, flt, out);
    else if (v.t == JV::Arr) for (size_t i = 0; i < v.a.size(); i++) Flatten(v.a[i], path + "/" + std::to_string(i), flt, out);
    else { std::string a = path, f = flt; for (auto& c : a) c = (char)tolower(c); for (auto& c : f) c = (char)tolower(c); if (a.find(f) != std::string::npos) out.push_back({path, &v}); }
}
void DrawSaveEditor() {
    if (Card("e0", "Save-file editor", "Opens a save file from disk, lets you edit every value, and writes it back (a backup of the original is made first). CLOSE THE GAME (or load a different save) before editing the file that is currently open in the game, otherwise the game may overwrite it. This editor works on JSON saves (plain or gzip-compressed).")) {
        static char dir[512]; static bool init = false; if (!init) { snprintf(dir, sizeof dir, "%s", cfg().saveDir.c_str()); init = true; }
        ImGui::SetNextItemWidth(-190); ImGui::InputText("Save folder", dir, sizeof dir); ImGui::SameLine(); if (ImGui::Button("Auto-detect##e")) { g_saveDirs = FindSaveDirs(); if (!g_saveDirs.empty()) snprintf(dir, sizeof dir, "%s", g_saveDirs[0].string().c_str()); }
        cfg().saveDir = dir; std::error_code ec; std::vector<fs::path> files; if (fs::exists(cfg().saveDir, ec)) for (auto& e : fs::directory_iterator(cfg().saveDir, ec)) if (e.is_regular_file()) files.push_back(e.path());
        std::sort(files.begin(), files.end(), [&](auto& a, auto& b) { std::error_code e1; return fs::last_write_time(a, e1) > fs::last_write_time(b, e1); });
        static int sel = -1; ImGui::SetNextItemWidth(420); if (ImGui::BeginCombo("File", sel >= 0 && sel < (int)files.size() ? files[sel].filename().string().c_str() : "choose a save...")) { for (int i = 0; i < (int)files.size() && i < 200; i++) if (ImGui::Selectable(files[i].filename().string().c_str(), i == sel)) { sel = i; LoadDoc(files[i]); } ImGui::EndCombo(); }
        ImGui::SameLine(); if (ImGui::Button("Reload") && sel >= 0 && sel < (int)files.size()) LoadDoc(files[sel]);
    } EndCard();
    if (g_doc.kind == 0) return;
    if (g_doc.kind == 3) { ImGui::TextColored(kWarn, "%s", g_doc.err.c_str()); ImGui::Text("File: %s  (%zu bytes)", g_doc.path.filename().string().c_str(), g_doc.raw.size()); return; }
    ImGui::Text("%s  -  %s%s", g_doc.path.filename().string().c_str(), g_doc.kind == 2 ? "gzip JSON" : "JSON", g_doc.dirty ? "   (modified)" : "");
    static char flt[128] = ""; ImGui::SetNextItemWidth(300); ImGui::InputTextWithHint("##sf", "search keys, e.g. gold, iron, population...", flt, 128);
    ImGui::SameLine(); ImGui::BeginDisabled(!g_doc.dirty);
    if (ImGui::Button("Save (backup first)")) { std::string o; JWrite(g_doc.root, o); if (g_doc.kind == 2) { std::string z; if (Deflate(o, z)) o = z; }
        std::error_code ec; fs::path bd = BackupRoot() / ("edit_" + Stamp()); fs::create_directories(bd, ec); fs::copy_file(g_doc.path, bd / g_doc.path.filename(), ec); std::ofstream f(g_doc.path, std::ios::binary | std::ios::trunc); f.write(o.data(), (std::streamsize)o.size()); g_doc.dirty = false; g_stateMsg = "Saved. Backup in " + bd.string(); }
    ImGui::EndDisabled(); if (!g_stateMsg.empty()) Desc(g_stateMsg.c_str());
    ImGui::BeginChild("tree", ImVec2(0, 0), ImGuiChildFlags_Borders);
    if (*flt) { std::vector<std::pair<std::string, JV*>> out; Flatten(g_doc.root, "", flt, out); for (auto& o : out) DrawJV(*o.second, o.first, 1, flt); if (out.size() > 2000) ImGui::TextDisabled("Showing first 2000 matches"); }
    else DrawJV(g_doc.root, "root", 0, flt);
    ImGui::EndChild();
}


