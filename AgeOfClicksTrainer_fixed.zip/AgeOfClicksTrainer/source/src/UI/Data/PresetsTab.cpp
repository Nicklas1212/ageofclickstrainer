#include "Presets/Presets.h"
#include "UI/Common.h"
#include "UI/Tabs.h"

void DrawPresets() {
    Desc("A preset runs several actions at once. Every change can be reverted from the History page.");
    auto& list = Presets::All(); static int confirmDel = -1;
    for (int i = 0; i < (int)list.size(); i++) {
        const Preset& p = list[i]; ImGui::PushID(i);
        if (Card("pc", p.name.c_str(), p.description.c_str(), p.builtin ? nullptr : "custom")) {
            if (ImGui::Button("Activate", ImVec2(110, 0))) Presets::Apply(i);
            if (!p.builtin) { ImGui::SameLine(); if (ImGui::Button("Delete")) confirmDel = i; }
            ImGui::SameLine(); if (ImGui::TreeNode("Commands")) { for (auto& c : p.commands) ImGui::TextDisabled("%s", c.c_str()); ImGui::TreePop(); }
        } EndCard(); ImGui::PopID();
    }
    if (confirmDel >= 0) { ImGui::OpenPopup("Delete preset"); }
    if (ImGui::BeginPopupModal("Delete preset", nullptr, ImGuiWindowFlags_AlwaysAutoResize)) {
        ImGui::Text("Delete the preset '%s'?", confirmDel >= 0 && confirmDel < (int)list.size() ? list[confirmDel].name.c_str() : "");
        if (ImGui::Button("Delete")) { Presets::Delete(confirmDel); confirmDel = -1; ImGui::CloseCurrentPopup(); } ImGui::SameLine(); if (ImGui::Button("Cancel")) { confirmDel = -1; ImGui::CloseCurrentPopup(); } ImGui::EndPopup(); }
    if (Card("pn", "Create a custom preset", "Captures the toggles, freezes and multipliers that are active right now. Set up the game the way you want first, then save it here.")) {
        ImGui::SetNextItemWidth(260); ImGui::InputTextWithHint("##pn", "preset name", Buf("presetname"), 64); std::string nm = BufStr("presetname");
        ImGui::SameLine(); ImGui::BeginDisabled(nm.empty()); if (ImGui::Button("Save current state as preset")) { Presets::SaveUser(Presets::CaptureCurrent(nm)); Buf("presetname")[0] = 0; } ImGui::EndDisabled();
        Desc("Presets are plain text files in the 'presets' folder next to the program: one command per line. You can edit them with any text editor."); EndCard();
    }
}
