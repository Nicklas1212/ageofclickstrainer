#include "UI/Common.h"
#include "UI/Tabs.h"

void DrawConsole() {
    if (Card("k1", "Game console & raw commands", "Runs the GAME's own debug console (type 'help'). Prefix with '!' to send a raw bridge command instead (for troubleshooting).")) {
        static char in[256] = ""; ImGui::SetNextItemWidth(-260); bool enter = ImGui::InputText("##con", in, 256, ImGuiInputTextFlags_EnterReturnsTrue); ImGui::SameLine();
        if ((ImGui::Button("Run") || enter) && *in) { std::string c = in; Cmd(c[0] == '!' ? c.substr(1) : "console " + c); in[0] = 0; ImGui::SetKeyboardFocusHere(-1); }
        ImGui::SameLine(); if (ImGui::Button("help")) Cmd("console help"); ImGui::SameLine(); if (ImGui::Button("Bridge diag")) Cmd("diag");
        EndCard();
    }
    ImGui::BeginChild("log", ImVec2(0, 0), ImGuiChildFlags_Borders); auto log = link().LogCopy();
    for (auto& e : log) { ImGui::PushStyleColor(ImGuiCol_Text, e.err ? kBad : ImGui::GetStyleColorVec4(ImGuiCol_Text)); ImGui::TextWrapped("[%s] %s", e.time.c_str(), e.text.c_str()); ImGui::PopStyleColor(); }
    if (ImGui::GetScrollY() >= ImGui::GetScrollMaxY() - 5) ImGui::SetScrollHereY(1.0f);
    ImGui::EndChild();
}
