// App: the shared application shell (navigation, header, tab dispatch, HUD, hotkey-driven navigation).
#pragma once
#include "Core/Config.h"

namespace App {
void Init();                    // call after the ImGui context exists: theme, presets, link callbacks
void Tick(double now);          // per-frame logic (status polling, world state, hotkeys, periodic saves)
void DrawMain();                // header + navigation + the current tab, inside the current window
void DrawWindows();             // overlay: HUD bar, main window and any popped-out tabs (each movable/resizable)
void DrawHud();                 // compact strip with click-to-edit values
void GoTo(Tab t);
Tab Current();
void PopOut(Tab t);             // open a tab in its own floating window (overlay only)
void Shutdown();
extern bool g_mainOpen;         // overlay: main window visible
}
