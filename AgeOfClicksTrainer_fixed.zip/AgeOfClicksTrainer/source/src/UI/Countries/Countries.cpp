#include <algorithm>
#include <cmath>
#include <map>
#include "Map/MapView.h"
#include "UI/App.h"
#include "UI/Common.h"
#include "UI/Tabs.h"

namespace {
std::map<std::string, std::string> g_info; std::string g_infoFor; uint64_t g_infoSerial = 0;
void LoadInfo(const std::string& name) {
    if (g_infoFor != name) { g_infoFor = name; g_info.clear(); link().ClearTag("cinfo_c"); g_infoSerial = 0; }
    Poll("cinfo " + EncodeName(name), "cinfo_c", 1.5);
    uint64_t s = link().Serial("cinfo_c"); if (s != g_infoSerial) { g_infoSerial = s; g_info.clear(); for (auto& kv : Split(link().Payload("cinfo_c"), '\t')) { size_t e = kv.find('='); if (e != std::string::npos) g_info[kv.substr(0, e)] = kv.substr(e + 1); } }
}
std::string Info(const std::string& k) { auto it = g_info.find(k); return it == g_info.end() ? "" : it->second; }
bool Editable(const std::string& k) { return !(k.rfind("get", 0) == 0 || k.rfind("calculate", 0) == 0 || k == "name" || k == "colorHex" || k == "govForm" || k == "puppetMasterName" || k == "allyOfCountryName" || k == "allianceName" || k == "tag"); }
}

void DrawCountries() {
    state().PollWorld(2.0); auto& cs = state().Countries();
    static std::string flt; static int sortCol = 1; static bool sortAsc = false;
    float leftW = std::max(360.0f, ImGui::GetContentRegionAvail().x * 0.46f);
    ImGui::BeginChild("clist", ImVec2(leftW, 0), ImGuiChildFlags_Borders);
    UI::Search("##cf", flt, "search country / tag...", -1);
    if (cs.empty()) Desc("Loading countries...");
    if (ImGui::BeginTable("ct", 6, ImGuiTableFlags_RowBg | ImGuiTableFlags_ScrollY | ImGuiTableFlags_Sortable | ImGuiTableFlags_SizingStretchProp | ImGuiTableFlags_Resizable)) {
        ImGui::TableSetupColumn("Country", 0, 2.4f); ImGui::TableSetupColumn("Population", ImGuiTableColumnFlags_DefaultSort | ImGuiTableColumnFlags_PreferSortDescending); ImGui::TableSetupColumn("Money"); ImGui::TableSetupColumn("Military"); ImGui::TableSetupColumn("Happy"); ImGui::TableSetupColumn("Stab."); ImGui::TableSetupScrollFreeze(0, 1); ImGui::TableHeadersRow();
        std::vector<const CountryRow*> v; for (auto& c : cs) if (flt.empty() || ContainsNoCase(c.name, flt) || ContainsNoCase(c.tag, flt)) v.push_back(&c);
        if (ImGuiTableSortSpecs* sp = ImGui::TableGetSortSpecs()) if (sp->SpecsCount > 0) { sortCol = sp->Specs[0].ColumnIndex; sortAsc = sp->Specs[0].SortDirection == ImGuiSortDirection_Ascending; }
        std::stable_sort(v.begin(), v.end(), [&](const CountryRow* a, const CountryRow* b) { auto f = [&](const CountryRow* c) { switch (sortCol) { case 1: return c->pop; case 2: return c->gold; case 3: return c->strength; case 4: return c->happiness; case 5: return c->Stability(); default: return 0.0; } };
            if (sortCol == 0) return sortAsc ? a->name < b->name : a->name > b->name; return sortAsc ? f(a) < f(b) : f(a) > f(b); });
        ImGuiListClipper clip; clip.Begin((int)v.size());
        while (clip.Step()) for (int i = clip.DisplayStart; i < clip.DisplayEnd; i++) { const CountryRow& c = *v[i]; ImGui::TableNextRow(); ImGui::PushID(c.name.c_str()); ImGui::TableNextColumn();
            ImGui::ColorButton("##c", ImGui::ColorConvertU32ToFloat4(UI::Rgb(c.color)), ImGuiColorEditFlags_NoTooltip | ImGuiColorEditFlags_NoPicker | ImGuiColorEditFlags_NoDragDrop, ImVec2(10, 10)); ImGui::SameLine();
            if (ImGui::Selectable(c.name.c_str(), state().selected == c.name, ImGuiSelectableFlags_SpanAllColumns)) state().Select(c.name, false); if (c.me) { ImGui::SameLine(); ImGui::TextColored(kGood, "(you)"); }
            ImGui::TableNextColumn(); ImGui::TextUnformatted(Human(c.pop).c_str()); ImGui::TableNextColumn(); ImGui::TextUnformatted(Human(c.gold).c_str()); ImGui::TableNextColumn(); ImGui::TextUnformatted(Human(c.strength).c_str());
            ImGui::TableNextColumn(); ImGui::TextUnformatted(Human(c.happiness).c_str()); ImGui::TableNextColumn(); ImGui::Text("%.0f%%", c.Stability()); ImGui::PopID(); }
        ImGui::EndTable(); }
    ImGui::EndChild(); ImGui::SameLine();
    ImGui::BeginChild("cinspect", ImVec2(0, 0), ImGuiChildFlags_None);
    const CountryRow* c = state().Find(state().selected);
    if (!c) { Desc("Select a country in the list or on the map."); ImGui::EndChild(); return; }
    std::string tgt = Game::Target(c->name); LoadInfo(c->name);
    if (Card("ci0", "Country Inspector", nullptr)) {
        ImGui::TextColored(ImGui::ColorConvertU32ToFloat4(UI::Rgb(c->color)), "%s", c->name.c_str()); ImGui::SameLine(); ImGui::TextDisabled("[%s]  %s", c->tag.c_str(), c->form.c_str());
        if (c->me) { ImGui::SameLine(); ImGui::TextColored(kGood, "your country"); } if (c->ally) { ImGui::SameLine(); ImGui::TextColored(kGood, "ally"); } if (c->puppet) { ImGui::SameLine(); ImGui::TextColored(kWarn, "puppet"); }
        ImGui::Text("Population %s   Money %s   Military %s   Happiness %s   Stability %.0f%%   Territory %s", Human(c->pop).c_str(), Human(c->gold).c_str(), Human(c->strength).c_str(), Human(c->happiness).c_str(), c->Stability(), Human(c->territory).c_str());
        if (ImGui::Button("Show on map")) { App::GoTo(T_MAP); MapView::CenterOnCountry(c->name); } ImGui::SameLine(); if (ImGui::Button("Open diplomacy")) { state().selectedB = c->name; App::GoTo(T_DIPL); }
        if (!c->me) { ImGui::SameLine(); if (ImGui::Button("Annex")) Cmd("console annex " + c->name); ImGui::SameLine(); if (ImGui::Button("Make puppet")) Cmd("puppet on " + c->name); ImGui::SameLine(); if (ImGui::Button("Free")) Cmd("puppet off " + c->name);
            ImGui::SameLine(); if (ImGui::Button("Friendly")) Cmd("rel " + c->name + " 100"); ImGui::SameLine(); if (ImGui::Button("Declare war")) Cmd("console declareWar " + c->name); }
        EndCard();
    }
    if (Card("ci1", "Edit", "Every field below can be changed with Set, +, -, x (multiply), Reset and Freeze. For other countries the game may recalculate some values.")) {
        struct F { const char* label; const char* field; const char* desc; } f[] = {{"Money", "gold", "Treasury."}, {"Population bonus", "populationBonus", "Flat citizens added to the population."}, {"Manpower", "manpower", "Recruits."},
            {"Infantry", "infantry", ""}, {"Artillery", "artillery", ""}, {"Tanks", "tanks", ""}, {"Aircraft", "aircraft", ""}, {"Ships", "ships", ""}, {"Science points", "sciencePoints", ""}, {"Living standard", "livingStandard", ""},
            {"Revolution risk", "revolutionRisk", "Lower = more stable."}, {"War exhaustion", "warExhaustion", ""}, {"Territory size", "territorySize", "Number the game uses for economy; it does not move borders."}};
        for (auto& x : f) EditRowT(x.label, x.field, tgt, x.desc, true, Info(x.field).empty() ? "" : Human(atof(Info(x.field).c_str())));
        EndCard();
    }
    if (ImGui::CollapsingHeader("All values (click to edit)")) {
        if (ImGui::BeginTable("allv", 2, ImGuiTableFlags_RowBg | ImGuiTableFlags_SizingStretchProp)) { for (auto& kv : g_info) { ImGui::TableNextRow(); ImGui::TableNextColumn(); ImGui::TextUnformatted(kv.first.c_str()); ImGui::TableNextColumn();
                char* e = nullptr; double d = strtod(kv.second.c_str(), &e); bool num = e && *e == 0 && !kv.second.empty();
                if (num && Editable(kv.first)) ClickValue(kv.first.c_str(), tgt, kv.first, Human(d), kv.first.c_str()); else ImGui::TextDisabled("%s", kv.second.c_str()); }
            ImGui::EndTable(); } }
    if (ImGui::CollapsingHeader("Resources")) { if (ImGui::BeginTable("cres", 2, ImGuiTableFlags_RowBg)) { for (int i = 0; i < kResCount; i++) { ImGui::TableNextRow(); ImGui::TableNextColumn(); ImGui::TextUnformatted(kResNames[i]); ImGui::TableNextColumn(); ClickValue(kResKeys[i], tgt, kResKeys[i], Human(c->stock[i]), kResNames[i]); } ImGui::EndTable(); } }
    ImGui::EndChild();
}
