#include <algorithm>
#include <filesystem>
#include "Hotkeys/Hotkeys.h"
#include "Input/Keys.h"
#include "Map/MapView.h"
#include "Palette/Palette.h"
#include "Presets/Presets.h"
#include "UI/Common.h"
#include "UI/Tabs.h"
namespace fs = std::filesystem;

void DrawSettings() {
    Config& c = cfg();
    if (Card("s_app", "Appearance", "Applies immediately and is saved automatically.")) {
        ImGui::SetNextItemWidth(ImGui::GetFontSize() * 14); if (ImGui::Combo("Theme", &c.theme, "Midnight Blue\0Slate Gold\0Emerald\0Light\0Chartroom\0")) UI::ApplyTheme();
        ImGui::SetNextItemWidth(ImGui::GetFontSize() * 14); if (ImGui::SliderFloat("UI scale", &c.uiScale, 0.7f, 1.8f, "%.2f")) UI::ApplyTheme(); UI::Tip("Makes all text and controls bigger or smaller.");
        ImGui::SetNextItemWidth(ImGui::GetFontSize() * 14); ImGui::SliderFloat("Window opacity", &c.opacity, 0.4f, 1.0f, "%.2f"); UI::Tip(host().overlay ? "Opacity of the overlay windows." : "Opacity of the whole window.");
        ImGui::Checkbox("Animations", &c.animations); UI::Tip("Fade-in and fade-out of notifications.");
        if (!host().overlay) { ImGui::Checkbox("Compact window stays on top", &c.overlayTop); }
        ImGui::Checkbox("Quick-action bar", &c.quickBar); ImGui::SameLine(); ImGui::Checkbox("Status bar", &c.statusBar);
        EndCard();
    }
    if (Card("s_quick", "Quick actions", "The buttons under the title bar. Tick what you want, then move items with the arrows.")) {
        auto& q = c.quick; for (size_t i = 0; i < q.size(); i++) { ImGui::PushID((int)i); ImGui::TextUnformatted(Palette::Label(q[i]).c_str()); ImGui::SameLine(ImGui::GetFontSize() * 14);
            if (ImGui::SmallButton("Up") && i > 0) std::swap(q[i], q[i - 1]); ImGui::SameLine(); if (ImGui::SmallButton("Down") && i + 1 < q.size()) std::swap(q[i], q[i + 1]); ImGui::SameLine(); if (ImGui::SmallButton("Remove")) { q.erase(q.begin() + i); ImGui::PopID(); break; } ImGui::PopID(); }
        if (ImGui::BeginCombo("Add a button", "Choose...")) { for (auto& ch : Palette::QuickChoices()) if (std::find(q.begin(), q.end(), ch.id) == q.end() && ImGui::Selectable(ch.label.c_str())) q.push_back(ch.id); ImGui::EndCombo(); }
        if (ImGui::Button("Restore default buttons")) c.quick = Config().quick;
        EndCard();
    }
    if (Card("s_map", "Map", nullptr)) {
        ImGui::Checkbox("Borders", &c.mapBorders); ImGui::SameLine(); ImGui::Checkbox("Country labels", &c.mapLabels); ImGui::SameLine(); ImGui::Checkbox("Minimap", &c.mapMinimap); ImGui::SameLine(); ImGui::Checkbox("Dim other countries", &c.mapDimOthers);
        ImGui::SetNextItemWidth(ImGui::GetFontSize() * 14); ImGui::SliderFloat("Refresh every (seconds)", &c.mapRefresh, 1, 30, "%.0f");
        ImGui::SetNextItemWidth(ImGui::GetFontSize() * 14); ImGui::Combo("Default map mode", &c.mapMode, "Political\0Territory ownership\0Resource\0Population\0Military\0Happiness\0Economy\0Diplomacy\0");
        EndCard();
    }
    if (Card("s_keys", "Hotkeys", "Click a key box, then press the key you want. Esc clears it. Hotkeys work while the game window is focused.")) {
        for (int i = 0; i < A_COUNT; i++) { ImGui::PushID(i); ImGui::AlignTextToFramePadding(); ImGui::Text("%s", kActNames[i]); ImGui::SameLine(ImGui::GetFontSize() * 18);
            std::string lab = Hotkeys::Capturing() == i ? "press a key..." : KeyName(c.vk[i]); if (ImGui::Button(lab.c_str(), ImVec2(ImGui::GetFontSize() * 9, 0))) Hotkeys::BeginCapture(i); ImGui::PopID(); }
        char b[64]; snprintf(b, sizeof b, "%s", c.hotkeyMoney.c_str()); ImGui::SetNextItemWidth(ImGui::GetFontSize() * 8); if (ImGui::InputText("Amount for 'Add money'", b, sizeof b)) c.hotkeyMoney = b;
        if (ImGui::Button("Restore default hotkeys")) { Config d; for (int i = 0; i < A_COUNT; i++) c.vk[i] = d.vk[i]; Notify::Push(NoteType::Success, "Hotkeys restored to their defaults."); }
        EndCard();
    }
    if (Card("s_note", "Notifications", nullptr)) {
        ImGui::Checkbox("Info", &c.noteInfo); ImGui::SameLine(); ImGui::Checkbox("Success", &c.noteSuccess); ImGui::SameLine(); ImGui::Checkbox("Warning", &c.noteWarning); ImGui::SameLine(); ImGui::Checkbox("Error", &c.noteError);
        ImGui::SetNextItemWidth(ImGui::GetFontSize() * 14); ImGui::SliderFloat("Show for (seconds)", &c.noteSeconds, 1, 15, "%.0f"); ImGui::Checkbox("Play a sound for alerts", &c.beep);
        if (ImGui::Button("Test info")) Notify::Push(NoteType::Info, "This is an information message."); ImGui::SameLine(); if (ImGui::Button("Test success")) Notify::Push(NoteType::Success, "This is a success message.");
        ImGui::SameLine(); if (ImGui::Button("Test warning")) Notify::Push(NoteType::Warning, "This is a warning message."); ImGui::SameLine(); if (ImGui::Button("Test error")) Notify::Push(NoteType::Error, "This is an error message.");
        EndCard();
    }
    if (Card("s_prof", "Visible pages", "A profile chooses which pages are shown. 'Custom' lets you tick them yourself.")) {
        ImGui::SetNextItemWidth(ImGui::GetFontSize() * 12); if (ImGui::Combo("Profile", &c.profile, "Full\0Economy\0Research\0AFK\0Custom\0")) { ApplyProfile(c.profile); if (c.profile == 3) Cmd("preset afk"); }
        if (c.profile == 4) { int n = 0; for (int i = 1; i < T_COUNT; i++) { if (i == T_SET) continue; ImGui::Checkbox(kTabNames[i], &c.tabOn[i]); if (++n % 4) ImGui::SameLine(); } ImGui::NewLine(); }
        EndCard();
    }
    if (Card("s_pre", "Presets", nullptr)) {
        Desc(("User presets are stored in: " + (fs::path(host().baseDir) / "presets").string()).c_str());
        if (ImGui::Button("Reload presets")) { Presets::Load(); Notify::Push(NoteType::Success, "Presets reloaded."); }
        EndCard();
    }
    if (ImGui::CollapsingHeader("Map detection")) MapView::DrawSetup();
    if (Card("s_reset", "Reset", nullptr)) {
        if (ImGui::Button("Save settings now")) { SaveConfig(); Notify::Push(NoteType::Success, "Settings saved."); } ImGui::SameLine();
        if (ImGui::Button("Reset all settings to defaults")) ImGui::OpenPopup("Reset settings?");
        if (ImGui::BeginPopupModal("Reset settings?", nullptr, ImGuiWindowFlags_AlwaysAutoResize)) { ImGui::Text("Restore every setting, hotkey and theme to its default?");
            if (ImGui::Button("Reset")) { Config d; std::string dir = c.saveDir; c = d; c.saveDir = dir; UI::ApplyTheme(); SaveConfig(); Notify::Push(NoteType::Success, "Settings were reset."); ImGui::CloseCurrentPopup(); } ImGui::SameLine(); if (ImGui::Button("Cancel")) ImGui::CloseCurrentPopup(); ImGui::EndPopup(); }
        EndCard();
    }
    if (Card("s_about", "About & safety", nullptr)) {
        Desc("Single-player only: the in-game bridge refuses every write when the game reports a network/multiplayer session. Everything runs locally on 127.0.0.1. Many values are recalculated by the game each day - use Freeze/Min if a number snaps back. Keep a file backup (Save States page) before big changes.");
        EndCard();
    }
}
