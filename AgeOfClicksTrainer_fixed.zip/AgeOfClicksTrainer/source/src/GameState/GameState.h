// GameState: client-side model of the game, refreshed from bridge replies (status, world table, events, rates).
#pragma once
#include <deque>
#include <map>
#include <string>
#include <vector>
#include "Core/Link.h"
#include "GameState/Resources.h"

struct CountryRow {
    std::string name, tag, form; uint32_t color = 0x808080;
    double territory = 0, gold = 0, pop = 0, strength = 0, happiness = 0, income = 0, relation = 0, manpower = 0, revRisk = 0, warExh = 0, science = 0, living = 0;
    bool ally = false, puppet = false, me = false; double stock[kResCount] = {};
    double Stability() const;      // estimated from revolution risk (0-100)
};
struct GameEvent { std::string time; NoteType type; std::string text; };
struct Series { std::deque<std::pair<double, double>> pts; std::vector<float> spark; double lastSpark = 0; };

class GameState {
public:
    void Update(double now);                                  // call once per frame
    double Now() const { return now_; }
    bool Ready() const;                                       // connected, single-player game active
    // time series for the resource monitor and dashboard graphs
    double Rate(const std::string& key, double window, const std::string& perDayOf = "");
    const std::vector<float>& Spark(const std::string& key);
    // world table (polled on demand)
    void PollWorld(double every);
    const std::vector<CountryRow>& Countries() const { return countries_; }
    const CountryRow* Find(const std::string& name) const;
    uint64_t CountriesSerial() const { return countriesSerial_; }
    // selection (shared by Map, Countries, Territory, Diplomacy)
    std::string selected, selectedB;
    void Select(const std::string& name, bool announce = true);
    // event feed
    const std::deque<GameEvent>& Events() const { return events_; }
    void AddEvent(NoteType t, const std::string& text);
    std::string Time() const;
private:
    void Track(); void DetectEvents(); void ParseWorld();
    double now_ = 0; uint64_t lastStatus_ = 0, lastWorldSerial_ = 0, countriesSerial_ = 0;
    std::map<std::string, Series> series_; std::vector<CountryRow> countries_; std::deque<GameEvent> events_; std::map<std::string, std::string> prev_;
    std::map<std::string, double> nextPoll_;
};
GameState& state();
