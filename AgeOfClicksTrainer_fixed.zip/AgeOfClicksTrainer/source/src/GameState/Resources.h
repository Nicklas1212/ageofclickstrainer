// The standard stockpile keys used for monitoring. (The Resources tab lists the game's own resources dynamically.)
#pragma once
static const char* kResKeys[] = {"gold","iron","coal","oil","timber","rubber","aluminum","uranium","copper","manpower","steel","fuel","ammo","mechParts","electronics","trucks","consumerGoods","infantry","artillery","tanks","aircraft","ships","nuclearWeapons"};
static const char* kResNames[] = {"Money (gold)","Iron","Coal","Oil","Timber","Rubber","Aluminum","Uranium","Copper","Manpower","Steel","Fuel","Ammunition","Mechanical parts","Electronics","Trucks","Consumer goods","Infantry","Artillery","Tanks","Aircraft","Ships","Nuclear weapons"};
static const int kResCount = 23;
