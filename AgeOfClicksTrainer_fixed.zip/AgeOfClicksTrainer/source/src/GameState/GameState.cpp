#include "GameState/GameState.h"
#include <algorithm>
#include <ctime>
#include <windows.h>
#include "Core/Config.h"
#include "Notifications/Notifications.h"

GameState& state() { static GameState s; return s; }
double CountryRow::Stability() const { double r = revRisk; if (r > 1.0) r /= 100.0; return std::max(0.0, std::min(100.0, 100.0 * (1.0 - r))); }
bool GameState::Ready() const { return link().connected && link().gameReady && !link().multiplayer; }
std::string GameState::Time() const { time_t t = time(nullptr); tm lt{}; localtime_s(&lt, &t); char b[16]; snprintf(b, sizeof b, "%02d:%02d:%02d", lt.tm_hour, lt.tm_min, lt.tm_sec); return b; }
void GameState::AddEvent(NoteType t, const std::string& text) { events_.push_front({Time(), t, text}); while (events_.size() > 400) events_.pop_back(); }
void GameState::Select(const std::string& name, bool announce) { if (selected == name) return; selected = name; if (announce && !name.empty()) Notify::Push(NoteType::Info, "Country selected: " + name + "."); }
const CountryRow* GameState::Find(const std::string& name) const { for (auto& c : countries_) if (c.name == name) return &c; return nullptr; }

void GameState::Update(double now) {
    now_ = now;
    if (link().StatusSerial() != lastStatus_) { lastStatus_ = link().StatusSerial(); Track(); DetectEvents(); }
    if (link().Serial("world") != lastWorldSerial_) { lastWorldSerial_ = link().Serial("world"); ParseWorld(); }
}
void GameState::PollWorld(double every) { double& n = nextPoll_["world"]; if (now_ >= n) { n = now_ + every; link().Submit("wstats", "world"); } }

void GameState::Track() {
    Link& L = link();
    auto push = [&](const std::string& k) {
        std::string sv = L.Get(k); if (sv.empty()) return; double v = atof(sv.c_str()); auto& s = series_[k]; s.pts.push_back({now_, v});
        while (s.pts.size() > 600 || (!s.pts.empty() && now_ - s.pts.front().first > 12)) s.pts.pop_front();
        if (now_ - s.lastSpark > 1.0) { s.lastSpark = now_; s.spark.push_back((float)v); if (s.spark.size() > 120) s.spark.erase(s.spark.begin()); } };
    push("days"); for (int i = 0; i < kResCount; i++) push(kResKeys[i]);
    for (const char* k : {"getTotalPopulation", "getHappinessPercent", "sciencePoints", "lastNetGoldIncome", "calculateTotalStrength", "getDynamicGoldIncomePerSec", "territorySize", "getMilitaryCount"}) push(k);
    for (auto& a : cfg().alerts) {
        if (!a.on) continue; double v = L.Num(kResKeys[a.res]); bool hit = a.above ? v >= a.thr : v <= a.thr;
        if (hit && !a.fired) { a.fired = true; std::string m = Fmt("%s %s %s", kResNames[a.res], a.above ? "reached" : "fell to", Human(a.thr).c_str()); Notify::Push(NoteType::Warning, "Alert: " + m); AddEvent(NoteType::Warning, "Alert: " + m); if (cfg().beep) MessageBeep(MB_ICONEXCLAMATION); }
        if (!hit) a.fired = false;
    }
}
double GameState::Rate(const std::string& key, double window, const std::string& per) {
    auto it = series_.find(key); if (it == series_.end() || it->second.pts.size() < 2) return 0;
    auto& p = it->second.pts; auto& b = p.back(); const auto* a = &p.front(); for (auto& e : p) if (b.first - e.first <= window) { a = &e; break; }
    double dt = b.first - a->first; if (dt < 0.2) return 0; if (per.empty()) return (b.second - a->second) / dt;
    auto jt = series_.find(per); if (jt == series_.end() || jt->second.pts.empty()) return 0;
    double d1 = jt->second.pts.back().second, d0 = d1; for (auto& e : jt->second.pts) if (jt->second.pts.back().first - e.first <= window) { d0 = e.second; break; }
    return d1 - d0 > 0 ? (b.second - a->second) / (d1 - d0) : 0;
}
const std::vector<float>& GameState::Spark(const std::string& key) { return series_[key].spark; }

void GameState::DetectEvents() {
    Link& L = link(); auto chg = [&](const char* k, const char* fmt, bool numeric = false) {
        std::string nv = L.Get(k), &ov = prev_[k]; if (!ov.empty() && nv != ov && !nv.empty()) { AddEvent(NoteType::Info, Fmt(fmt, ov.c_str(), nv.c_str())); } ov = nv; (void)numeric; };
    chg("govForm", "Government changed from %s to %s.");
    { std::string nv = L.Get("hasEpidemic"), &ov = prev_["hasEpidemic"]; if (!ov.empty() && nv != ov) AddEvent(nv == "true" ? NoteType::Warning : NoteType::Success, nv == "true" ? "An epidemic broke out in your country." : "The epidemic in your country ended."); ov = nv; }
    { std::string nv = L.Get("rebellionStage"), &ov = prev_["rebellionStage"]; if (!ov.empty() && nv != ov) AddEvent(atoi(nv.c_str()) > atoi(ov.c_str()) ? NoteType::Warning : NoteType::Info, "Rebellion stage changed from " + ov + " to " + nv + "."); ov = nv; }
    { std::string nv = L.Get("sandbox"), &ov = prev_["sandbox"]; if (!ov.empty() && nv != ov) AddEvent(NoteType::Info, nv == "true" ? "Sandbox mode enabled." : "Sandbox mode disabled."); ov = nv; }
    { std::string nv = L.Get("paused"), &ov = prev_["paused"]; if (!ov.empty() && nv != ov) AddEvent(NoteType::Info, nv == "true" ? "Game paused." : "Game resumed."); ov = nv; }
    { std::string nv = L.Get("researched"), &ov = prev_["researched"]; if (!ov.empty() && nv != ov && atoi(nv.c_str()) > atoi(ov.c_str())) AddEvent(NoteType::Success, Fmt("Research completed (%d technologies known).", atoi(nv.c_str()))); ov = nv; }
    { double g = L.Num("gold"); std::string& ov = prev_["goldneg"]; std::string nv = g < 0 ? "1" : "0"; if (!ov.empty() && nv != ov) AddEvent(g < 0 ? NoteType::Warning : NoteType::Success, g < 0 ? "Your treasury went negative." : "Your treasury is positive again."); ov = nv; }
    { std::string nv = L.Get("getName"), &ov = prev_["country"]; if (!ov.empty() && nv != ov) AddEvent(NoteType::Info, "Playing as " + nv + "."); ov = nv; }
}

void GameState::ParseWorld() {
    std::string raw = link().Payload("world"); std::vector<CountryRow> out;
    auto num = [](const std::string& s) { return (s.empty() || s == "null") ? 0.0 : atof(s.c_str()); };
    for (auto& r : Split(raw, '\x1e')) {
        auto c = Split(r, '\x1f'); if (c.size() < 19 + kResCount) continue; CountryRow x;
        x.name = c[0]; x.tag = c[1]; uint32_t col; x.color = ParseHexColor(c[2], col) ? col : 0x808080; x.territory = num(c[3]); x.gold = num(c[4]); x.pop = num(c[5]); x.strength = num(c[6]); x.happiness = num(c[7]);
        x.income = num(c[8]); x.relation = num(c[9]); x.ally = c[10] == "true"; x.puppet = c[11] == "true"; x.me = c[12] == "1"; x.form = c[13]; x.manpower = num(c[14]); x.revRisk = num(c[15]); x.warExh = num(c[16]);
        x.science = num(c[17]); x.living = num(c[18]); for (int i = 0; i < kResCount; i++) x.stock[i] = num(c[19 + i]); out.push_back(x);
    }
    countries_.swap(out); countriesSerial_++;
    if (selected.empty()) for (auto& c : countries_) if (c.me) { selected = c.name; break; }
}
