// Command palette (Ctrl+K) and the action ids shared with the quick-action bar.
// Ids: "page:<page name>", "act:<undo|redo|pause|autoclick|quicksave|quickload|infmoney|compact|hide>", "country:<name>", "map:<name>", "preset:<name>".
#pragma once
#include <string>
#include <vector>

namespace Palette {
void Open();                                   // show the palette on the next frame
void Draw();                                   // call once per frame inside the main window
bool Run(const std::string& id);               // execute an action id; false when it is not available right now
std::string Label(const std::string& id);      // human-readable name for an id
bool Available(const std::string& id);         // false when the action needs a running game that is not ready
struct QuickChoice { std::string id, label; };
std::vector<QuickChoice> QuickChoices();       // everything that can be pinned to the quick-action bar
}
