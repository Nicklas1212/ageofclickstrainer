#include "Palette/Palette.h"
#include <algorithm>
#include "Core/Config.h"
#include "Core/Host.h"
#include "Game/GameApi.h"
#include "GameState/GameState.h"
#include "Map/MapView.h"
#include "Presets/Presets.h"
#include "UI/App.h"
#include "UI/Common.h"

namespace {
struct Item { std::string id, label, group; int score = 0; };
bool g_open = false, g_justOpened = false; char g_q[96] = ""; int g_sel = 0; std::vector<std::string> g_recent;
struct ActDef { const char* id; const char* label; bool needsGame; };
const ActDef kActs[] = {{"undo", "Undo last change", true}, {"redo", "Redo", true}, {"pause", "Pause or resume the game", true}, {"autoclick", "Toggle auto-clicker", true}, {"infmoney", "Toggle infinite money", true},
    {"quicksave", "Quick-save state (slot 1)", true}, {"quickload", "Quick-load state (slot 1)", true}, {"compact", "Toggle compact window", false}, {"hide", "Hide the overlay", false}};
int PageIndex(const std::string& name) { for (int i = 0; i < T_COUNT; i++) if (name == kTabNames[i]) return i; return -1; }
std::vector<Item> Build() {
    std::vector<Item> v;
    for (int i = 0; i < T_COUNT; i++) if (cfg().tabOn[i] || i == T_DASH || i == T_SET) v.push_back({std::string("page:") + kTabNames[i], std::string("Open ") + kTabNames[i], "Page"});
    for (auto& a : kActs) { if (std::string(a.id) == "compact" && !host().toggleCompact) continue; if (std::string(a.id) == "hide" && !host().requestClose) continue; v.push_back({std::string("act:") + a.id, a.label, "Action"}); }
    for (auto& p : Presets::All()) v.push_back({"preset:" + p.name, "Load preset: " + p.name, "Preset"});
    for (auto& c : state().Countries()) { v.push_back({"country:" + c.name, "Inspect " + c.name, "Country"}); v.push_back({"map:" + c.name, "Show " + c.name + " on the map", "Map"}); }
    return v;
}
}
namespace Palette {
void Open() { g_open = true; g_justOpened = true; g_q[0] = 0; g_sel = 0; }
bool Available(const std::string& id) {
    if (id.rfind("act:", 0) == 0) for (auto& a : kActs) if (id == std::string("act:") + a.id) return !a.needsGame || state().Ready();
    if (id.rfind("preset:", 0) == 0) return state().Ready();
    return true;
}
std::string Label(const std::string& id) {
    if (id.rfind("page:", 0) == 0) return id.substr(5);
    if (id.rfind("act:", 0) == 0) for (auto& a : kActs) if (id == std::string("act:") + a.id) return a.label;
    if (id.rfind("country:", 0) == 0) return id.substr(8); if (id.rfind("map:", 0) == 0) return "Map: " + id.substr(4); if (id.rfind("preset:", 0) == 0) return id.substr(7); return id;
}
std::vector<QuickChoice> QuickChoices() {
    std::vector<QuickChoice> v; for (int i = 0; i < T_COUNT; i++) v.push_back({std::string("page:") + kTabNames[i], kTabNames[i]});
    for (auto& a : kActs) v.push_back({std::string("act:") + a.id, a.label}); return v;
}
bool Run(const std::string& id) {
    if (!Available(id)) { Notify::Push(NoteType::Warning, "That action needs a running single-player game."); return false; }
    size_t c = id.find(':'); std::string kind = id.substr(0, c), arg = id.substr(c + 1);
    if (kind == "page") { int i = PageIndex(arg); if (i < 0) return false; App::GoTo((Tab)i); }
    else if (kind == "country") { state().Select(arg, false); App::GoTo(T_COUNTRIES); }
    else if (kind == "map") { state().Select(arg, false); App::GoTo(T_MAP); MapView::CenterOnCountry(arg); }
    else if (kind == "preset") { const auto& all = Presets::All(); for (size_t i = 0; i < all.size(); i++) if (all[i].name == arg) { Presets::Apply((int)i); break; } }
    else if (kind == "act") {
        if (arg == "undo") Cmd("undo"); else if (arg == "redo") Cmd("redo");
        else if (arg == "pause") Cmd(Fmt("pause %s", link().Get("paused") == "true" ? "off" : "on"));
        else if (arg == "autoclick") Cmd(Fmt("autoclick %s %g %g %g", IsFlag("autoclick") ? "off" : "on", cfg().cps, cfg().jitter, cfg().clickMul));
        else if (arg == "infmoney") Cmd(IsLocked("country.gold") ? "lock country.gold off" : "lock country.gold floor 9t");
        else if (arg == "quicksave") Cmd("snapshot 1"); else if (arg == "quickload") Cmd("restore 1");
        else if (arg == "compact") { if (host().toggleCompact) host().toggleCompact(); } else if (arg == "hide") { if (host().requestClose) host().requestClose(); }
    } else return false;
    g_recent.erase(std::remove(g_recent.begin(), g_recent.end(), id), g_recent.end()); g_recent.insert(g_recent.begin(), id); if (g_recent.size() > 8) g_recent.pop_back(); return true;
}
void Draw() {
    ImGuiIO& io = ImGui::GetIO();
    if (!g_open) return;
    ImGuiViewport* vp = ImGui::GetMainViewport(); float w = std::min(580.0f, vp->Size.x * 0.9f);
    ImGui::SetNextWindowPos(ImVec2(vp->Pos.x + vp->Size.x * 0.5f, vp->Pos.y + vp->Size.y * 0.16f), ImGuiCond_Always, ImVec2(0.5f, 0)); ImGui::SetNextWindowSize(ImVec2(w, 0)); ImGui::SetNextWindowBgAlpha(0.98f);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(14, 12)); ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 10); ImGui::PushStyleColor(ImGuiCol_Border, kAccent);
    bool shown = ImGui::Begin("Command palette##pal", nullptr, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoCollapse);
    ImGui::PopStyleColor(); ImGui::PopStyleVar(2);
    if (shown) {
        if (g_justOpened) { ImGui::SetWindowFocus(); ImGui::SetKeyboardFocusHere(); g_justOpened = false; }
        ImGui::SetNextItemWidth(-1); UI::PushFont(UI::fontHead); bool ch = ImGui::InputTextWithHint("##q", "Type a command, page or country", g_q, sizeof g_q); UI::PopFont(); if (ch) g_sel = 0;
        std::vector<Item> all = Build(), hit;
        for (auto& it : all) { int sc = 0; if (!UI::Fuzzy(it.label, g_q, &sc)) continue; it.score = sc; if (!*g_q) { auto r = std::find(g_recent.begin(), g_recent.end(), it.id); if (r == g_recent.end()) { if (it.group != "Page") continue; sc = 0; } else sc = 1000 - (int)(r - g_recent.begin()); it.score = sc; }
            if (*g_q && it.group == "Page") it.score += 25; hit.push_back(it); }
        std::stable_sort(hit.begin(), hit.end(), [](const Item& a, const Item& b) { return a.score > b.score; }); if (hit.size() > 12) hit.resize(12);
        if (io.KeyCtrl == false) { if (ImGui::IsKeyPressed(ImGuiKey_DownArrow)) g_sel++; if (ImGui::IsKeyPressed(ImGuiKey_UpArrow)) g_sel--; }
        g_sel = hit.empty() ? 0 : std::max(0, std::min((int)hit.size() - 1, g_sel));
        ImGui::Spacing(); if (hit.empty()) Desc("Nothing matches. Try a page name such as \"economy\", or a country name.");
        else if (!*g_q) ImGui::TextDisabled("Recent and pages");
        std::string run;
        for (int i = 0; i < (int)hit.size(); i++) { ImGui::PushID(i); bool ok = Available(hit[i].id); if (!ok) ImGui::BeginDisabled();
            if (ImGui::Selectable(("##s" + std::to_string(i)).c_str(), i == g_sel, ImGuiSelectableFlags_AllowOverlap, ImVec2(0, ImGui::GetTextLineHeight() + 6))) run = hit[i].id;
            ImVec2 a = ImGui::GetItemRectMin(), b = ImGui::GetItemRectMax(); ImDrawList* d = ImGui::GetWindowDrawList(); d->AddText(ImVec2(a.x + 6, a.y + 3), ImGui::GetColorU32(ImGuiCol_Text), hit[i].label.c_str());
            float gw = ImGui::CalcTextSize(hit[i].group.c_str()).x; d->AddText(ImVec2(b.x - gw - 8, a.y + 3), ImGui::GetColorU32(ImGuiCol_TextDisabled), hit[i].group.c_str()); if (!ok) ImGui::EndDisabled(); ImGui::PopID(); }
        if (ImGui::IsKeyPressed(ImGuiKey_Enter) && !hit.empty()) run = hit[g_sel].id;
        ImGui::Spacing(); ImGui::TextDisabled("Up/Down to move, Enter to run, Esc to close");
        if (!run.empty()) { if (Run(run)) g_open = false; }
        if (ImGui::IsKeyPressed(ImGuiKey_Escape) || (!ImGui::IsWindowFocused(ImGuiFocusedFlags_RootAndChildWindows) && !g_justOpened && ImGui::IsMouseClicked(0))) g_open = false;
    }
    ImGui::End();
}
}
