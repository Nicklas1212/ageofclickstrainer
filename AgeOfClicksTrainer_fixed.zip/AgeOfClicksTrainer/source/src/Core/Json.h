#pragma once
// Lenient JSON (accepts libGDX "minimal" style: unquoted keys/strings, optional commas, comments) -> editable tree -> strict JSON writer.
#include <string>
#include <vector>
#include <utility>
#include <cstdlib>
#include <cstdio>

struct JV {
    enum T { Null, Bool, Num, Str, Arr, Obj } t = Null;
    bool b = false; double n = 0; std::string num; std::string s;
    std::vector<JV> a; std::vector<std::pair<std::string, JV>> o;
};

struct JParser {
    const std::string& s; size_t i = 0; std::string err;
    explicit JParser(const std::string& str) : s(str) {}
    void ws() { for (;;) { while (i < s.size() && (isspace((unsigned char)s[i]) || s[i] == ',')) i++;
        if (i + 1 < s.size() && s[i] == '/' && s[i + 1] == '/') { while (i < s.size() && s[i] != '\n') i++; continue; }
        if (i + 1 < s.size() && s[i] == '/' && s[i + 1] == '*') { i += 2; while (i + 1 < s.size() && !(s[i] == '*' && s[i + 1] == '/')) i++; i += 2; continue; }
        break; } }
    bool quoted(std::string& out) { char q = s[i++]; out.clear();
        while (i < s.size() && s[i] != q) { char c = s[i++];
            if (c == '\\' && i < s.size()) { char e = s[i++]; switch (e) { case 'n': out += '\n'; break; case 't': out += '\t'; break; case 'r': out += '\r'; break; case 'b': out += '\b'; break; case 'f': out += '\f'; break;
                case 'u': { unsigned v = 0; for (int k = 0; k < 4 && i < s.size(); k++) v = v * 16 + (isdigit((unsigned char)s[i]) ? s[i] - '0' : (tolower(s[i]) - 'a' + 10)), i++;
                    if (v < 0x80) out += (char)v; else if (v < 0x800) { out += (char)(0xC0 | (v >> 6)); out += (char)(0x80 | (v & 63)); } else { out += (char)(0xE0 | (v >> 12)); out += (char)(0x80 | ((v >> 6) & 63)); out += (char)(0x80 | (v & 63)); } break; }
                default: out += e; } } else out += c; }
        if (i >= s.size()) return false; i++; return true; }
    std::string bare(bool key) { size_t st = i; while (i < s.size() && !isspace((unsigned char)s[i]) && s[i] != ',' && s[i] != '}' && s[i] != ']' && !(key && s[i] == ':') && s[i] != '{' && s[i] != '[') i++; return s.substr(st, i - st); }
    bool value(JV& v, int depth = 0) {
        ws(); if (i >= s.size()) { err = "unexpected end"; return false; } if (depth > 200) { err = "too deep"; return false; }
        char c = s[i];
        if (c == '{') { i++; v.t = JV::Obj;
            for (;;) { ws(); if (i >= s.size()) { err = "unterminated object"; return false; } if (s[i] == '}') { i++; return true; }
                std::string k; if (s[i] == '"' || s[i] == '\'') { if (!quoted(k)) { err = "bad key"; return false; } } else k = bare(true);
                ws(); if (i < s.size() && s[i] == ':') i++; JV c2; if (!value(c2, depth + 1)) return false; v.o.emplace_back(k, std::move(c2)); } }
        if (c == '[') { i++; v.t = JV::Arr;
            for (;;) { ws(); if (i >= s.size()) { err = "unterminated array"; return false; } if (s[i] == ']') { i++; return true; } JV c2; if (!value(c2, depth + 1)) return false; v.a.push_back(std::move(c2)); } }
        if (c == '"' || c == '\'') { v.t = JV::Str; return quoted(v.s) ? true : (err = "unterminated string", false); }
        std::string tok = bare(false); if (tok.empty()) { err = "unexpected character"; return false; }
        if (tok == "true" || tok == "false") { v.t = JV::Bool; v.b = tok == "true"; return true; }
        if (tok == "null") { v.t = JV::Null; return true; }
        char* e = nullptr; double d = strtod(tok.c_str(), &e);
        if (e && *e == 0) { v.t = JV::Num; v.n = d; v.num = tok; return true; }
        v.t = JV::Str; v.s = tok; return true;
    }
};

inline bool JParse(const std::string& text, JV& out, std::string& err) {
    JParser p(text); if (!p.value(out)) { err = p.err + " at byte " + std::to_string(p.i); return false; }
    p.ws(); return true;
}
inline void JEsc(std::string& o, const std::string& s) {
    o += '"'; for (unsigned char c : s) { switch (c) { case '"': o += "\\\""; break; case '\\': o += "\\\\"; break; case '\n': o += "\\n"; break; case '\r': o += "\\r"; break; case '\t': o += "\\t"; break;
        default: if (c < 0x20) { char b[8]; snprintf(b, sizeof b, "\\u%04x", c); o += b; } else o += (char)c; } } o += '"';
}
inline void JWrite(const JV& v, std::string& o) {
    switch (v.t) {
        case JV::Null: o += "null"; break; case JV::Bool: o += v.b ? "true" : "false"; break;
        case JV::Num: if (!v.num.empty()) o += v.num; else { char b[64]; snprintf(b, sizeof b, "%.17g", v.n); o += b; } break;
        case JV::Str: JEsc(o, v.s); break;
        case JV::Arr: o += '['; for (size_t k = 0; k < v.a.size(); k++) { if (k) o += ','; JWrite(v.a[k], o); } o += ']'; break;
        case JV::Obj: o += '{'; for (size_t k = 0; k < v.o.size(); k++) { if (k) o += ','; JEsc(o, v.o[k].first); o += ':'; JWrite(v.o[k].second, o); } o += '}'; break;
    }
}
