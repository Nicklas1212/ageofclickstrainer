#include "Core/Host.h"
Host& host() { static Host h; return h; }
