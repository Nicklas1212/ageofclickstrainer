#include "Core/Util.h"
#include <algorithm>
#include <cmath>
#include <cstdlib>

std::vector<std::string> Split(const std::string& s, char sep) {
    std::vector<std::string> out; size_t st = 0;
    while (true) { size_t p = s.find(sep, st); if (p == std::string::npos) { out.push_back(s.substr(st)); break; } out.push_back(s.substr(st, p - st)); st = p + 1; }
    return out;
}
std::string Fmt(const char* f, ...) { char b[2048]; va_list a; va_start(a, f); vsnprintf(b, sizeof b, f, a); va_end(a); return b; }
std::string Human(double v) {
    double a = std::fabs(v); char b[64];
    if (a >= 1e15) snprintf(b, sizeof b, "%.2fQ", v / 1e15); else if (a >= 1e12) snprintf(b, sizeof b, "%.2fT", v / 1e12); else if (a >= 1e9) snprintf(b, sizeof b, "%.2fB", v / 1e9);
    else if (a >= 1e6) snprintf(b, sizeof b, "%.2fM", v / 1e6); else if (a >= 1e4) snprintf(b, sizeof b, "%.1fK", v / 1e3); else if (a == std::floor(a)) snprintf(b, sizeof b, "%.0f", v); else snprintf(b, sizeof b, "%.3g", v);
    return b;
}
std::string Grouped(double v) {
    char b[64]; snprintf(b, sizeof b, "%.0f", std::fabs(v)); std::string s = b, out; int n = 0;
    for (int i = (int)s.size() - 1; i >= 0; i--) { out.insert(out.begin(), s[i]); if (++n % 3 == 0 && i > 0) out.insert(out.begin(), ','); }
    return (v < 0 ? "-" : "") + out;
}
std::string LowerCase(std::string s) { for (auto& c : s) c = (char)tolower((unsigned char)c); return s; }
bool ContainsNoCase(const std::string& h, const std::string& n) { return n.empty() || LowerCase(h).find(LowerCase(n)) != std::string::npos; }
std::string EncodeName(std::string n) { std::replace(n.begin(), n.end(), ' ', '_'); return n; }
bool ParseHexColor(const std::string& hex, uint32_t& out) {
    std::string h = hex; if (!h.empty() && h[0] == '#') h.erase(0, 1); if (h.size() == 8) h.erase(0, 2); if (h.size() != 6) return false;
    char* e = nullptr; unsigned long v = strtoul(h.c_str(), &e, 16); if (!e || *e) return false; out = (uint32_t)v; return true;
}
std::string Base64Decode(const std::string& in) {
    static int T[256]; static bool init = false;
    if (!init) { for (int i = 0; i < 256; i++) T[i] = -1; const char* c = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"; for (int i = 0; i < 64; i++) T[(unsigned char)c[i]] = i; init = true; }
    std::string out; out.reserve(in.size() * 3 / 4); int val = 0, bits = -8;
    for (unsigned char ch : in) { if (T[ch] < 0) continue; val = (val << 6) + T[ch]; bits += 6; if (bits >= 0) { out.push_back((char)((val >> bits) & 0xFF)); bits -= 8; } }
    return out;
}
