#include "Core/Config.h"
#include <windows.h>
#include <fstream>
#include <set>
#include "Core/Host.h"
#include "Core/Util.h"

const char* kTabNames[T_COUNT] = {"Dashboard", "Map", "Countries", "Events", "Economy", "Population", "Military", "Research", "Resources", "Industry", "Diplomacy", "Territory", "Politics", "World",
    "Economy Planner", "Time & Clicker", "Automation", "Presets", "History", "Variable Explorer", "Save States", "Save Editor", "Console", "Settings", "Rankings", "Compare", "Diagnostics", "Help"};
const char* kTabKeywords[T_COUNT] = {"overview summary graphs status", "world political territory zoom minimap", "inspector country list select", "log changes alerts feed", "money income debt tax budget loan interest gdp",
    "citizens happiness unrest stability workers growth", "army units manpower ammunition equipment", "technology science unlock queue", "iron coal oil steel fuel stock multiplier", "buildings upgrades factories construction",
    "relations influence alliance puppet", "land owner claim transfer", "government regime support", "pause speed time war peace capitulation ai multipliers sandbox", "target economy calculate upgrades prices",
    "autoclicker cps clicks speed", "afk auto upgrade research alerts", "preset profile save load", "undo redo changes log", "variables tree reflection fields", "backup snapshot slot", "file json edit", "command debug", "hotkeys theme scale opacity", "top best leaderboard rank sort", "side by side versus compare countries", "feature detection supported performance fps connection debug status", "guide shortcuts troubleshooting changelog help documentation"};
const char* kProfileNames[5] = {"Full", "Economy", "Research", "AFK", "Custom"};
const char* kActNames[A_COUNT] = {"Toggle overlay", "Go to Dashboard", "Go to Map", "Go to Countries", "Go to Economy", "Go to Military", "Toggle auto-clicker", "Pause / resume game", "Add money (amount in Settings)",
    "Quick-save state (slot 1)", "Quick-load state (slot 1)", "Undo last modification", "Redo", "Game speed +1", "Game speed -1", "Toggle infinite money", "Toggle compact window"};
const char* kActKeys[A_COUNT] = {"overlay", "tab_dashboard", "tab_map", "tab_countries", "tab_economy", "tab_military", "autoclick", "pause", "money", "quicksave", "quickload", "undo", "redo", "speed_up", "speed_down", "infinite_money", "compact"};

Config::Config() {
    for (int& v : vk) v = 0; for (bool& b : tabOn) b = true; quick = {"page:Dashboard", "page:Map", "page:Countries", "page:Economy", "page:Military", "page:Research", "act:undo", "act:redo"};
    vk[A_OVERLAY] = VK_INSERT; vk[A_TAB_DASH] = VK_F1; vk[A_TAB_MAP] = VK_F2; vk[A_TAB_COUNTRIES] = VK_F3; vk[A_TAB_ECONOMY] = VK_F4; vk[A_TAB_MILITARY] = VK_F5;
    vk[A_AUTOCLICK] = VK_F6; vk[A_PAUSE] = VK_F7; vk[A_MONEY] = VK_F8; vk[A_QSAVE] = VK_F9; vk[A_QLOAD] = VK_F10; vk[A_UNDO] = VK_F11;
}
static Config g_cfg; static std::string g_dir;
Config& cfg() { return g_cfg; }

static std::string Path() { return g_dir + "AgeOfClicksTrainer.ini"; }
void SaveConfig() {
    std::ofstream f(Path()); if (!f) return;
    for (int i = 0; i < A_COUNT; i++) f << "hotkey." << kActKeys[i] << "=" << g_cfg.vk[i] << "\n";
    for (int i = 0; i < T_COUNT; i++) f << "tab." << i << "=" << g_cfg.tabOn[i] << "\n";
    Config& c = g_cfg;
    f << "profile=" << c.profile << "\nautoInject=" << c.autoInject << "\nbeep=" << c.beep << "\nuiScale=" << c.uiScale << "\nopacity=" << c.opacity << "\ntheme=" << c.theme << "\nanimations=" << c.animations
      << "\noverlayTop=" << c.overlayTop << "\nmapRes=" << c.mapRes << "\nmapMode=" << c.mapMode << "\nmapBorders=" << c.mapBorders << "\nmapLabels=" << c.mapLabels << "\nmapMinimap=" << c.mapMinimap
      << "\nmapDimOthers=" << c.mapDimOthers << "\nmapLastGrid=" << c.mapLastGrid << "\nmapRefresh=" << c.mapRefresh << "\nmapResource=" << c.mapResource << "\ncps=" << c.cps << "\njitter=" << c.jitter << "\nclickMul=" << c.clickMul
      << "\nmoneyAmount=" << c.hotkeyMoney << "\nsaveDir=" << c.saveDir << "\nnoteSeconds=" << c.noteSeconds << "\nnoteInfo=" << c.noteInfo << "\nnoteSuccess=" << c.noteSuccess << "\nnoteWarning=" << c.noteWarning << "\nnoteError=" << c.noteError << "\nquickBar=" << c.quickBar << "\nstatusBar=" << c.statusBar << "\n";
    for (auto& n : c.favorites) f << "fav=" << n << "\n";
    for (auto& q : c.quick) f << "quick=" << q << "\n";
    for (auto& a : c.alerts) f << "alert=" << a.res << "," << a.above << "," << a.thr << "," << a.on << "\n";
}
void LoadConfig(const std::string& dir) {
    g_dir = dir; std::ifstream f(Path()); std::string l; Config& c = g_cfg; bool quickLoaded = false;
    while (std::getline(f, l)) { size_t e = l.find('='); if (e == std::string::npos) continue; std::string k = l.substr(0, e), v = l.substr(e + 1); auto b = [&]() { return v == "1"; };
        if (k.rfind("hotkey.", 0) == 0) { for (int i = 0; i < A_COUNT; i++) if (k.substr(7) == kActKeys[i]) c.vk[i] = atoi(v.c_str()); }
        else if (k.rfind("tab.", 0) == 0) { int i = atoi(k.c_str() + 4); if (i >= 0 && i < T_COUNT) c.tabOn[i] = b(); }
        else if (k == "profile") c.profile = atoi(v.c_str()); else if (k == "autoInject") c.autoInject = b(); else if (k == "beep") c.beep = b(); else if (k == "uiScale") c.uiScale = (float)atof(v.c_str());
        else if (k == "opacity") c.opacity = (float)atof(v.c_str()); else if (k == "theme") c.theme = atoi(v.c_str()); else if (k == "animations") c.animations = b(); else if (k == "overlayTop") c.overlayTop = b();
        else if (k == "mapRes") c.mapRes = atoi(v.c_str()); else if (k == "mapMode") c.mapMode = atoi(v.c_str()); else if (k == "mapBorders") c.mapBorders = b(); else if (k == "mapLabels") c.mapLabels = b();
        else if (k == "mapMinimap") c.mapMinimap = b(); else if (k == "mapDimOthers") c.mapDimOthers = b(); else if (k == "mapLastGrid") c.mapLastGrid = atoi(v.c_str()); else if (k == "mapRefresh") c.mapRefresh = (float)atof(v.c_str());
        else if (k == "mapResource") c.mapResource = atoi(v.c_str()); else if (k == "cps") c.cps = atof(v.c_str()); else if (k == "jitter") c.jitter = atof(v.c_str()); else if (k == "clickMul") c.clickMul = atof(v.c_str());
        else if (k == "moneyAmount") c.hotkeyMoney = v; else if (k == "saveDir") c.saveDir = v; else if (k == "noteSeconds") c.noteSeconds = (float)atof(v.c_str());
        else if (k == "noteInfo") c.noteInfo = b(); else if (k == "noteSuccess") c.noteSuccess = b(); else if (k == "noteWarning") c.noteWarning = b(); else if (k == "noteError") c.noteError = b();
        else if (k == "quickBar") c.quickBar = b(); else if (k == "statusBar") c.statusBar = b();
        else if (k == "fav") c.favorites.push_back(v); else if (k == "quick") { if (!quickLoaded) { c.quick.clear(); quickLoaded = true; } c.quick.push_back(v); }
        else if (k == "alert") { auto p = Split(v, ','); if (p.size() == 4) { Alert a; a.res = atoi(p[0].c_str()); a.above = p[1] == "1"; a.thr = atof(p[2].c_str()); a.on = p[3] == "1"; c.alerts.push_back(a); } }
    }
    if (c.profile != 4) ApplyProfile(c.profile);
    c.tabOn[T_DIAG] = c.tabOn[T_HELP] = true;
}
void ApplyProfile(int p) {
    static const std::set<int> eco = {T_DASH, T_MAP, T_COUNTRIES, T_ECO, T_RES, T_IND, T_PLAN, T_AUTO, T_PRESETS, T_HIST, T_STATE, T_CON, T_SET, T_TIME, T_EVENTS, T_WORLD};
    static const std::set<int> rs = {T_DASH, T_COUNTRIES, T_ECO, T_RSCH, T_AUTO, T_PRESETS, T_HIST, T_STATE, T_CON, T_SET, T_TIME, T_EVENTS, T_WORLD};
    static const std::set<int> afk = {T_DASH, T_AUTO, T_TIME, T_PRESETS, T_EVENTS, T_SET};
    for (int i = 0; i < T_COUNT; i++) g_cfg.tabOn[i] = (p == 0 || p == 4) ? true : (p == 1 ? eco.count(i) : p == 2 ? rs.count(i) : afk.count(i)) > 0;
    g_cfg.tabOn[T_DIAG] = g_cfg.tabOn[T_HELP] = true; if (p == 1 || p == 2) g_cfg.tabOn[T_RANK] = g_cfg.tabOn[T_COMPARE] = true;
}
