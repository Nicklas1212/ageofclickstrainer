// Core utilities shared by every module (strings, number formatting, colours).
#pragma once
#include <cstdarg>
#include <cstdint>
#include <cstdio>
#include <string>
#include <vector>

std::vector<std::string> Split(const std::string& s, char sep);
std::string Fmt(const char* fmt, ...);
std::string Human(double v);                       // 1.2M, 3.4B ...
std::string Grouped(double v);                     // 1,234,567
std::string LowerCase(std::string s);
bool ContainsNoCase(const std::string& hay, const std::string& needle);
std::string EncodeName(std::string name);          // spaces -> '_' (bridge command encoding)
bool ParseHexColor(const std::string& hex, uint32_t& rgbOut);   // "#RRGGBB" -> 0xRRGGBB
std::string Base64Decode(const std::string& in);
