// Persistent settings (one INI-style file next to the program). All keys and values are English.
#pragma once
#include <string>
#include <vector>

enum Tab {
    T_DASH, T_MAP, T_COUNTRIES, T_EVENTS,
    T_ECO, T_POP, T_MIL, T_RSCH, T_RES, T_IND, T_DIPL, T_TERR, T_POL, T_WORLD,
    T_PLAN, T_TIME, T_AUTO, T_PRESETS, T_HIST, T_VARS,
    T_STATE, T_SAVE, T_CON, T_SET,
    T_RANK, T_COMPARE, T_DIAG, T_HELP, T_COUNT
};
extern const char* kTabNames[T_COUNT];
extern const char* kTabKeywords[T_COUNT];

enum Act {
    A_OVERLAY, A_TAB_DASH, A_TAB_MAP, A_TAB_COUNTRIES, A_TAB_ECONOMY, A_TAB_MILITARY,
    A_AUTOCLICK, A_PAUSE, A_MONEY, A_QSAVE, A_QLOAD, A_UNDO, A_REDO, A_SPEEDUP, A_SPEEDDOWN, A_INFMONEY, A_COMPACT, A_COUNT
};
extern const char* kActNames[A_COUNT];
extern const char* kActKeys[A_COUNT];

struct Alert { int res = 0; bool above = false; double thr = 1000; bool on = false; bool fired = false; };

struct Config {
    int vk[A_COUNT];
    int profile = 0; bool tabOn[T_COUNT];
    bool autoInject = true; bool beep = true;
    // appearance
    float uiScale = 1.0f; float opacity = 0.97f; int theme = 4; bool animations = true; bool overlayTop = true;
    // map
    int mapRes = 512; int mapMode = 0; bool mapBorders = true; bool mapLabels = true; bool mapMinimap = true; bool mapDimOthers = true; int mapLastGrid = -1; float mapRefresh = 5.0f; int mapResource = 0;
    // clicker / misc
    double cps = 15, jitter = 20, clickMul = 1; std::string hotkeyMoney = "1m"; std::string saveDir;
    // notifications
    float noteSeconds = 4.0f; bool noteInfo = true, noteSuccess = true, noteWarning = true, noteError = true;
    std::vector<Alert> alerts;
    std::vector<std::string> favorites;     // favourite country names
    std::vector<std::string> quick;         // ids of the quick-action buttons, in order
    bool quickBar = true; bool statusBar = true;
    Config();
};
Config& cfg();
void LoadConfig(const std::string& dir);
void SaveConfig();
void ApplyProfile(int p);
extern const char* kProfileNames[5];
