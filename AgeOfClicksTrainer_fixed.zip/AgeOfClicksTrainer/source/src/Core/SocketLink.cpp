#include "Core/SocketLink.h"
#include <ws2tcpip.h>

static const int kBridgePort = 47653;
SocketLink::SocketLink() { WSADATA w; WSAStartup(MAKEWORD(2, 2), &w); }
SocketLink::~SocketLink() { WSACleanup(); }
bool SocketLink::Open() {
    s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP); if (s == INVALID_SOCKET) return false;
    sockaddr_in a{}; a.sin_family = AF_INET; a.sin_port = htons(kBridgePort); inet_pton(AF_INET, "127.0.0.1", &a.sin_addr);
    DWORD to = 8000; setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, (const char*)&to, sizeof to);
    if (connect(s, (sockaddr*)&a, sizeof a) != 0) { closesocket(s); s = INVALID_SOCKET; return false; }
    int one = 1; setsockopt(s, IPPROTO_TCP, TCP_NODELAY, (const char*)&one, sizeof one); rbuf.clear(); return true;
}
bool SocketLink::Exchange(const std::string& cmd, std::string& resp) {
    std::string out = cmd + "\n"; if (send(s, out.c_str(), (int)out.size(), 0) <= 0) return false;
    while (true) {
        size_t p = rbuf.find('\n'); if (p != std::string::npos) { resp = rbuf.substr(0, p); rbuf.erase(0, p + 1); return true; }
        static char b[1 << 16]; int n = recv(s, b, sizeof b, 0); if (n <= 0) return false; rbuf.append(b, n);
    }
}
void SocketLink::Close() { if (s != INVALID_SOCKET) { closesocket(s); s = INVALID_SOCKET; } }
