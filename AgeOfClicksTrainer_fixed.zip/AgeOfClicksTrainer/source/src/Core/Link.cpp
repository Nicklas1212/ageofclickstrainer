#include "Core/Link.h"
#include <chrono>
#include <ctime>

static Link* g_link = nullptr;
Link& link() { return *g_link; }
void SetLink(Link* l) { g_link = l; }

void Link::Start() { run = true; th = std::thread(&Link::Loop, this); }
void Link::Stop() { run = false; if (th.joinable()) th.join(); }
void Link::SetState(const std::string& s) { std::lock_guard<std::mutex> l(mu); stateMsg = s; }
std::string Link::StateMessage() { std::lock_guard<std::mutex> l(mu); return stateMsg; }
void Link::Submit(const std::string& cmd, const std::string& tag) {
    std::lock_guard<std::mutex> l(mu);
    if (tag != "cmd") for (auto& r : q) if (r.tag == tag) return;
    q.push_back({cmd, tag});
}
std::string Link::Get(const std::string& k, const std::string& def) { std::lock_guard<std::mutex> l(mu); auto it = kv.find(k); return it == kv.end() ? def : it->second; }
double Link::Num(const std::string& k, double def) { std::string s = Get(k); return s.empty() ? def : atof(s.c_str()); }
bool Link::Has(const std::string& k) { std::lock_guard<std::mutex> l(mu); return kv.count(k) > 0; }
std::string Link::Payload(const std::string& t) { std::lock_guard<std::mutex> l(mu); auto it = last.find(t); return it == last.end() ? "" : it->second; }
uint64_t Link::Serial(const std::string& t) { std::lock_guard<std::mutex> l(mu); auto it = serial.find(t); return it == serial.end() ? 0 : it->second; }
std::string Link::TagError(const std::string& t) { std::lock_guard<std::mutex> l(mu); auto it = tagErr.find(t); return it == tagErr.end() ? "" : it->second; }
void Link::ClearTag(const std::string& t) { std::lock_guard<std::mutex> l(mu); last.erase(t); tagErr.erase(t); serial.erase(t); }
void Link::AddLog(const std::string& t, bool err) {
    time_t now = time(nullptr); tm lt{}; 
#ifdef _WIN32
    localtime_s(&lt, &now);
#else
    localtime_r(&now, &lt);
#endif
    char b[16]; snprintf(b, sizeof b, "%02d:%02d:%02d", lt.tm_hour, lt.tm_min, lt.tm_sec);
    std::lock_guard<std::mutex> l(mu); log.push_back({b, t, err}); while (log.size() > 600) log.pop_front();
}
std::deque<LogEntry> Link::LogCopy() { std::lock_guard<std::mutex> l(mu); return log; }

static std::string Unescape(std::string s) { size_t p = 0; while ((p = s.find("\\n", p)) != std::string::npos) { s.replace(p, 2, "\n"); p++; } return s; }

void Link::Handle(const Req& r, const std::string& resp) {
    bool ok = resp.rfind("OK|", 0) == 0; std::string body = resp.size() > 3 ? resp.substr(3) : "";
    if (!ok) {
        std::string m = resp.size() > 4 ? resp.substr(4) : resp; auto parts = Split(m, '|');
        std::string code = parts.size() > 1 ? parts[0] : "", msg = parts.size() > 1 ? parts[1] : parts[0];
        if (code == "NOGAME") { gameReady = false; multiplayer = false; SetState("Connected - waiting for a game: " + Unescape(msg)); return; }
        if (code == "MULTIPLAYER") multiplayer = true;
        if (r.tag != "cmd" && r.tag != "status") { std::lock_guard<std::mutex> l(mu); tagErr[r.tag] = Unescape(msg); serial[r.tag]++; }
        if (r.tag == "cmd" || code == "MULTIPLAYER") { AddLog(r.cmd + "  ->  " + Unescape(msg), true); if (notify) notify(NoteType::Error, Unescape(msg)); }
        return;
    }
    if (r.tag == "status") {
        std::map<std::string, std::string> m;
        for (auto& f : Split(body, '\t')) { size_t e = f.find('='); if (e != std::string::npos) m[f.substr(0, e)] = f.substr(e + 1); }
        { std::lock_guard<std::mutex> l(mu); kv.swap(m); }
        statusSerial++; multiplayer = Get("mp") == "1"; gameReady = true;
        SetState(multiplayer ? "MULTIPLAYER detected - trainer disabled" : "Attached - single-player game active"); return;
    }
    if (r.tag == "cmd") { AddLog(r.cmd + "  ->  " + Unescape(body), false); if (notify) notify(NoteType::Success, Unescape(body)); }
    else { std::lock_guard<std::mutex> l(mu); last[r.tag] = body; tagErr.erase(r.tag); serial[r.tag]++; }
}

void Link::Loop() {
    bool open = false;
    while (run) {
        if (!open) {
            connected = false;
            if (!Open()) { SetState("Not connected - press 'Inject / Connect' (the game must be running)"); gameReady = false; for (int i = 0; i < 10 && run; i++) std::this_thread::sleep_for(std::chrono::milliseconds(100)); continue; }
            open = true; connected = true; SetState("Connected");
        }
        Req r; bool have = false;
        { std::lock_guard<std::mutex> l(mu); if (!q.empty()) { r = q.front(); q.pop_front(); have = true; } }
        if (!have) { std::this_thread::sleep_for(std::chrono::milliseconds(6)); continue; }
        std::string resp;
        if (!Exchange(r.cmd, resp)) { Close(); open = false; connected = false; gameReady = false; SetState("Connection lost"); continue; }
        Handle(r, resp);
    }
    if (open) Close();
}
