// Host: the services the shared UI needs from whichever program embeds it (external window or in-game overlay).
#pragma once
#include <cstdint>
#include <functional>
#include <string>
#include "imgui.h"

struct ITextureBackend {
    virtual ~ITextureBackend() {}
    virtual ImTextureID Create(int w, int h, const uint32_t* rgba) = 0;
    virtual void Update(ImTextureID id, int w, int h, const uint32_t* rgba) = 0;
    virtual void Destroy(ImTextureID id) = 0;
};

struct Host {
    bool overlay = false;                    // true when drawn inside the game window
    bool hotkeysActive = true;               // false while another window has the focus (overlay: game not in front)
    bool hasFocus = true;                    // the UI window currently receives keyboard input
    ITextureBackend* tex = nullptr;
    std::string baseDir;                     // folder for settings, backups, presets
    std::function<std::string()> gameDir;   // folder of the running game (used to find its save folder)
    std::function<void()> inject;            // external app: inject the helper DLL
    std::string injectStatus;                // external app: status line of the last injection attempt
    std::function<void()> toggleCompact;     // external app: compact stats window
    std::function<void()> requestClose;      // overlay: hide the overlay
};
Host& host();
