// Link: asynchronous command channel to the in-game bridge. The transport (TCP socket for the external app,
// direct JNI call for the in-game overlay) is supplied by subclasses; everything else is shared.
#pragma once
#include <atomic>
#include <deque>
#include <functional>
#include <map>
#include <mutex>
#include <string>
#include <thread>
#include "Core/Util.h"

struct LogEntry { std::string time, text; bool err; };
enum class NoteType { Info, Success, Warning, Error };

class Link {
public:
    virtual ~Link() {}
    void Start();
    void Stop();
    // Queue a command. Periodic requests with the same non-"cmd" tag are coalesced.
    void Submit(const std::string& cmd, const std::string& tag = "cmd");

    // Parsed live status (key=value pairs from the "status" command)
    std::string Get(const std::string& key, const std::string& def = "");
    double Num(const std::string& key, double def = 0);
    bool Has(const std::string& key);
    // Last payload for a tag, its serial number (increments per new payload), and error text if the last reply failed.
    std::string Payload(const std::string& tag);
    uint64_t Serial(const std::string& tag);
    std::string TagError(const std::string& tag);
    void ClearTag(const std::string& tag);

    void AddLog(const std::string& text, bool err);
    std::deque<LogEntry> LogCopy();

    std::atomic<bool> connected{false}, gameReady{false}, multiplayer{false};
    std::string StateMessage();
    uint64_t StatusSerial() const { return statusSerial; }
    // Called from the worker thread when a user-visible command finishes.
    std::function<void(NoteType, const std::string&)> notify;

protected:
    virtual bool Open() = 0;                                        // connect; false if unavailable right now
    virtual bool Exchange(const std::string& cmd, std::string& reply) = 0;   // false means the link broke
    virtual void Close() = 0;
    void SetState(const std::string& s);

private:
    struct Req { std::string cmd, tag; };
    void Loop();
    void Handle(const Req& r, const std::string& resp);
    std::mutex mu; std::deque<Req> q;
    std::map<std::string, std::string> kv, last, tagErr; std::map<std::string, uint64_t> serial;
    std::deque<LogEntry> log; std::string stateMsg = "Not connected";
    std::thread th; std::atomic<bool> run{false}; std::atomic<uint64_t> statusSerial{0};
};

Link& link();                 // the process-wide link (set by the host application)
void SetLink(Link* l);
