// TCP transport used by the external trainer window (127.0.0.1 only).
#pragma once
#include <winsock2.h>
#include "Core/Link.h"

class SocketLink : public Link {
public:
    SocketLink(); ~SocketLink();
protected:
    bool Open() override; bool Exchange(const std::string& cmd, std::string& reply) override; void Close() override;
private:
    SOCKET s = INVALID_SOCKET; std::string rbuf;
};
