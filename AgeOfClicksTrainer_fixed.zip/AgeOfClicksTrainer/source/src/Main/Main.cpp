// Age of Clicks Trainer - external window (DX11 + Win32). SINGLE-PLAYER ONLY.
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <d3d11.h>
#include <atomic>
#include <thread>
#include "imgui.h"
#include "imgui_impl_win32.h"
#include "imgui_impl_dx11.h"
#include "../../trainer/inject.h"
#include "Core/Config.h"
#include "Core/Host.h"
#include "Core/SocketLink.h"
#include "GameState/GameState.h"
#include "Notifications/Notifications.h"
#include "UI/App.h"
#include "UI/Common.h"
#include "Input/Keys.h"

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

static ID3D11Device* g_dev = nullptr; static ID3D11DeviceContext* g_ctx = nullptr; static IDXGISwapChain* g_swap = nullptr; static ID3D11RenderTargetView* g_rtv = nullptr;
static void CreateRTV() { ID3D11Texture2D* bb = nullptr; g_swap->GetBuffer(0, IID_PPV_ARGS(&bb)); g_dev->CreateRenderTargetView(bb, nullptr, &g_rtv); bb->Release(); }
static void CleanRTV() { if (g_rtv) { g_rtv->Release(); g_rtv = nullptr; } }
static bool CreateDevice(HWND hwnd) {
    DXGI_SWAP_CHAIN_DESC sd{}; sd.BufferCount = 2; sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM; sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT; sd.OutputWindow = hwnd;
    sd.SampleDesc.Count = 1; sd.Windowed = TRUE; sd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD; sd.Flags = DXGI_SWAP_CHAIN_FLAG_ALLOW_MODE_SWITCH;
    D3D_FEATURE_LEVEL fl; const D3D_FEATURE_LEVEL lv[] = {D3D_FEATURE_LEVEL_11_0, D3D_FEATURE_LEVEL_10_0};
    HRESULT r = D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, 0, lv, 2, D3D11_SDK_VERSION, &sd, &g_swap, &g_dev, &fl, &g_ctx);
    if (r == DXGI_ERROR_UNSUPPORTED) r = D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_WARP, nullptr, 0, lv, 2, D3D11_SDK_VERSION, &sd, &g_swap, &g_dev, &fl, &g_ctx);
    if (r != S_OK) return false; CreateRTV(); return true;
}
static LRESULT WINAPI WndProc(HWND h, UINT m, WPARAM w, LPARAM l) {
    if (ImGui_ImplWin32_WndProcHandler(h, m, w, l)) return true;
    switch (m) {
        case WM_SIZE: if (g_dev && w != SIZE_MINIMIZED) { CleanRTV(); g_swap->ResizeBuffers(0, LOWORD(l), HIWORD(l), DXGI_FORMAT_UNKNOWN, 0); CreateRTV(); } return 0;
        case WM_SYSCOMMAND: if ((w & 0xfff0) == SC_KEYMENU) return 0; break;
        case WM_DESTROY: PostQuitMessage(0); return 0;
    }
    return DefWindowProcW(h, m, w, l);
}

// Map textures live in DX11 shader-resource views; ImTextureID is the SRV pointer.
struct Dx11Textures : ITextureBackend {
    ImTextureID Create(int w, int h, const uint32_t* px) override {
        D3D11_TEXTURE2D_DESC d{}; d.Width = w; d.Height = h; d.MipLevels = 1; d.ArraySize = 1; d.Format = DXGI_FORMAT_R8G8B8A8_UNORM; d.SampleDesc.Count = 1; d.Usage = D3D11_USAGE_DEFAULT; d.BindFlags = D3D11_BIND_SHADER_RESOURCE;
        D3D11_SUBRESOURCE_DATA sd{px, (UINT)w * 4, 0}; ID3D11Texture2D* t = nullptr; if (FAILED(g_dev->CreateTexture2D(&d, &sd, &t))) return 0;
        ID3D11ShaderResourceView* v = nullptr; D3D11_SHADER_RESOURCE_VIEW_DESC sv{}; sv.Format = d.Format; sv.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D; sv.Texture2D.MipLevels = 1; g_dev->CreateShaderResourceView(t, &sv, &v); t->Release(); return (ImTextureID)v; }
    void Update(ImTextureID id, int w, int h, const uint32_t* px) override {
        ID3D11ShaderResourceView* v = (ID3D11ShaderResourceView*)id; if (!v) return; ID3D11Resource* r = nullptr; v->GetResource(&r); if (r) { g_ctx->UpdateSubresource(r, 0, nullptr, px, (UINT)w * 4, 0); r->Release(); } }
    void Destroy(ImTextureID id) override { ID3D11ShaderResourceView* v = (ID3D11ShaderResourceView*)id; if (v) v->Release(); }
};

static std::wstring g_exeDir; static std::atomic<bool> g_injecting{false}; static std::string g_gameDir; static bool g_compact = false;
static std::string Narrow(const std::wstring& w) { if (w.empty()) return ""; int n = WideCharToMultiByte(CP_UTF8, 0, w.c_str(), -1, nullptr, 0, nullptr, nullptr); std::string s(n, 0); WideCharToMultiByte(CP_UTF8, 0, w.c_str(), -1, s.data(), n, nullptr, nullptr); s.resize(n - 1); return s; }
static void DoInject() {
    if (g_injecting) return; GameProc g = FindGame();
    if (!g.pid) { host().injectStatus = "Age of Clicks is not running. Start the game first."; return; }
    if (!g.exePath.empty()) g_gameDir = Narrow(g.exePath.substr(0, g.exePath.find_last_of(L"\\/")));
    if (!g.hasJvm && !g.modulesUnknown) { host().injectStatus = "A game process was found but Java is not loaded in it" + g.diag + ". If the game is fully started, this build cannot see its Java - please send this line."; return; }
    if (g.hasCore) { host().injectStatus = "Already injected - connecting..."; return; }
    g_injecting = true; host().injectStatus = "Injecting into process " + std::to_string(g.pid) + "...";
    std::thread([g]() { std::string e = InjectDll(g.pid, g_exeDir + L"AgeOfClicksTrainerCore.dll"); host().injectStatus = e.empty() ? "Injected - connecting to the in-game bridge..." : "Injection failed: " + e; g_injecting = false; }).detach();
}

static void DrawCompact() {
    Link& L = link(); GameState& S = state();
    ImGui::TextColored(kAccent, "%s  %s", L.Get("getName").c_str(), L.Get("date").c_str());
    if (!S.Ready()) { ImGui::TextWrapped("%s", L.StateMessage().c_str()); return; }
    ImGui::TextDisabled("Money"); ImGui::SameLine(); ClickValue("g", "country", "gold", Val("gold"), "Money"); ImGui::SameLine(); double r = S.Rate("gold", 5); ImGui::TextColored(r >= 0 ? kGood : kBad, "(%s%s/s)", r >= 0 ? "+" : "", Human(r).c_str());
    ImGui::Text("Pop %s   Happy %s%%   Army %s", Val("getTotalPopulation").c_str(), Val("getHappinessPercent").c_str(), Val("getMilitaryCount").c_str());
    ImGui::Text("Steel %s  Fuel %s  Ammo %s", Val("steel").c_str(), Val("fuel").c_str(), Val("ammo").c_str());
    if (IsFlag("autoclick")) ImGui::TextColored(kGood, "Auto-clicker ON"); if (L.Get("paused") == "true") ImGui::TextColored(kWarn, "PAUSED");
}

int WINAPI WinMain(HINSTANCE hi, HINSTANCE, LPSTR, int) {
    g_exeDir = ExeDir(); host().baseDir = Narrow(g_exeDir); LoadConfig(host().baseDir);
    WNDCLASSEXW wc{sizeof wc, CS_CLASSDC, WndProc, 0, 0, hi, nullptr, nullptr, nullptr, nullptr, L"AocTrainer", nullptr}; RegisterClassExW(&wc);
    HWND hwnd = CreateWindowExW(WS_EX_LAYERED, wc.lpszClassName, L"Age of Clicks Tools (single-player)", WS_OVERLAPPEDWINDOW, 100, 80, 1280, 840, nullptr, nullptr, hi, nullptr);
    if (!CreateDevice(hwnd)) { MessageBoxW(nullptr, L"Could not create a Direct3D 11 device.", L"Error", MB_ICONERROR); return 1; }
    ShowWindow(hwnd, SW_SHOWDEFAULT); UpdateWindow(hwnd);
    IMGUI_CHECKVERSION(); ImGui::CreateContext(); ImGuiIO& io = ImGui::GetIO(); io.IniFilename = nullptr; io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
    UI::LoadFonts(io);
    ImGui_ImplWin32_Init(hwnd); ImGui_ImplDX11_Init(g_dev, g_ctx);
    static SocketLink net; SetLink(&net); static Dx11Textures tex; host().tex = &tex; host().overlay = false; host().inject = DoInject; host().gameDir = []() { return g_gameDir; };
    host().injectStatus = "Waiting for Age of Clicks to start...";
    RECT saved{}; host().toggleCompact = [&]() { g_compact = !g_compact; };
    App::Init(); net.Start();
    LARGE_INTEGER fq, t0; QueryPerformanceFrequency(&fq); QueryPerformanceCounter(&t0); bool prevCompact = false, done = false, insDown = false; double nextInject = 0;
    while (!done) {
        MSG msg; while (PeekMessageW(&msg, nullptr, 0, 0, PM_REMOVE)) { TranslateMessage(&msg); DispatchMessageW(&msg); if (msg.message == WM_QUIT) done = true; } if (done) break;
        LARGE_INTEGER t1; QueryPerformanceCounter(&t1); double now = double(t1.QuadPart - t0.QuadPart) / fq.QuadPart;
        host().hasFocus = GetForegroundWindow() == hwnd;
        if (cfg().autoInject && !net.connected && !g_injecting && now > nextInject) { nextInject = now + 2.5; DoInject(); }
        bool d = KeyDown(cfg().vk[A_OVERLAY]); if (d && !insDown) g_compact = !g_compact; insDown = d;
        App::Tick(now);
        if (g_compact != prevCompact) { prevCompact = g_compact;
            if (g_compact) { GetWindowRect(hwnd, &saved); SetWindowPos(hwnd, cfg().overlayTop ? HWND_TOPMOST : HWND_NOTOPMOST, saved.left, saved.top, 380, 200, SWP_NOACTIVATE); }
            else SetWindowPos(hwnd, HWND_NOTOPMOST, saved.left, saved.top, saved.right - saved.left, saved.bottom - saved.top, 0); }
        SetLayeredWindowAttributes(hwnd, 0, (BYTE)(255 * (g_compact ? std::min(cfg().opacity, 0.85f) : cfg().opacity)), LWA_ALPHA);
        ImGui_ImplDX11_NewFrame(); ImGui_ImplWin32_NewFrame(); ImGui::NewFrame();
        ImGuiViewport* vp = ImGui::GetMainViewport(); ImGui::SetNextWindowPos(vp->WorkPos); ImGui::SetNextWindowSize(vp->WorkSize);
        ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 0);
        ImGui::Begin("main", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoBringToFrontOnFocus);
        if (g_compact) { DrawCompact(); if (ImGui::Button("Full window")) g_compact = false; } else App::DrawMain();
        ImGui::End(); ImGui::PopStyleVar();
        if (!g_compact) Notify::Draw(now);
        ImGui::Render(); const float clear[4] = {0.055f, 0.075f, 0.082f, 1}; g_ctx->OMSetRenderTargets(1, &g_rtv, nullptr); g_ctx->ClearRenderTargetView(g_rtv, clear);
        ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData()); g_swap->Present(1, 0);
    }
    App::Shutdown(); net.Stop(); ImGui_ImplDX11_Shutdown(); ImGui_ImplWin32_Shutdown(); ImGui::DestroyContext(); CleanRTV(); return 0;
}
