#include "Notifications/Notifications.h"
#include <ctime>
#include <mutex>
#include "Core/Config.h"
#include "imgui.h"

namespace {
std::mutex mu; std::vector<Note> active, hist; double g_now = 0;
ImVec4 Col(NoteType t) { switch (t) { case NoteType::Success: return ImVec4(0.35f, 0.85f, 0.5f, 1); case NoteType::Warning: return ImVec4(1.0f, 0.75f, 0.3f, 1); case NoteType::Error: return ImVec4(0.95f, 0.38f, 0.38f, 1); default: return ImVec4(0.45f, 0.7f, 1.0f, 1); } }
}
namespace Notify {
const char* TypeName(NoteType t) { switch (t) { case NoteType::Success: return "Success"; case NoteType::Warning: return "Warning"; case NoteType::Error: return "Error"; default: return "Info"; } }
void Push(NoteType type, const std::string& text) {
    Config& c = cfg(); if ((type == NoteType::Info && !c.noteInfo) || (type == NoteType::Success && !c.noteSuccess) || (type == NoteType::Warning && !c.noteWarning) || (type == NoteType::Error && !c.noteError)) {
        // still keep it in the history so nothing is lost
    }
    time_t t = time(nullptr); tm lt{}; localtime_s(&lt, &t); char b[16]; snprintf(b, sizeof b, "%02d:%02d:%02d", lt.tm_hour, lt.tm_min, lt.tm_sec);
    std::lock_guard<std::mutex> l(mu); Note n{type, text, -1, b}; hist.push_back(n); if (hist.size() > 300) hist.erase(hist.begin());
    bool show = (type == NoteType::Info && c.noteInfo) || (type == NoteType::Success && c.noteSuccess) || (type == NoteType::Warning && c.noteWarning) || (type == NoteType::Error && c.noteError);
    if (show) { active.push_back(n); if (active.size() > 6) active.erase(active.begin()); }
}
std::vector<Note> History() { std::lock_guard<std::mutex> l(mu); return hist; }
void ClearHistory() { std::lock_guard<std::mutex> l(mu); hist.clear(); }
void Draw(double now) {
    std::lock_guard<std::mutex> l(mu); g_now = now;
    for (auto& n : active) if (n.born < 0) n.born = now;
    float life = cfg().noteSeconds;
    for (size_t i = 0; i < active.size();) { if (now - active[i].born > life) active.erase(active.begin() + i); else i++; }
    ImGuiViewport* vp = ImGui::GetMainViewport(); float y = vp->WorkPos.y + vp->WorkSize.y - 16;
    for (int i = (int)active.size() - 1; i >= 0; i--) {
        Note& n = active[i]; float age = (float)(now - n.born), alpha = age > life - 0.4f ? (life - age) / 0.4f : 1.0f; if (cfg().animations && age < 0.15f) alpha = age / 0.15f; if (alpha < 0) alpha = 0;
        ImGui::SetNextWindowPos(ImVec2(vp->WorkPos.x + vp->WorkSize.x - 16, y), ImGuiCond_Always, ImVec2(1, 1)); ImGui::SetNextWindowBgAlpha(0.92f * alpha);
        std::string id = "##toast" + std::to_string(i);
        ImGui::PushStyleVar(ImGuiStyleVar_Alpha, alpha);
        ImGui::Begin(id.c_str(), nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoInputs | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoFocusOnAppearing | ImGuiWindowFlags_NoNav);
        ImGui::PushStyleColor(ImGuiCol_Text, Col(n.type)); ImGui::TextUnformatted(TypeName(n.type)); ImGui::PopStyleColor(); ImGui::SameLine();
        ImGui::PushTextWrapPos(460); ImGui::TextWrapped("%s", n.text.c_str()); ImGui::PopTextWrapPos(); y -= ImGui::GetWindowHeight() + 6; ImGui::End(); ImGui::PopStyleVar();
    }
}
}
