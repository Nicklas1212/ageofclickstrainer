// Toast notifications (information / success / warning / error) with a history list.
#pragma once
#include <string>
#include <vector>
#include "Core/Link.h"

struct Note { NoteType type; std::string text; double born; std::string time; };
namespace Notify {
void Push(NoteType type, const std::string& text);
void Draw(double now);                         // draws the toast stack in a corner of the current viewport
std::vector<Note> History();
void ClearHistory();
const char* TypeName(NoteType t);
}
