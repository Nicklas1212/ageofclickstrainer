#include "Map/MapView.h"
#include <algorithm>
#include <cmath>
#include <cstring>
#include <vector>
#include "Core/Config.h"
#include "Core/Host.h"
#include "Core/Link.h"
#include "Game/GameApi.h"
#include "GameState/GameState.h"
#include "Map/MapData.h"
#include "Notifications/Notifications.h"
#include "UI/App.h"
#include "UI/Common.h"

namespace MapView {
const char* kModeNames[M_COUNT] = {"Political", "Territory ownership", "Resource", "Population", "Military", "Happiness", "Economy", "Diplomacy"};
namespace {
ImTextureID g_tex = 0; int g_texW = 0, g_texH = 0; uint64_t g_sig = 0; std::vector<uint32_t> g_pix;
ImVec2 g_pan(0, 0); float g_scale = 0; bool g_fit = true; ImVec2 g_canvasSize(0, 0);
std::string g_search; bool g_showOwn = true, g_showAllies = true, g_showPuppets = true, g_showOthers = true;
Focus g_focus; std::vector<uint8_t> g_region; uint64_t g_regionSerial = 1; std::string g_cellInfo; std::string g_panelSection;
struct Label { std::string name; float x, y; size_t cells; }; std::vector<Label> g_labels; uint64_t g_labelVersion = 0;
std::string g_pendingOwner; bool g_confirmOpen = false; std::string g_ownerFilter;
double g_pendingRefresh = 0;

uint32_t Mix(uint32_t a, uint32_t b, float t) { auto ch = [&](int s) { return (uint32_t)((int)(((a >> s) & 255) * (1 - t) + ((b >> s) & 255) * t) & 255) << s; }; return ch(16) | ch(8) | ch(0); }
uint32_t Heat(float t) {
    static const float st[5][3] = {{0.07f, 0.09f, 0.30f}, {0.10f, 0.45f, 0.65f}, {0.20f, 0.75f, 0.50f}, {0.96f, 0.85f, 0.22f}, {0.95f, 0.30f, 0.15f}};
    t = std::max(0.0f, std::min(1.0f, t)) * 4; int i = std::min(3, (int)t); float f = t - i; float r = st[i][0] * (1 - f) + st[i + 1][0] * f, g = st[i][1] * (1 - f) + st[i + 1][1] * f, b = st[i][2] * (1 - f) + st[i + 1][2] * f;
    return ((uint32_t)(r * 255) << 16) | ((uint32_t)(g * 255) << 8) | (uint32_t)(b * 255);
}
uint32_t Diverge(float t) {   // 0 = red, 0.5 = grey, 1 = green
    t = std::max(0.0f, std::min(1.0f, t)); uint32_t red = 0xD94A4A, mid = 0x808890, grn = 0x45C46B; return t < 0.5f ? Mix(red, mid, t * 2) : Mix(mid, grn, (t - 0.5f) * 2);
}
const uint32_t kOcean = 0x101C2A, kLand = 0x3A3F46;
bool Matches(const CountryRow& c) {
    if (!g_search.empty() && !ContainsNoCase(c.name, g_search) && !ContainsNoCase(c.tag, g_search)) return false;
    if (c.me) return g_showOwn; if (c.ally) return g_showAllies; if (c.puppet) return g_showPuppets; return g_showOthers;
}
double Value(const CountryRow& c) {
    switch (cfg().mapMode) {
        case M_RESOURCE: return c.stock[std::max(0, std::min(kResCount - 1, cfg().mapResource))];
        case M_POPULATION: return c.pop; case M_MILITARY: return c.strength; case M_HAPPINESS: return c.happiness; case M_ECONOMY: return c.gold; default: return 0; }
}

void Rebuild() {
    int w = MapData::Width(), h = MapData::Height(); if (w <= 0 || h <= 0 || !host().tex) return;
    auto& cs = state().Countries(); int mode = cfg().mapMode; int sel = MapData::OwnerIndexOfName(state().selected);
    std::vector<uint32_t> col(cs.size(), kLand); std::vector<uint8_t> dim(cs.size(), 0);
    double mx = 1e-9, mn = 1e300; for (auto& c : cs) { double v = Value(c); mx = std::max(mx, v); mn = std::min(mn, v); }
    bool pct = mode == M_HAPPINESS && mx <= 1.5;
    for (size_t i = 0; i < cs.size(); i++) {
        const CountryRow& c = cs[i]; uint32_t k = c.color;
        switch (mode) {
            case M_POLITICAL: case M_TERRITORY: k = c.color; break;
            case M_HAPPINESS: { double v = pct ? c.happiness * 100 : c.happiness; k = Diverge((float)(v / 100.0)); break; }
            case M_DIPLOMACY: k = c.me ? 0xF2C230 : c.ally ? 0x35D0E6 : c.puppet ? 0xA070E0 : Diverge((float)((c.relation + 100) / 200.0)); break;
            default: { double v = Value(c); float t = mx > 0 ? (float)(std::log1p(std::max(0.0, v)) / std::log1p(mx)) : 0; k = Heat(t); }
        }
        col[i] = k; bool selOther = sel >= 0 && (int)i != sel;
        if (!Matches(c) || (mode == M_TERRITORY && selOther && !c.me) || (mode == M_POLITICAL && cfg().mapDimOthers && selOther)) dim[i] = 1;
    }
    g_pix.assign((size_t)w * h, 0xFF000000u);
    auto set = [&](int x, int y, uint32_t rgb) { g_pix[(size_t)y * w + x] = 0xFF000000u | ((rgb & 0xFF) << 16) | (rgb & 0xFF00) | ((rgb >> 16) & 0xFF); };   // ImGui expects ABGR
    bool haveRegion = g_region.size() == (size_t)w * h && g_focus.valid;
    for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
        int o = MapData::OwnerAt(x, y); uint32_t raw = MapData::Raw(x, y); uint32_t c;
        if (o >= 0) { c = col[o]; if (dim[o]) c = Mix(c, kOcean, 0.72f); }
        else c = raw == 0 ? kOcean : kLand;
        if (cfg().mapBorders && o >= 0) { int xr = x + 1 < w ? MapData::OwnerAt(x + 1, y) : o, yd = y + 1 < h ? MapData::OwnerAt(x, y + 1) : o;
            if (xr != o || yd != o) c = Mix(c, 0x000000, 0.45f);
            if (sel >= 0) { int xl = x > 0 ? MapData::OwnerAt(x - 1, y) : o, yu = y > 0 ? MapData::OwnerAt(x, y - 1) : o; if (o == sel && (xr != o || yd != o || xl != o || yu != o)) c = 0xFFFFFF; } }
        if (haveRegion && g_region[(size_t)y * w + x]) c = Mix(c, 0xFFFFFF, 0.42f);
        set(x, y, c);
    }
    if (!g_tex || g_texW != w || g_texH != h) { if (g_tex) host().tex->Destroy(g_tex); g_tex = host().tex->Create(w, h, g_pix.data()); g_texW = w; g_texH = h; }
    else host().tex->Update(g_tex, w, h, g_pix.data());
}
void RebuildLabels() {
    auto& cs = state().Countries(); int w = MapData::Width(), h = MapData::Height(); std::vector<double> sx(cs.size(), 0), sy(cs.size(), 0); std::vector<size_t> n(cs.size(), 0);
    for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) { int o = MapData::OwnerAt(x, y); if (o >= 0) { sx[o] += x; sy[o] += y; n[o]++; } }
    g_labels.clear(); for (size_t i = 0; i < cs.size(); i++) if (n[i] > 12) g_labels.push_back({cs[i].name, (float)(sx[i] / n[i]), (float)(sy[i] / n[i]), n[i]});
}
void Fit() { if (g_texW <= 0 || g_canvasSize.x <= 0) return; g_scale = std::min(g_canvasSize.x / g_texW, g_canvasSize.y / g_texH); g_pan = ImVec2((g_canvasSize.x - g_texW * g_scale) / 2, (g_canvasSize.y - g_texH * g_scale) / 2); g_fit = false; }
void FloodRegion(int x, int y) {
    int w = MapData::Width(), h = MapData::Height(); g_region.assign((size_t)w * h, 0); uint32_t v = MapData::Raw(x, y); std::vector<int> st; st.push_back(y * w + x); g_region[(size_t)y * w + x] = 1; size_t n = 0;
    while (!st.empty()) { int p = st.back(); st.pop_back(); n++; int px = p % w, py = p / w; const int nb[4][2] = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
        for (auto& d : nb) { int qx = px + d[0], qy = py + d[1]; if (qx < 0 || qy < 0 || qx >= w || qy >= h) continue; size_t q = (size_t)qy * w + qx; if (!g_region[q] && MapData::Raw(qx, qy) == v) { g_region[q] = 1; st.push_back((int)q); } } }
    g_focus.cells = n; g_regionSerial++;
}
ImVec2 ToScreen(ImVec2 origin, float tx, float ty) { return ImVec2(origin.x + g_pan.x + tx * g_scale, origin.y + g_pan.y + ty * g_scale); }
}

const Focus& GetFocus() { return g_focus; }
void SetMode(int m) { cfg().mapMode = std::max(0, std::min((int)M_COUNT - 1, m)); }
void Release() { if (g_tex && host().tex) host().tex->Destroy(g_tex); g_tex = 0; g_texW = g_texH = 0; g_sig = 0; }
void SetFocusAt(int tx, int ty) {
    int w = MapData::Width(), h = MapData::Height(); if (tx < 0 || ty < 0 || tx >= w || ty >= h) return;
    g_focus = Focus(); g_focus.valid = true; g_focus.tx = tx; g_focus.ty = ty; g_focus.sx = (int)((tx + 0.5) * MapData::SourceWidth() / w); g_focus.sy = (int)((ty + 0.5) * MapData::SourceHeight() / h);
    g_focus.raw = MapData::Raw(tx, ty); g_focus.owner = MapData::OwnerAt(tx, ty); auto& cs = state().Countries(); if (g_focus.owner >= 0) g_focus.ownerName = cs[g_focus.owner].name;
    FloodRegion(tx, ty); double cellW = (double)MapData::SourceWidth() / w * MapData::SourceHeight() / h; g_focus.cells = (size_t)(g_focus.cells * cellW);
    if (g_focus.owner >= 0 && cs[g_focus.owner].territory > 0) g_focus.countryShare = 100.0 * g_focus.cells / cs[g_focus.owner].territory;
    g_cellInfo.clear(); link().ClearTag("cellinfo"); link().Submit(Fmt("cellinfo %d %d", g_focus.sx, g_focus.sy), "cellinfo"); g_sig = 0;
}
void CenterOnCountry(const std::string& name) {
    for (auto& l : g_labels) if (l.name == name) { g_pan = ImVec2(g_canvasSize.x / 2 - l.x * g_scale, g_canvasSize.y / 2 - l.y * g_scale); return; }
    Notify::Push(NoteType::Warning, "That country has no visible territory on the map.");
}
void CenterOnFocus() { if (g_focus.valid) g_pan = ImVec2(g_canvasSize.x / 2 - (g_focus.tx + 0.5f) * g_scale, g_canvasSize.y / 2 - (g_focus.ty + 0.5f) * g_scale); }
void RequestChangeOwner(const std::string& n) { g_pendingOwner = n; g_confirmOpen = true; }

void Tick(double now) {
    state().PollWorld(2.0); MapData::Tick(now, true);
    if (MapData::GetStage() == MapData::Stage::Ready && g_pendingRefresh > 0 && now >= g_pendingRefresh) { g_pendingRefresh = 0; MapData::Refresh(); }
}

void DrawToolbar() {
    Config& c = cfg(); ImGui::SetNextItemWidth(170); int m = c.mapMode; if (ImGui::BeginCombo("##mode", kModeNames[m])) { for (int i = 0; i < M_COUNT; i++) if (ImGui::Selectable(kModeNames[i], i == m)) c.mapMode = i; ImGui::EndCombo(); } UI::Tip("Map mode: what the colours mean.");
    if (c.mapMode == M_RESOURCE) { ImGui::SameLine(); ImGui::SetNextItemWidth(150); if (ImGui::BeginCombo("##res", kResNames[c.mapResource])) { for (int i = 0; i < kResCount; i++) if (ImGui::Selectable(kResNames[i], i == c.mapResource)) c.mapResource = i; ImGui::EndCombo(); } }
    ImGui::SameLine(); UI::Search("##mapsearch", g_search, "search country / tag...", 190);
    ImGui::SameLine(); if (ImGui::Button("Fit")) g_fit = true; UI::Tip("Show the whole world.");
    ImGui::SameLine(); if (ImGui::Button("Center")) { if (!state().selected.empty()) CenterOnCountry(state().selected); } UI::Tip("Center the camera on the selected country.");
    ImGui::SameLine(); if (ImGui::Button("Refresh")) MapData::Refresh(); UI::Tip("Reload ownership from the game now.");
    ImGui::SameLine(); if (ImGui::Button("Filters")) ImGui::OpenPopup("##filters2");
    if (ImGui::BeginPopup("##filters2")) {
        UI::Heading("Show countries"); ImGui::Checkbox("My country", &g_showOwn); ImGui::Checkbox("Allies", &g_showAllies); ImGui::Checkbox("Puppets", &g_showPuppets); ImGui::Checkbox("Everyone else", &g_showOthers);
        ImGui::Separator(); ImGui::Checkbox("Borders", &c.mapBorders); ImGui::Checkbox("Country labels", &c.mapLabels); ImGui::Checkbox("Minimap", &c.mapMinimap); ImGui::Checkbox("Dim other countries when one is selected", &c.mapDimOthers);
        ImGui::TextDisabled("Hidden countries are dimmed, not removed."); ImGui::EndPopup(); }
}

static void DrawLegend() {
    int mode = cfg().mapMode; if (mode == M_POLITICAL || mode == M_TERRITORY) return;
    ImDrawList* d = ImGui::GetWindowDrawList(); ImVec2 p = ImGui::GetCursorScreenPos(); float w = 180, h = 10;
    for (int i = 0; i < 90; i++) { float t = i / 89.0f; uint32_t c = mode == M_HAPPINESS ? Diverge(t) : mode == M_DIPLOMACY ? Diverge(t) : Heat(t); d->AddRectFilled(ImVec2(p.x + w * i / 90, p.y), ImVec2(p.x + w * (i + 1) / 90 + 1, p.y + h), UI::Rgb(c)); }
    const char* l = "low", *r = "high"; if (mode == M_DIPLOMACY) { l = "hostile"; r = "friendly"; } if (mode == M_HAPPINESS) { l = "unhappy"; r = "happy"; }
    ImGui::Dummy(ImVec2(w, h + 2)); ImGui::TextDisabled("%s", l); ImGui::SameLine(w - ImGui::CalcTextSize(r).x); ImGui::TextDisabled("%s", r);
}

void DrawCanvas(ImVec2 size) {
    using MapData::Stage; ImGuiIO& io = ImGui::GetIO(); Stage st = MapData::GetStage();
    ImGui::BeginChild("mapcanvas", size, ImGuiChildFlags_Borders, ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse);
    ImVec2 cmin = ImGui::GetCursorScreenPos(), avail = ImGui::GetContentRegionAvail(); g_canvasSize = avail; ImDrawList* d = ImGui::GetWindowDrawList();
    if (st != Stage::Ready) {
        ImGui::Dummy(ImVec2(0, 20)); ImGui::TextWrapped("%s", MapData::Message().c_str());
        if (st == Stage::Idle || st == Stage::Failed) { if (ImGui::Button("Detect map")) MapData::Detect(); }
        if (st == Stage::ChooseGrid || st == Stage::Failed) DrawSetup();
        ImGui::EndChild(); return; }
    // texture refresh when anything that affects the picture changed
    uint64_t sig = MapData::Version() * 1315423911ull ^ (uint64_t)cfg().mapMode * 2654435761ull ^ (uint64_t)(MapData::OwnerIndexOfName(state().selected) + 3) * 97531ull ^ (g_regionSerial << 7)
                 ^ ((uint64_t)cfg().mapBorders << 40) ^ ((uint64_t)cfg().mapDimOthers << 41) ^ ((uint64_t)cfg().mapResource << 42) ^ (state().CountriesSerial() << 20)
                 ^ ((uint64_t)g_showOwn << 50) ^ ((uint64_t)g_showAllies << 51) ^ ((uint64_t)g_showPuppets << 52) ^ ((uint64_t)g_showOthers << 53) ^ std::hash<std::string>()(g_search);
    if (sig != g_sig) { g_sig = sig; Rebuild(); }
    if (g_labelVersion != MapData::Version()) { g_labelVersion = MapData::Version(); RebuildLabels(); }
    if (g_fit || g_scale <= 0) Fit();
    ImGui::InvisibleButton("##mapbtn", avail, ImGuiButtonFlags_MouseButtonLeft | ImGuiButtonFlags_MouseButtonRight | ImGuiButtonFlags_MouseButtonMiddle); bool hovered = ImGui::IsItemHovered();
    ImVec2 mp = io.MousePos;
    if (hovered && io.MouseWheel != 0) {   // zoom around the cursor
        float old = g_scale, fit = std::min(avail.x / g_texW, avail.y / g_texH); float ns = std::max(fit * 0.6f, std::min(fit * 60.0f, old * std::pow(1.18f, io.MouseWheel)));
        float ax = (mp.x - cmin.x - g_pan.x) / old, ay = (mp.y - cmin.y - g_pan.y) / old; g_scale = ns; g_pan = ImVec2(mp.x - cmin.x - ax * ns, mp.y - cmin.y - ay * ns); }
    static ImVec2 downPos; static bool dragged = false;
    if (hovered && (ImGui::IsMouseClicked(0) || ImGui::IsMouseClicked(1))) { downPos = mp; dragged = false; }
    if (ImGui::IsItemActive() && (ImGui::IsMouseDown(0) || ImGui::IsMouseDown(2) || ImGui::IsMouseDown(1))) { ImVec2 dl = io.MouseDelta; if (std::fabs(mp.x - downPos.x) + std::fabs(mp.y - downPos.y) > 5) dragged = true; if (dragged && !ImGui::IsMouseDown(1)) { g_pan.x += dl.x; g_pan.y += dl.y; } }
    d->PushClipRect(cmin, ImVec2(cmin.x + avail.x, cmin.y + avail.y), true);
    d->AddRectFilled(cmin, ImVec2(cmin.x + avail.x, cmin.y + avail.y), UI::Rgb(kOcean));
    ImVec2 a = ToScreen(cmin, 0, 0), b = ToScreen(cmin, (float)g_texW, (float)g_texH); if (g_tex) d->AddImage(g_tex, a, b);
    int htx = (int)std::floor((mp.x - a.x) / g_scale), hty = (int)std::floor((mp.y - a.y) / g_scale); bool inMap = hovered && htx >= 0 && hty >= 0 && htx < g_texW && hty < g_texH;
    if (cfg().mapLabels) for (auto& l : g_labels) { float wpx = std::sqrt((float)l.cells) * g_scale * 1.6f; ImVec2 ts = ImGui::CalcTextSize(l.name.c_str()); if (wpx < ts.x * 0.55f) continue; ImVec2 p = ToScreen(cmin, l.x, l.y);
        if (p.x < cmin.x - 100 || p.y < cmin.y - 20 || p.x > cmin.x + avail.x + 100 || p.y > cmin.y + avail.y + 20) continue; d->AddText(ImVec2(p.x - ts.x / 2 + 1, p.y - ts.y / 2 + 1), IM_COL32(0, 0, 0, 200), l.name.c_str()); d->AddText(ImVec2(p.x - ts.x / 2, p.y - ts.y / 2), IM_COL32(255, 255, 255, 235), l.name.c_str()); }
    d->PopClipRect();
    auto& cs = state().Countries();
    if (inMap) {
        int o = MapData::OwnerAt(htx, hty);
        if (o >= 0 && !ImGui::IsPopupOpen("mapctx")) {
            const CountryRow& c = cs[o]; ImGui::BeginTooltip(); ImGui::TextColored(ImGui::ColorConvertU32ToFloat4(UI::Rgb(c.color)), "%s", c.name.c_str()); ImGui::SameLine(); ImGui::TextDisabled("[%s]", c.tag.c_str());
            ImGui::Separator(); ImGui::Text("Population: %s", Human(c.pop).c_str()); ImGui::Text("Money: %s", Human(c.gold).c_str()); ImGui::Text("Military: %s", Human(c.strength).c_str());
            ImGui::Text("Happiness: %s", Human(c.happiness).c_str()); ImGui::Text("Stability: %.0f%%", c.Stability()); ImGui::Text("Territory: %s cells", Human(c.territory).c_str());
            if (c.me) ImGui::TextColored(kGood, "Your country"); else if (c.ally) ImGui::TextColored(kGood, "Ally"); else if (c.puppet) ImGui::TextColored(kWarn, "Puppet"); ImGui::TextDisabled("Left click: select   Right click: territory menu"); ImGui::EndTooltip(); }
        else if (o < 0 && !ImGui::IsPopupOpen("mapctx")) { ImGui::BeginTooltip(); ImGui::TextDisabled(MapData::Raw(htx, hty) == 0 ? "Sea / unowned" : "Unowned land"); ImGui::EndTooltip(); }
        if (ImGui::IsMouseReleased(0) && !dragged) { if (o >= 0) { state().Select(cs[o].name, false); SetFocusAt(htx, hty); } }
        if (ImGui::IsMouseDoubleClicked(0) && o >= 0) CenterOnCountry(cs[o].name);
        if (ImGui::IsMouseReleased(1) && !dragged) { SetFocusAt(htx, hty); ImGui::OpenPopup("mapctx"); }
    }
    if (ImGui::BeginPopup("mapctx")) {
        UI::Heading(g_focus.ownerName.empty() ? "Unowned area" : g_focus.ownerName.c_str());
        bool has = g_focus.valid && g_focus.owner >= 0;
        if (ImGui::MenuItem("Inspect Territory", nullptr, false, g_focus.valid)) g_panelSection = "territory";
        if (ImGui::MenuItem("Edit Territory", nullptr, false, g_focus.valid)) { App::GoTo(T_TERR); }
        if (ImGui::BeginMenu("Change Owner", g_focus.valid)) {
            if (!MapData::Writable()) ImGui::TextDisabled("The detected map grid is read-only.");
            else { UI::Search("##ownflt", g_ownerFilter, "find country...", 200); ImGui::BeginChild("##ownlist", ImVec2(240, 220), ImGuiChildFlags_Borders);
                for (auto& n : MapData::CountryNames()) { if (!g_ownerFilter.empty() && !ContainsNoCase(n, g_ownerFilter)) continue; if (ImGui::Selectable(n.c_str())) { RequestChangeOwner(n); ImGui::CloseCurrentPopup(); } } ImGui::EndChild(); }
            ImGui::EndMenu(); }
        if (ImGui::MenuItem("Center Camera", nullptr, false, g_focus.valid)) CenterOnFocus();
        if (ImGui::MenuItem("View Resources", nullptr, false, has)) { state().Select(g_focus.ownerName, false); SetMode(M_RESOURCE); g_panelSection = "resources"; }
        if (ImGui::MenuItem("View Population", nullptr, false, has)) { state().Select(g_focus.ownerName, false); SetMode(M_POPULATION); g_panelSection = "population"; }
        ImGui::EndPopup(); }
    // minimap
    if (cfg().mapMinimap && g_tex) {
        float mw = 200, mh = mw * g_texH / g_texW; ImVec2 mp0(cmin.x + avail.x - mw - 8, cmin.y + avail.y - mh - 8); ImGui::SetCursorScreenPos(mp0); ImGui::InvisibleButton("##minimap", ImVec2(mw, mh));
        d->AddRectFilled(ImVec2(mp0.x - 2, mp0.y - 2), ImVec2(mp0.x + mw + 2, mp0.y + mh + 2), IM_COL32(0, 0, 0, 170)); d->AddImage(g_tex, mp0, ImVec2(mp0.x + mw, mp0.y + mh));
        float k = mw / g_texW; ImVec2 v0(mp0.x + (-g_pan.x / g_scale) * k, mp0.y + (-g_pan.y / g_scale) * k), v1(v0.x + avail.x / g_scale * k, v0.y + avail.y / g_scale * k);
        d->PushClipRect(mp0, ImVec2(mp0.x + mw, mp0.y + mh), true); d->AddRect(v0, v1, IM_COL32(255, 255, 255, 230), 0, 0, 1.5f); d->PopClipRect();
        if (ImGui::IsItemActive()) { float tx = (io.MousePos.x - mp0.x) / k, ty = (io.MousePos.y - mp0.y) / k; g_pan = ImVec2(avail.x / 2 - tx * g_scale, avail.y / 2 - ty * g_scale); dragged = true; }
        UI::Tip("Minimap: click or drag to move the camera."); }
    ImGui::SetCursorScreenPos(ImVec2(cmin.x + 8, cmin.y + 8)); DrawLegend();
    ImGui::EndChild();
    DrawDialogs();
}

void DrawDialogs() {
    static unsigned lastFrame = 0; if (lastFrame == (unsigned)ImGui::GetFrameCount()) return; lastFrame = (unsigned)ImGui::GetFrameCount();
    if (g_confirmOpen) { ImGui::OpenPopup("Change territory owner"); g_confirmOpen = false; }
    ImGui::SetNextWindowSizeConstraints(ImVec2(420, 0), ImVec2(560, 400));
    if (ImGui::BeginPopupModal("Change territory owner", nullptr, ImGuiWindowFlags_AlwaysAutoResize)) {
        ImGui::TextWrapped("Give the connected area under the cursor (about %s cells, now owned by %s) to %s?", Human((double)g_focus.cells).c_str(), g_focus.ownerName.empty() ? "nobody" : g_focus.ownerName.c_str(), g_pendingOwner.c_str());
        Desc("Experimental: this writes into the game's map data. The on-screen map in the game may only redraw after a reload, and the standard Undo cannot revert it. To go back, change the owner back the same way.");
        if (ImGui::Button("Change owner", ImVec2(140, 0))) { uint32_t key; if (MapData::KeyForCountry(g_pendingOwner, key)) { Cmd(Fmt("mapset %d %d %u", g_focus.sx, g_focus.sy, key)); g_pendingRefresh = state().Now() + 0.8; } else Notify::Push(NoteType::Error, "No map value is known for that country."); ImGui::CloseCurrentPopup(); }
        ImGui::SameLine(); if (ImGui::Button("Cancel", ImVec2(100, 0))) ImGui::CloseCurrentPopup(); ImGui::EndPopup(); }
}

void DrawSidePanel() {
    auto& cs = state().Countries(); const CountryRow* sel = state().Find(state().selected);
    std::string ci = link().Payload("cellinfo"); if (!ci.empty()) g_cellInfo = ci;
    if (sel) {
        ImGui::TextColored(ImGui::ColorConvertU32ToFloat4(UI::Rgb(sel->color)), "%s", sel->name.c_str()); ImGui::SameLine(); ImGui::TextDisabled("[%s]", sel->tag.c_str()); ImGui::TextDisabled("%s", sel->form.c_str());
        if (ImGui::Button("Open in Countries")) App::GoTo(T_COUNTRIES); ImGui::SameLine(); if (ImGui::Button("Center")) CenterOnCountry(sel->name);
        ImGui::Separator();
        ImGui::Text("Population"); ImGui::SameLine(110); ImGui::TextColored(kGood, "%s", Human(sel->pop).c_str());
        ImGui::Text("Money"); ImGui::SameLine(110); ImGui::TextColored(kGood, "%s", Human(sel->gold).c_str());
        ImGui::Text("Military"); ImGui::SameLine(110); ImGui::TextColored(kGood, "%s", Human(sel->strength).c_str());
        ImGui::Text("Happiness"); ImGui::SameLine(110); ImGui::TextColored(kGood, "%s", Human(sel->happiness).c_str());
        ImGui::Text("Stability"); ImGui::SameLine(110); ImGui::TextColored(kGood, "%.0f%%", sel->Stability());
        ImGui::Text("Territory"); ImGui::SameLine(110); ImGui::TextColored(kGood, "%s", Human(sel->territory).c_str());
        ImGui::Text("Income"); ImGui::SameLine(110); ImGui::TextColored(sel->income >= 0 ? kGood : kBad, "%s", Human(sel->income).c_str());
        bool openRes = g_panelSection == "resources", openPop = g_panelSection == "population", openTer = g_panelSection == "territory";
        if (openRes) ImGui::SetNextItemOpen(true); if (ImGui::CollapsingHeader("Resources")) { for (int i = 0; i < kResCount; i++) if (sel->stock[i] != 0) { ImGui::Text("%s", kResNames[i]); ImGui::SameLine(150); ImGui::Text("%s", Human(sel->stock[i]).c_str()); } }
        if (openPop) ImGui::SetNextItemOpen(true); if (ImGui::CollapsingHeader("Population")) { double tot = 0; for (auto& c : cs) tot += c.pop; ImGui::Text("World share: %.2f%%", tot > 0 ? 100 * sel->pop / tot : 0.0); ImGui::Text("Manpower: %s", Human(sel->manpower).c_str()); ImGui::Text("Living standard: %s", Human(sel->living).c_str()); }
        if (openTer) ImGui::SetNextItemOpen(true);
        if (ImGui::CollapsingHeader("Territory under cursor") && g_focus.valid) {
            ImGui::Text("Owner: %s", g_focus.ownerName.empty() ? "nobody" : g_focus.ownerName.c_str()); ImGui::Text("Cell: %d, %d", g_focus.sx, g_focus.sy); ImGui::Text("Region size: ~%s cells", Human((double)g_focus.cells).c_str());
            if (g_focus.countryShare > 0) ImGui::Text("Share of country: %.1f%%", g_focus.countryShare); ImGui::Text("Grid value: %u", g_focus.raw);
            if (!g_cellInfo.empty()) { for (auto& kv : Split(g_cellInfo, '\t')) ImGui::TextDisabled("%s", kv.c_str()); }
            if (ImGui::Button("Edit Territory")) App::GoTo(T_TERR); }
        g_panelSection.clear();
    } else Desc("Click a country on the map to select it.");
}

void DrawSetup() {
    using MapData::Stage; Stage st = MapData::GetStage();
    UI::Heading("Map setup & diagnostics");
    Desc("The map is read from the running game at run time. If the picture is wrong, pick a different grid below. All of this only reads data unless you change a territory owner.");
    ImGui::Text("Status:"); ImGui::SameLine(); ImGui::TextColored(st == Stage::Ready ? kGood : st == Stage::Failed ? kBad : kWarn, "%s", MapData::Message().c_str());
    if (!MapData::Extractor().empty()) ImGui::Text("Country matching: %s, %d%% of land cells matched.", MapData::Extractor().c_str(), MapData::Coverage());
    if (ImGui::Button("Detect again")) MapData::Detect(); ImGui::SameLine(); if (ImGui::Button("Dump classes to file")) Cmd("classdump"); UI::Tip("Writes the field/method names of the game's map classes to aoc_class_dump.txt in the game folder, for troubleshooting."); ImGui::SameLine(); if (ImGui::Button("Write diagnostics")) Cmd("mapdiag"); UI::Tip("Writes aoc_map_diag.txt (every candidate grid, its most common values, and how many countries matched) to the game folder. Send it if the map is still wrong.");
    int res = cfg().mapRes; ImGui::SetNextItemWidth(160); if (ImGui::Combo("Detail", &res, "Low (256)\0Medium (384)\0High (512)\0Very high (768)\0Maximum (1024)\0")) { static const int v[] = {256, 384, 512, 768, 1024}; cfg().mapRes = v[res]; MapData::Refresh(); }
    ImGui::SetNextItemWidth(160); ImGui::SliderFloat("Refresh every (s)", &cfg().mapRefresh, 1, 30, "%.0f");
    if (!MapData::Grids().empty() && ImGui::BeginTable("grids", 6, ImGuiTableFlags_RowBg | ImGuiTableFlags_SizingStretchProp)) {
        ImGui::TableSetupColumn("Grid path", 0, 3); ImGui::TableSetupColumn("Type"); ImGui::TableSetupColumn("Size"); ImGui::TableSetupColumn("Distinct"); ImGui::TableSetupColumn("Writable"); ImGui::TableSetupColumn(""); ImGui::TableHeadersRow();
        for (auto& g : MapData::Grids()) { ImGui::TableNextRow(); ImGui::PushID(g.idx); ImGui::TableNextColumn(); ImGui::TextColored(g.idx == MapData::ChosenGrid() ? kGood : ImGui::GetStyleColorVec4(ImGuiCol_Text), "%s", g.path.c_str());
            ImGui::TableNextColumn(); ImGui::TextUnformatted(g.kind.c_str()); ImGui::TableNextColumn(); ImGui::Text("%dx%d", g.w, g.h); ImGui::TableNextColumn(); ImGui::Text("%d", g.unique); ImGui::TableNextColumn(); ImGui::TextUnformatted(g.writable ? "yes" : "no");
            ImGui::TableNextColumn(); if (ImGui::SmallButton("Use this")) MapData::UseGrid(g.idx); UI::Tip(g.reader.c_str()); ImGui::PopID(); }
        ImGui::EndTable(); }
}
}
