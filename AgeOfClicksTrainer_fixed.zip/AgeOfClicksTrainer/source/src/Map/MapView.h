// MapView: the interactive map widget (zoom, pan, search, selection, hover info, minimap, filters, map modes).
#pragma once
#include <string>
#include "imgui.h"

namespace MapView {
enum Mode { M_POLITICAL, M_TERRITORY, M_RESOURCE, M_POPULATION, M_MILITARY, M_HAPPINESS, M_ECONOMY, M_DIPLOMACY, M_COUNT };
extern const char* kModeNames[M_COUNT];

struct Focus {                  // the territory the user last clicked / right-clicked
    bool valid = false; int tx = 0, ty = 0, sx = 0, sy = 0, owner = -1; unsigned raw = 0; size_t cells = 0; double countryShare = 0; std::string ownerName;
};
void Tick(double now);                      // keeps map data and the world table fresh while the map is visible
void DrawToolbar();
void DrawCanvas(ImVec2 size);               // the map itself
void DrawSidePanel();                       // details for the selection / focused territory
void DrawDialogs();                         // confirmation dialog for territory changes (safe to call from several tabs)
void DrawSetup();                           // detection status, grid choice, resolution, diagnostics
const Focus& GetFocus();
void SetFocusAt(int tx, int ty);
void CenterOnCountry(const std::string& name);
void CenterOnFocus();
void RequestChangeOwner(const std::string& newOwner);   // asks for confirmation, then rewrites the region
void SetMode(int mode);
void Release();                             // free the texture
}
