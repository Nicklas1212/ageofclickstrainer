// MapData: discovers the game's territory grid through the bridge, matches grid values to countries and keeps a
// down-sampled copy for display. All discovery is done at run time because the game's map classes are not documented.
#pragma once
#include <cstdint>
#include <string>
#include <vector>

namespace MapData {
enum class Stage { Idle, Probing, ChooseGrid, MatchKeys, Loading, Ready, Failed };
struct GridInfo { int idx = 0; std::string path, kind, reader; int w = 0, h = 0, unique = 0; long long mn = 0, mx = 0; bool writable = false; };

void Tick(double now, bool wanted);                 // drives the state machine; `wanted` = the map is on screen
void Detect();                                      // (re)start detection from scratch
void UseGrid(int idx);                              // user picked another candidate grid
void Refresh();                                     // request fresh data now
Stage GetStage();
const std::string& Message();                       // human-readable status / error
const std::vector<GridInfo>& Grids();
int ChosenGrid();
const std::string& Extractor();                     // how grid values were matched to countries
int Coverage();                                     // % of land cells matched to a known country
int Width(); int Height(); int SourceWidth(); int SourceHeight();
uint32_t Raw(int x, int y);                         // raw grid value at a down-sampled cell
int OwnerAt(int x, int y);                          // index into state().Countries(), or -1
int OwnerIndexOfName(const std::string& name);
bool KeyForCountry(const std::string& name, uint32_t& key);   // grid value that stands for this country
uint64_t Version();                                 // increments when the picture could look different
bool Writable();
std::vector<std::string> CountryNames();            // countries that have a grid key
}
