#include "Map/MapData.h"
#include <cstring>
#include <algorithm>
#include <map>
#include "Core/Config.h"
#include "Core/Link.h"
#include "Core/Util.h"
#include "GameState/GameState.h"

namespace MapData {
namespace {
Stage g_stage = Stage::Idle; std::string g_msg = "The map has not been loaded yet."; std::vector<GridInfo> g_grids; int g_chosen = -1;
std::string g_extractor; int g_coverage = 0; int g_w = 0, g_h = 0, g_sw = 0, g_sh = 0; std::vector<uint32_t> g_raw; std::vector<int> g_owner;
std::map<uint32_t, std::string> g_keyName; std::map<std::string, uint32_t> g_nameKey; uint64_t g_version = 1, g_countriesSerial = 0;
double g_nextData = 0; bool g_dataPending = false; uint64_t g_seen[4] = {0, 0, 0, 0};   // probe, keys, data, use
bool g_autoTried = false;

const char* kTags[4] = {"mapprobe", "mapkeys", "mapdata", "mapuse"};
void Clear() { for (auto t : kTags) link().ClearTag(t); for (auto& s : g_seen) s = 0; }
// returns 1 when a new reply arrived (payload in out), -1 for an error reply, 0 when still waiting
int Reply(int which, std::string& out, std::string& err) {
    uint64_t s = link().Serial(kTags[which]); if (s == 0 || s == g_seen[which]) return 0; g_seen[which] = s;
    err = link().TagError(kTags[which]); if (!err.empty()) return -1; out = link().Payload(kTags[which]); return 1;
}
void RebuildOwners() {
    g_countriesSerial = state().CountriesSerial(); g_owner.assign(g_raw.size(), -1); if (g_raw.empty()) return;
    std::map<std::string, int> idx; auto& cs = state().Countries(); for (size_t i = 0; i < cs.size(); i++) idx[cs[i].name] = (int)i;
    std::map<uint32_t, int> keyIdx; for (auto& kv : g_keyName) { auto it = idx.find(kv.second); if (it != idx.end()) keyIdx[kv.first] = it->second; }
    for (size_t i = 0; i < g_raw.size(); i++) { auto it = keyIdx.find(g_raw[i]); if (it != keyIdx.end()) g_owner[i] = it->second; }
    g_version++;
}
void RequestKeys() { g_stage = Stage::MatchKeys; g_msg = "Matching map values to countries..."; link().Submit("mapkeys", "mapkeys"); }
void RequestData() { g_dataPending = true; link().Submit(Fmt("mapdata %d", cfg().mapRes), "mapdata"); }
}

Stage GetStage() { return g_stage; } const std::string& Message() { return g_msg; } const std::vector<GridInfo>& Grids() { return g_grids; } int ChosenGrid() { return g_chosen; }
const std::string& Extractor() { return g_extractor; } int Coverage() { return g_coverage; } int Width() { return g_w; } int Height() { return g_h; } int SourceWidth() { return g_sw; } int SourceHeight() { return g_sh; }
uint32_t Raw(int x, int y) { if (x < 0 || y < 0 || x >= g_w || y >= g_h) return 0; return g_raw[(size_t)y * g_w + x]; }
int OwnerAt(int x, int y) { if (x < 0 || y < 0 || x >= g_w || y >= g_h || g_owner.size() != g_raw.size()) return -1; return g_owner[(size_t)y * g_w + x]; }
uint64_t Version() { return g_version; }
bool Writable() { for (auto& g : g_grids) if (g.idx == g_chosen) return g.writable; return false; }
int OwnerIndexOfName(const std::string& n) { auto& cs = state().Countries(); for (size_t i = 0; i < cs.size(); i++) if (cs[i].name == n) return (int)i; return -1; }
bool KeyForCountry(const std::string& n, uint32_t& k) { auto it = g_nameKey.find(n); if (it == g_nameKey.end()) return false; k = it->second; return true; }
std::vector<std::string> CountryNames() { std::vector<std::string> v; for (auto& kv : g_nameKey) v.push_back(kv.first); return v; }

void Detect() {
    Clear(); g_grids.clear(); g_chosen = -1; g_raw.clear(); g_owner.clear(); g_keyName.clear(); g_nameKey.clear(); g_extractor.clear(); g_coverage = 0; g_w = g_h = 0; g_dataPending = false;
    g_stage = Stage::Probing; g_msg = "Looking for the map grid inside the game..."; link().Submit("mapprobe", "mapprobe"); g_version++;
}
void UseGrid(int idx) {
    for (auto t : kTags) link().ClearTag(t); for (auto& s : g_seen) s = 0; g_raw.clear(); g_owner.clear(); g_chosen = idx; cfg().mapLastGrid = idx;
    g_stage = Stage::MatchKeys; g_msg = "Switching grid..."; link().Submit(Fmt("mapuse %d", idx), "mapuse"); link().Submit("mapkeys", "mapkeys"); g_version++;
}
void Refresh() { if (g_stage == Stage::Ready && !g_dataPending) RequestData(); }

void Tick(double now, bool wanted) {
    if (!state().Ready()) { if (g_stage != Stage::Idle && g_stage != Stage::Failed) { /* keep what we have */ } return; }
    std::string out, err;
    if (g_stage == Stage::Idle) { if (wanted && !g_autoTried) { g_autoTried = true; Detect(); } return; }
    if (g_stage == Stage::Probing) {
        int r = Reply(0, out, err);
        if (r < 0) { g_stage = Stage::Failed; g_msg = err; }
        else if (r > 0) {
            auto rows = Split(out, '\x1e'); if (rows.empty()) { g_stage = Stage::Failed; g_msg = "The bridge returned an empty map probe."; return; }
            g_chosen = atoi(rows[0].c_str()); g_grids.clear();
            for (size_t i = 1; i < rows.size(); i++) { auto c = Split(rows[i], '\x1f'); if (c.size() < 10) continue; GridInfo g; g.idx = atoi(c[0].c_str()); g.path = c[1]; g.kind = c[2]; g.w = atoi(c[3].c_str()); g.h = atoi(c[4].c_str()); g.unique = atoi(c[5].c_str()); g.mn = atoll(c[6].c_str()); g.mx = atoll(c[7].c_str()); g.reader = c[8]; g.writable = c[9] == "1"; g_grids.push_back(g); }
            if (g_grids.empty()) { g_stage = Stage::Failed; g_msg = "No grid that looks like a world map was found in the game. Use 'Dump classes' below and send the file so the detection can be extended."; }
            else if (g_chosen >= 0) RequestKeys();
            else { g_stage = Stage::ChooseGrid; g_msg = "Several candidate grids were found. Choose the one that looks like the world map."; }
        }
        return;
    }
    if (g_stage == Stage::MatchKeys) {
        Reply(3, out, err);   // result of mapuse is informational
        int r = Reply(1, out, err);
        if (r < 0) { g_stage = Stage::ChooseGrid; g_msg = err; }
        else if (r > 0) {
            auto rows = Split(out, '\x1e'); g_keyName.clear(); g_nameKey.clear();
            if (!rows.empty()) { auto h = Split(rows[0], '\x1f'); if (h.size() >= 4) { g_extractor = h[0]; g_coverage = atoi(h[3].c_str()); } }
            for (size_t i = 1; i < rows.size(); i++) { auto c = Split(rows[i], '\x1f'); if (c.size() < 2) continue; uint32_t k = (uint32_t)strtoull(c[0].c_str(), nullptr, 10); g_keyName[k] = c[1]; g_nameKey[c[1]] = k; }
            g_stage = Stage::Loading; g_msg = "Downloading the map picture..."; RequestData();
        }
        return;
    }
    if (g_stage == Stage::Loading || g_stage == Stage::Ready) {
        int r = Reply(2, out, err);
        if (r < 0) { g_dataPending = false; if (g_stage == Stage::Loading) { g_stage = Stage::Failed; g_msg = err; } else g_msg = err; }
        else if (r > 0) {
            g_dataPending = false; size_t sp[4]; size_t p = 0; for (int i = 0; i < 4; i++) { sp[i] = out.find(' ', p); if (sp[i] == std::string::npos) { g_stage = Stage::Failed; g_msg = "Malformed map data."; return; } p = sp[i] + 1; }
            int ow = atoi(out.substr(0, sp[0]).c_str()), oh = atoi(out.substr(sp[0] + 1, sp[1] - sp[0] - 1).c_str()); g_sw = atoi(out.substr(sp[1] + 1, sp[2] - sp[1] - 1).c_str()); g_sh = atoi(out.substr(sp[2] + 1, sp[3] - sp[2] - 1).c_str());
            std::string bin = Base64Decode(out.substr(sp[3] + 1)); if (ow <= 0 || oh <= 0 || bin.size() < (size_t)ow * oh * 4) { g_stage = Stage::Failed; g_msg = "The map data was truncated."; return; }
            g_w = ow; g_h = oh; g_raw.resize((size_t)ow * oh); memcpy(g_raw.data(), bin.data(), g_raw.size() * 4);
            g_stage = Stage::Ready; g_msg = Fmt("Map ready: %dx%d cells shown, source grid %dx%d, %d%% of land matched (%s).", ow, oh, g_sw, g_sh, g_coverage, g_extractor.c_str()); RebuildOwners();
        }
        if (g_stage == Stage::Ready) {
            if (state().CountriesSerial() != g_countriesSerial) RebuildOwners();
            if (wanted && !g_dataPending && now >= g_nextData) { g_nextData = now + std::max(1.0f, cfg().mapRefresh); RequestData(); }
        }
    }
}
}
