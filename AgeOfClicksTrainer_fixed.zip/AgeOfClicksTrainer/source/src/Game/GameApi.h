// GameApi: the single abstraction the UI uses to read and change the game. It speaks the bridge protocol so no
// widget needs to know command syntax. Values are strings that may use 1.5m / 20k / 3b suffixes.
#pragma once
#include <string>
#include "Core/Link.h"

void Cmd(const std::string& command);                                  // queue a bridge command (result shown as a notification)
void Poll(const std::string& command, const std::string& tag, double everySeconds);
bool IsFlag(const std::string& flag);
bool IsLocked(const std::string& key);                                 // key = "country.gold" or "c:Germany.gold"
bool HasGainMultiplier(const std::string& key);
void SetFlag(const std::string& flag, bool on);
std::string Val(const std::string& statusKey);                         // formatted status value ("-" when unknown)

namespace Game {
std::string Target(const std::string& countryName);                    // "country" for the player's own country, otherwise "c:Name"
void Set(const std::string& target, const std::string& field, const std::string& value);
void Add(const std::string& target, const std::string& field, const std::string& value);
void Multiply(const std::string& target, const std::string& field, const std::string& factor);
void Reset(const std::string& target, const std::string& field);
void Freeze(const std::string& target, const std::string& field, bool on);
void Floor(const std::string& target, const std::string& field, const std::string& value);
}
