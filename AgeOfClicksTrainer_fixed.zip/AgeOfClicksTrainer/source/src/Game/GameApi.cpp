#include "Game/GameApi.h"
#include <map>
#include "GameState/GameState.h"

void Cmd(const std::string& c) { link().Submit(c, "cmd"); }
void Poll(const std::string& cmd, const std::string& tag, double every) { static std::map<std::string, double> nxt; double& n = nxt[tag]; double now = state().Now(); if (now >= n) { n = now + every; link().Submit(cmd, tag); } }
static bool InList(std::string l, const std::string& item) { for (auto& c : l) if (c == '[' || c == ']' || c == '{' || c == '}') c = ','; l = "," + l + ","; return l.find("," + item + ",") != std::string::npos || l.find("," + item + "=") != std::string::npos; }
bool IsFlag(const std::string& f) { return InList(link().Get("flags"), f); }
bool IsLocked(const std::string& key) { return InList(link().Get("locks"), key); }
bool HasGainMultiplier(const std::string& key) { return InList(link().Get("gm"), key); }
void SetFlag(const std::string& f, bool on) { Cmd("flag " + f + " " + (on ? "on" : "off")); }
std::string Val(const std::string& k) { std::string s = link().Get(k); if (s.empty()) return "-"; char* e = nullptr; double d = strtod(s.c_str(), &e); if (e && *e == 0) return Human(d); return s; }

namespace Game {
std::string Target(const std::string& n) { const CountryRow* me = nullptr; for (auto& c : state().Countries()) if (c.me) me = &c; if (!n.empty() && (!me || me->name != n)) return "c:" + EncodeName(n); return "country"; }
void Set(const std::string& t, const std::string& f, const std::string& v) { Cmd("set " + t + " " + f + " " + v); }
void Add(const std::string& t, const std::string& f, const std::string& v) { Cmd("add " + t + " " + f + " " + v); }
void Multiply(const std::string& t, const std::string& f, const std::string& m) { Cmd("mul " + t + " " + f + " " + m); }
void Reset(const std::string& t, const std::string& f) { Cmd("reset " + t + " " + f); }
void Freeze(const std::string& t, const std::string& f, bool on) { Cmd(on ? "lock " + t + "." + f + " exact" : "lock " + t + "." + f + " off"); }
void Floor(const std::string& t, const std::string& f, const std::string& v) { Cmd("lock " + t + "." + f + " floor " + v); }
}
