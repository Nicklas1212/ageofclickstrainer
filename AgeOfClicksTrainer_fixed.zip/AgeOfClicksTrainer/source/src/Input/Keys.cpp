#include "Input/Keys.h"
#include <windows.h>
bool KeyDown(int vk) { return vk != 0 && (GetAsyncKeyState(vk) & 0x8000) != 0; }
std::string KeyName(int vk) {
    if (!vk) return "(none)"; if (vk == VK_INSERT) return "Insert"; if (vk == VK_DELETE) return "Delete"; if (vk == VK_HOME) return "Home"; if (vk == VK_END) return "End"; if (vk == VK_PRIOR) return "Page Up"; if (vk == VK_NEXT) return "Page Down";
    UINT sc = MapVirtualKeyA(vk, MAPVK_VK_TO_VSC); char nm[64]; if (GetKeyNameTextA((LONG)(sc << 16), nm, sizeof nm) > 0) return nm; return "Key " + std::to_string(vk);
}
