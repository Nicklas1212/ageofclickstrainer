// Keyboard helpers (virtual-key names, edge detection) shared by hotkeys and settings.
#pragma once
#include <string>
std::string KeyName(int vk);
bool KeyDown(int vk);
