#include "Presets/Presets.h"
#include <filesystem>
#include <fstream>
#include "Core/Host.h"
#include "Game/GameApi.h"
#include "Notifications/Notifications.h"
namespace fs = std::filesystem;

static std::vector<Preset> g_list;
static fs::path Dir() { return fs::path(host().baseDir) / "presets"; }

void Presets::Load() {
    g_list.clear();
    g_list.push_back({"Unlimited Economy", "Gold and every resource are kept at 9 trillion or more.", {"preset infinite_economy"}, true});
    g_list.push_back({"Maximum Research", "All technologies unlocked, x10 science gain, instant research.", {"preset max_research"}, true});
    g_list.push_back({"Military Power", "Military technology, maximum buildings, invincible units, 5 million of every unit type.", {"techs military", "maxbuildings", "flag godunits on", "set country infantry 5m", "set country artillery 5m", "set country tanks 5m", "set country aircraft 5m", "set country ships 5m", "set country manpower 50m"}, true});
    g_list.push_back({"Sandbox", "Turns on the game's own sandbox mode and its editors.", {"preset sandbox"}, true});
    g_list.push_back({"Superpower", "Unlimited economy, all technology, maximum buildings, friendly relations, huge army.", {"preset superpower"}, true});
    g_list.push_back({"God Mode", "Unlimited economy, no cooldowns, invincible units, no unrest, no capitulation.", {"preset god_mode"}, true});
    g_list.push_back({"Tiny Nation", "Hard start: 5,000 gold, 100 of each resource, no army.", {"preset tiny_nation"}, true});
    g_list.push_back({"AFK", "Auto-clicker, auto-upgrade, auto-research and no cooldowns.", {"preset afk"}, true});
    std::error_code ec; if (!fs::exists(Dir(), ec)) return;
    for (auto& e : fs::directory_iterator(Dir(), ec)) {
        if (e.path().extension() != ".txt") continue; std::ifstream f(e.path()); std::string l; Preset p; p.name = e.path().stem().string(); p.description = "Custom preset";
        while (std::getline(f, l)) { while (!l.empty() && (l.back() == '\r' || l.back() == ' ')) l.pop_back(); if (l.empty()) continue; if (l[0] == '#') { p.description = l.substr(1); while (!p.description.empty() && p.description[0] == ' ') p.description.erase(0, 1); continue; } p.commands.push_back(l); }
        g_list.push_back(p);
    }
}
const std::vector<Preset>& Presets::All() { return g_list; }
void Presets::Apply(int i) {
    if (i < 0 || i >= (int)g_list.size()) return; for (auto& c : g_list[i].commands) Cmd(c);
    Notify::Push(NoteType::Success, "Preset loaded successfully: " + g_list[i].name + ".");
}
bool Presets::SaveUser(const Preset& p) {
    std::error_code ec; fs::create_directories(Dir(), ec); std::string safe; for (char c : p.name) safe += (isalnum((unsigned char)c) || c == ' ' || c == '-' || c == '_') ? c : '_';
    std::ofstream f(Dir() / (safe + ".txt")); if (!f) { Notify::Push(NoteType::Error, "Could not save the preset file."); return false; }
    f << "# " << p.description << "\n"; for (auto& c : p.commands) f << c << "\n"; Load(); Notify::Push(NoteType::Success, "Preset saved: " + p.name + "."); return true;
}
void Presets::Delete(int i) {
    if (i < 0 || i >= (int)g_list.size() || g_list[i].builtin) return; std::string safe; for (char c : g_list[i].name) safe += (isalnum((unsigned char)c) || c == ' ' || c == '-' || c == '_') ? c : '_';
    std::error_code ec; fs::remove(Dir() / (safe + ".txt"), ec); Load(); Notify::Push(NoteType::Info, "Preset deleted.");
}
Preset Presets::CaptureCurrent(const std::string& name) {
    Preset p; p.name = name; p.description = "Captured from the current toggles, locks and multipliers.";
    std::string fl = link().Get("flags"); for (auto& c : fl) if (c == '[' || c == ']') c = ','; for (auto& f : Split(fl, ',')) if (!f.empty()) p.commands.push_back("flag " + f + " on");
    for (auto& d : Split(link().Get("lockd"), '|')) { auto q = Split(d, ':'); if (q.size() == 3) p.commands.push_back("lock " + q[0] + " " + q[1] + " " + q[2]); }
    std::string gm = link().Get("gm"); for (auto& c : gm) if (c == '{' || c == '}') c = ','; for (auto& g : Split(gm, ',')) { size_t e = g.find('='); if (e != std::string::npos) p.commands.push_back("gainmult " + g.substr(0, e) + " " + g.substr(e + 1)); }
    return p;
}
