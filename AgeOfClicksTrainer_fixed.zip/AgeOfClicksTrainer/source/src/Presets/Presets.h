// Presets: named lists of bridge commands. Built-in presets call the bridge's own preset routines; user presets
// are plain text files (one command per line) in the "presets" folder next to the program.
#pragma once
#include <string>
#include <vector>

struct Preset { std::string name, description; std::vector<std::string> commands; bool builtin = false; };
namespace Presets {
void Load();
const std::vector<Preset>& All();
void Apply(int index);
bool SaveUser(const Preset& p);
void Delete(int index);
Preset CaptureCurrent(const std::string& name);   // builds commands from the currently active toggles/locks/multipliers
}
