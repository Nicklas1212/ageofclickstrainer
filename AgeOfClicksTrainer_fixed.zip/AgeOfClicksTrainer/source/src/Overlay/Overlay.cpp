#include "Overlay/Overlay.h"
#include "Core/SocketLink.h"
#include <windows.h>
#include <GL/gl.h>
#include <atomic>
#include <cstdarg>
#include <cstdio>
#include <string>
#include <thread>
#include "Core/SocketLink.h"
#include "MinHook.h"
#include "imgui.h"
#include "imgui_impl_opengl3.h"
#include "imgui_impl_win32.h"
#include "Core/Config.h"
#include "Core/Host.h"
#include "GameState/GameState.h"
#include "Input/Keys.h"
#include "Notifications/Notifications.h"
#include "UI/App.h"
#include "UI/Common.h"

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

namespace Overlay {
namespace {
char g_logPath[MAX_PATH] = {0}; std::string g_dir, g_iniPath; HMODULE g_self = nullptr;
HWND g_hwnd = nullptr; WNDPROC g_origProc = nullptr; bool g_inited = false, g_failed = false, g_visible = false, g_useGl2Fallback = false; LARGE_INTEGER g_fq, g_t0; bool g_toggleDown = false;
typedef BOOL(WINAPI* SwapFn)(HDC); SwapFn g_origGdiSwap = nullptr, g_origWglSwap = nullptr;

// Map textures: plain OpenGL 1.1 calls, with the game's GL state restored afterwards.
struct GlTextures : ITextureBackend {
    ImTextureID Create(int w, int h, const uint32_t* px) override {
        GLint prev = 0, ra = 0, al = 4; glGetIntegerv(GL_TEXTURE_BINDING_2D, &prev); glGetIntegerv(0x0CF2 /*GL_UNPACK_ROW_LENGTH*/, &ra); glGetIntegerv(GL_UNPACK_ALIGNMENT, &al);
        GLuint t = 0; glGenTextures(1, &t); glBindTexture(GL_TEXTURE_2D, t); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, 0x812F); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, 0x812F); glPixelStorei(0x0CF2, 0); glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, px); glPixelStorei(0x0CF2, ra); glPixelStorei(GL_UNPACK_ALIGNMENT, al); glBindTexture(GL_TEXTURE_2D, (GLuint)prev); return (ImTextureID)(uintptr_t)t; }
    void Update(ImTextureID id, int w, int h, const uint32_t* px) override {
        GLint prev = 0, ra = 0, al = 4; glGetIntegerv(GL_TEXTURE_BINDING_2D, &prev); glGetIntegerv(0x0CF2, &ra); glGetIntegerv(GL_UNPACK_ALIGNMENT, &al);
        glBindTexture(GL_TEXTURE_2D, (GLuint)(uintptr_t)id); glPixelStorei(0x0CF2, 0); glPixelStorei(GL_UNPACK_ALIGNMENT, 1); glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, w, h, GL_RGBA, GL_UNSIGNED_BYTE, px); glPixelStorei(0x0CF2, ra); glPixelStorei(GL_UNPACK_ALIGNMENT, al); glBindTexture(GL_TEXTURE_2D, (GLuint)prev); }
    void Destroy(ImTextureID id) override { GLuint t = (GLuint)(uintptr_t)id; if (t) glDeleteTextures(1, &t); }
};

LRESULT CALLBACK HookedProc(HWND h, UINT m, WPARAM w, LPARAM l) {
    if (g_visible && g_inited) {
        ImGui_ImplWin32_WndProcHandler(h, m, w, l); ImGuiIO& io = ImGui::GetIO();
        switch (m) {
            case WM_LBUTTONDOWN: case WM_LBUTTONUP: case WM_LBUTTONDBLCLK: case WM_RBUTTONDOWN: case WM_RBUTTONUP: case WM_RBUTTONDBLCLK: case WM_MBUTTONDOWN: case WM_MBUTTONUP: case WM_MOUSEWHEEL: case WM_MOUSEHWHEEL: case WM_XBUTTONDOWN: case WM_XBUTTONUP:
                if (io.WantCaptureMouse) return 0; break;
            case WM_KEYDOWN: case WM_KEYUP: case WM_SYSKEYDOWN: case WM_SYSKEYUP: case WM_CHAR: case WM_UNICHAR:
                if (io.WantCaptureKeyboard || io.WantTextInput) return 0; break;
            case WM_SETCURSOR: if (io.WantCaptureMouse && LOWORD(l) == HTCLIENT) return TRUE; break;
        }
    }
    return CallWindowProcW(g_origProc, h, m, w, l);
}

bool Init(HDC dc) {
    g_hwnd = WindowFromDC(dc); if (!g_hwnd) return false;
    char ver[64] = ""; const char* v = (const char*)glGetString(GL_VERSION); if (v) snprintf(ver, sizeof ver, "%s", v); int major = atoi(ver);
    Log("overlay: window %p, OpenGL %s", (void*)g_hwnd, ver); if (major < 3) { Log("overlay: OpenGL older than 3.0 is not supported by the overlay"); return false; }
    bool core = strstr(ver, "Core") != nullptr || major >= 4 || (major == 3 && atoi(ver + 2) >= 2);
    IMGUI_CHECKVERSION(); ImGui::CreateContext(); ImGuiIO& io = ImGui::GetIO(); g_iniPath = g_dir + "AgeOfClicksOverlay.ini"; io.IniFilename = g_iniPath.c_str(); io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
    UI::LoadFonts(io);
    if (!ImGui_ImplWin32_Init(g_hwnd)) { Log("overlay: ImGui Win32 init failed"); return false; }
    if (!ImGui_ImplOpenGL3_Init(core ? "#version 150" : "#version 130")) { Log("overlay: ImGui OpenGL3 init failed"); return false; }
    static SocketLink net; static GlTextures tex; SetLink(&net); host().tex = &tex; host().overlay = true; host().baseDir = g_dir; host().requestClose = []() { g_visible = false; };
    host().hasFocus = false; host().injectStatus.clear();
    LoadConfig(g_dir); App::Init(); net.Start();
    g_origProc = (WNDPROC)SetWindowLongPtrW(g_hwnd, GWLP_WNDPROC, (LONG_PTR)HookedProc); QueryPerformanceFrequency(&g_fq); QueryPerformanceCounter(&g_t0);
    Log("overlay: ready (press the overlay key, Insert by default)"); return true;
}

void Frame(HDC dc) {
    if (g_failed) return;
    if (!g_inited) { try { g_inited = Init(dc); } catch (...) { g_inited = false; } if (!g_inited) { g_failed = true; return; } }
    LARGE_INTEGER t1; QueryPerformanceCounter(&t1); double now = double(t1.QuadPart - g_t0.QuadPart) / g_fq.QuadPart; ImGuiIO& io = ImGui::GetIO();
    bool fg = GetForegroundWindow() == g_hwnd; bool d = fg && KeyDown(cfg().vk[A_OVERLAY]); if (d && !g_toggleDown) g_visible = !g_visible; g_toggleDown = d;
    host().hasFocus = g_visible; host().hotkeysActive = fg;
    if (g_visible) io.ConfigFlags &= ~ImGuiConfigFlags_NoMouseCursorChange; else io.ConfigFlags |= ImGuiConfigFlags_NoMouseCursorChange;
    if (!g_visible) io.ConfigFlags |= ImGuiConfigFlags_NoMouse; else io.ConfigFlags &= ~ImGuiConfigFlags_NoMouse;
    App::Tick(now);
    ImGui_ImplOpenGL3_NewFrame(); ImGui_ImplWin32_NewFrame(); ImGui::NewFrame();
    if (g_visible) App::DrawWindows();
    Notify::Draw(now);
    ImGui::Render(); ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
}

thread_local int g_depth = 0;
BOOL WINAPI HkSwap(HDC dc, SwapFn orig) {
    if (g_depth == 0) { g_depth++; try { Frame(dc); } catch (...) { g_failed = true; Log("overlay: exception while drawing - overlay disabled"); } g_depth--; }
    g_depth++; BOOL r = orig(dc); g_depth--; return r;
}
BOOL WINAPI HkGdiSwap(HDC dc) { return HkSwap(dc, g_origGdiSwap); }
BOOL WINAPI HkWglSwap(HDC dc) { return HkSwap(dc, g_origWglSwap); }

void Run() {
    Log("overlay: waiting for OpenGL...");
    HMODULE gl = nullptr, gdi = GetModuleHandleA("gdi32.dll"); for (int i = 0; i < 1200 && !gl; i++) { gl = GetModuleHandleA("opengl32.dll"); if (!gl) Sleep(100); }
    if (!gl) { Log("overlay: opengl32.dll never loaded - no overlay"); return; }
    if (MH_Initialize() != MH_OK) { Log("overlay: MinHook init failed"); return; }
    void* wgl = (void*)GetProcAddress(gl, "wglSwapBuffers"); void* gdiSwap = gdi ? (void*)GetProcAddress(gdi, "SwapBuffers") : nullptr; int hooked = 0;
    if (gdiSwap && MH_CreateHook(gdiSwap, (void*)HkGdiSwap, (void**)&g_origGdiSwap) == MH_OK && MH_EnableHook(gdiSwap) == MH_OK) hooked++;
    if (wgl && MH_CreateHook(wgl, (void*)HkWglSwap, (void**)&g_origWglSwap) == MH_OK && MH_EnableHook(wgl) == MH_OK) hooked++;
    Log("overlay: %d buffer-swap hook(s) installed", hooked);
}
}

void Log(const char* fmt, ...) {
    if (!g_logPath[0]) return; FILE* f = fopen(g_logPath, "ab"); if (!f) return; SYSTEMTIME t; GetLocalTime(&t); fprintf(f, "[%02d:%02d:%02d] ", t.wHour, t.wMinute, t.wSecond);
    va_list a; va_start(a, fmt); vfprintf(f, fmt, a); va_end(a); fputc('\n', f); fclose(f);
}
void Start(HMODULE self) {
    g_self = self; GetModuleFileNameA(self, g_logPath, MAX_PATH); char* sl = strrchr(g_logPath, '\\'); if (sl) *(sl + 1) = 0; g_dir = g_logPath; strcat(g_logPath, "aoc_trainer_dll.log");
    std::thread(Run).detach();
}
}
