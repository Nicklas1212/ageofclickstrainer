// In-game overlay: hooks the game's OpenGL buffer swap and draws the shared UI on top of the game.
#pragma once
#include <windows.h>
namespace Overlay {
void Start(HMODULE self);        // call once from the injected DLL; returns immediately (works on its own thread)
void Log(const char* fmt, ...);  // writes to aoc_trainer_dll.log next to the DLL
}
