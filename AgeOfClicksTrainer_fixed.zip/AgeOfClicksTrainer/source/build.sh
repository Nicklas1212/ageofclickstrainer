#!/usr/bin/env bash
# Cross-compile (Linux -> Windows x64) with mingw-w64 (posix threads). On Windows use build_windows.bat / CMake instead.
# Produces dist/AgeOfClicksTrainer.exe (window), dist/AgeOfClicksTrainerCore.dll (bridge + in-game overlay), dist/AocInject.exe (CLI injector).
set -e
cd "$(dirname "$0")"
CXX=x86_64-w64-mingw32-g++-posix; CC=x86_64-w64-mingw32-gcc-posix
OUT=dist; OBJ=obj; IM=imgui; Z=third_party/zlib; MH=third_party/minhook
mkdir -p $OUT $OBJ
FLAGS="-O2 -std=c++17"
INC="-Isrc -I$IM -I$IM/backends -I$Z -I$MH/include -Isrc/UI/Diplomacy -Isrc/UI/Territory"
[ -f dll/bridge_classes.h ] || python3 bridge/gen_header.py
newer() { [ ! -f "$2" ] || [ "$1" -nt "$2" ]; }
# third-party objects
for f in adler32 compress crc32 deflate inflate inffast inftrees trees zutil uncompr; do newer $Z/$f.c $OBJ/z_$f.o && $CC -O2 -c $Z/$f.c -I$Z -o $OBJ/z_$f.o; done
for f in imgui imgui_draw imgui_tables imgui_widgets backends/imgui_impl_win32 backends/imgui_impl_dx11 backends/imgui_impl_opengl3; do n=$(basename $f); newer $IM/$f.cpp $OBJ/im_$n.o && $CXX $FLAGS -c $IM/$f.cpp -I$IM -I$IM/backends -o $OBJ/im_$n.o; done
for f in buffer hook trampoline hde/hde64; do n=$(basename $f); newer $MH/src/$f.c $OBJ/mh_$n.o && $CC -O2 -c $MH/src/$f.c -I$MH/include -I$MH/src -o $OBJ/mh_$n.o; done
# application sources (compiled in parallel)
SHARED=$(find src -name '*.cpp' ! -path 'src/Main/*' ! -path 'src/Overlay/*'); SHARED_O=""; pids=()
for f in $SHARED src/Main/Main.cpp src/Overlay/Overlay.cpp; do o=$OBJ/s_$(echo $f | tr '/.' '__').o; case $f in src/Main/*|src/Overlay/*) ;; *) SHARED_O="$SHARED_O $o";; esac
  if newer $f $o || [ -n "$(find src -name '*.h' -newer $o 2>/dev/null | head -1)" ]; then $CXX $FLAGS -Wall -Wno-unused-function -Wno-unused-variable -Wno-sign-compare -Wno-misleading-indentation -c $f $INC -o $o & pids+=($!); fi; done
for p in "${pids[@]}"; do wait $p; done
ZO="$OBJ/z_*.o"
# 1) trainer window
$CXX $FLAGS -mwindows -static -static-libgcc -static-libstdc++ -o $OUT/AgeOfClicksTrainer.exe $OBJ/s_src_Main_Main_cpp.o $SHARED_O $ZO $OBJ/im_imgui.o $OBJ/im_imgui_draw.o $OBJ/im_imgui_tables.o $OBJ/im_imgui_widgets.o $OBJ/im_imgui_impl_win32.o $OBJ/im_imgui_impl_dx11.o \
  -ld3d11 -ldxgi -ld3dcompiler -lws2_32 -lgdi32 -ldwmapi -lshell32 -lole32 -lcomdlg32 -limm32 -lpsapi -ladvapi32
# 2) injected DLL: Java bridge loader + in-game overlay
$CXX $FLAGS -shared -static -static-libgcc -static-libstdc++ -o $OUT/AgeOfClicksTrainerCore.dll dll/aoc_dll.cpp $OBJ/s_src_Overlay_Overlay_cpp.o $SHARED_O $ZO $OBJ/mh_*.o $OBJ/im_imgui.o $OBJ/im_imgui_draw.o $OBJ/im_imgui_tables.o $OBJ/im_imgui_widgets.o $OBJ/im_imgui_impl_win32.o $OBJ/im_imgui_impl_opengl3.o \
  -Idll $INC -Wl,--kill-at -lopengl32 -lws2_32 -lgdi32 -ldwmapi -lshell32 -lole32 -limm32 -lpsapi -ladvapi32
# 3) command-line injector
$CXX -O2 -std=c++17 -static -static-libgcc -static-libstdc++ -o $OUT/AocInject.exe trainer/injector_cli.cpp -Itrainer -lpsapi -ladvapi32
ls -la $OUT
