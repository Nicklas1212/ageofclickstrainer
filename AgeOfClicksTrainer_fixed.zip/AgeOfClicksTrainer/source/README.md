# Age of Clicks Trainer v2  (single-player only)

A developer/debug interface for **Age of Clicks** (Steam). Windows 10/11 x64. Everything you see is in English.

> **Single-player only.** The in-game bridge checks the game's own network/multiplayer flags and refuses every write
> if a multiplayer session is detected. Do not use it online.

## Quick start
1. **Back up your saves first** (page *Save States* > *Create backup now*).
2. Unzip into one folder. Keep `AgeOfClicksTrainer.exe`, `AgeOfClicksTrainerCore.dll` and `AocInject.exe` together.
3. Start Age of Clicks and load or start a **single-player** game.
4. Start `AgeOfClicksTrainer.exe` (run as administrator if injection fails). It injects automatically; the dot in the header turns green.
5. **In-game overlay:** switch to the game window and press **Insert**. The overlay appears on top of the game: a "Quick values" bar and the full tool window. Press Insert again to hide it. While it is open you can still click the game itself wherever the overlay has no window.

## What is new in v2
* **Interactive map** (page *Map*): zoom (mouse wheel), pan (drag), hover info (population, money, military, happiness, stability), click to select, double-click to center, search, filters, minimap, country labels, and 8 map modes: Political, Territory ownership, Resource, Population, Military, Happiness, Economy, Diplomacy. Right-click a territory for: Inspect Territory, Edit Territory, Change Owner, Center Camera, View Resources, View Population.
* **Click any value to edit it.** Highlighted values (green, underlined on hover) open an editor with Set / Add / Subtract / Multiply / Freeze / Minimum / Infinite / Reset. This works on the Dashboard, in the in-game "Quick values" bar, in tables, on the Countries page and on the Resources page. (The game's own widgets cannot be hooked; the overlay shows the same values next to them instead.)
* **Economy Planner:** type how much of each resource you want to produce per day. It reads the game's own building costs, measures what each upgrade really adds, picks the cheapest set of upgrades, shows the total cost and the exact building levels, and applies it (buy with your money, optionally add missing money, or set levels directly).
* **Country Inspector**, **Economy / Population / Military / Research / Resources (dynamic list from the game) / Industry editors**, **Diplomacy (Country A / Country B)**, **Territory editor**, **World**, **Events**, **History with Undo / Redo (before -> after)**, **Variable Explorer** (searchable live object tree with edit and reset), **Presets** (built-in + your own), **Settings** (theme, UI scale, opacity, animations, map, hotkeys, notifications, profiles, reset).
* Notifications (Info / Success / Warning / Error), movable and resizable overlay windows, any page can be popped out into its own window, persistent settings.

## Default hotkeys (change in Settings)
| Key | Action |
|---|---|
| Insert | Toggle the in-game overlay (in the trainer window: compact mode) |
| F1 / F2 / F3 / F4 / F5 | Dashboard / Map / Countries / Economy / Military (while the overlay or trainer window is active) |
| F6 | Auto-clicker | 
| F7 | Pause / resume |
| F8 | Add money (amount in Settings) |
| F9 / F10 | Quick-save / quick-load state |
| F11 | Undo (Ctrl+Z and Ctrl+Y also work inside the UI) |
| Ctrl+F | Search pages; Ctrl+PageUp / PageDown switches page |

## Honest notes (please read)
I could not run the real game or any Windows program while building this. What was verified, and how:
* **Verified against a mock of the game's classes (real JVM):** the Java bridge (all commands, history/undo/redo, multiply/reset, resources, variable explorer, map discovery, planner), the embedded-class loading sequence through JNI, and the C++ client logic (protocol parsing, map data pipeline, presets, edits). A headless run draws **every page in both layouts** with Dear ImGui's assertions enabled, including the map with simulated hover, clicks and all 8 modes.
* **Not verified (needs your game):**
  * **Map detection.** The game's map classes are undocumented. The tool searches the game's objects for a large integer grid and matches its values to countries (by colour or id). If the picture is wrong, open *Map > Map setup & diagnostics* (or *Settings > Map detection*), choose another grid, or press *Dump classes to file* and send me `aoc_class_dump.txt`.
  * **The in-game overlay** (hooks the game's OpenGL buffer swap with MinHook, draws Dear ImGui on top, subclasses the window procedure). It needs OpenGL 3.0 or newer. If it does not appear, read `aoc_trainer_dll.log` next to the DLL; it states what happened. The trainer window works independently of it.
  * **Economy Planner.** It measures effects through the game's own functions (`ResourceLedger`). A resource whose production does not react to building levels is reported as such instead of guessed. Units are whatever the ledger reports per day.
  * **Change Owner** (writes the map grid). Experimental; the game may redraw its map only after a reload and the standard Undo does not cover it (change the owner back to revert).
  * **Stability** is estimated from revolution risk because the game has no single stability value.
* Some things do not exist in this game and are listed as unavailable instead of faked: inflation, migration, civilian/military factory split, fog of war, direct border painting, peace-conference values (use the sandbox editors).
* The game recalculates many numbers each day. If a value snaps back, use **Freeze** or **Minimum**.
* Keep backups. Changing a running game can corrupt progress or disable achievements.

## Files
* `AgeOfClicksTrainer.exe` - the trainer window (DirectX 11).
* `AgeOfClicksTrainerCore.dll` - injected into the game: Java bridge + in-game overlay.
* `AocInject.exe` - command-line injector (only injects).
* Settings: `AgeOfClicksTrainer.ini`; overlay window layout: `AgeOfClicksOverlay.ini`; your presets: `presets\*.txt` (one bridge command per line); backups: `backups\`; log of the injected part: `aoc_trainer_dll.log`.

## Troubleshooting
* *"Age of Clicks is not running"* - the process must be `Age of Clicks.exe`.
* *"Injection failed ... error 5"* - run as administrator. Antivirus may flag any DLL injector; the full source is in `source\`.
* *Connected but "waiting for a single-player game"* - you are in the main menu; load a save.
* *Overlay does not show* - make sure the game window is in front, press Insert; check `aoc_trainer_dll.log`.
* *Map is empty or wrong* - see "Not verified" above.
* Delete `AgeOfClicksTrainer.ini` to reset all settings (or use *Settings > Reset*).

## Source layout (`source\`)
```
src/Core        utilities, config, link (command queue), socket transport, host interface
src/Game        GameApi: the only place that speaks the bridge command syntax
src/GameState   client model of the game (status, world table, series, events)
src/Map         MapData (discovery + data), MapView (interactive map)
src/Overlay     in-game overlay (OpenGL hook)           src/Main   trainer window (DX11)
src/Hotkeys, Input, Presets, Notifications
src/UI          App shell + Common widgets + one folder per area (Dashboard, Economy, Population, Military, Research, Diplomacy, Territory, Settings, ...)
bridge/src      Java bridge (reflection on the game's classes) - AocBridge, AocExt, AocWorld, AocVars, AocMap, AocPlan
bridge/test     mock game + tests (incl. native/ harness: headless UI smoke test, protocol test)
dll/            injected loader (JNI class definition) + generated bridge_classes.h
```
* **Linux cross-compile:** `apt install mingw-w64 default-jdk python3 cmake git`, then `./build.sh` (outputs to `dist/`). This is the verified build path.
* **Windows:** CMake + MSYS2 MinGW-w64: `build_windows.bat` (not verified here; MSVC is untested).
* After changing `bridge/src/*.java` run `python3 bridge/gen_header.py` (compiles and re-embeds the bytecode).
* Dependencies bundled: Dear ImGui 1.91.5, zlib 1.3.1, MinHook.

## Bridge protocol (for tinkering)
Line-based text on `127.0.0.1:47653`. Replies are `OK|payload` or `ERR|CODE|message`. Examples: `set country gold 1.5m`, `mul country gold 2`, `reset country gold`, `lock country.gold floor 9t`, `set c:Germany gold 5m`, `resources`, `rates`, `wstats`, `cinfo Germany`, `dipl A B`, `relpair A B 100`, `mapprobe`, `mapdata 512`, `plan iron=50k steel=10k`, `planapply buy 1`, `vx country`, `vxset <path> <value>`, `history`, `undo`, `redo`.
